from pathlib import Path
import subprocess
import tempfile

root = Path.cwd()
with tempfile.TemporaryDirectory(prefix='btmobile-v124-tests-') as directory:
    tmp = Path(directory)
    service = root / 'iTorrent/Services/TrackersListService/TrackersListService.swift'
    (tmp / 'TrackersListService.swift').write_text(service.read_text().replace('import LibTorrent\n', '').replace('import MvvmFoundation\n', ''))
    (tmp / 'main.swift').write_text((root / 'tests/v124/main.swift').read_text())
    folder = root / 'iTorrent/Services/TorrentService'
    subprocess.run(['xcrun', 'swiftc', str(folder / 'BTSubscription.swift'), str(folder / 'BTSubscriptionNetwork.swift'),
                    str(folder / 'BTClientRuntimeProtocol.swift'), str(tmp / 'TrackersListService.swift'),
                    str(tmp / 'main.swift'), '-o', str(tmp / 'runtime-tests')], check=True)
    subprocess.run([str(tmp / 'runtime-tests')], check=True)
    runtime = (folder / 'BTClientRuntimeService.swift').read_text()
    for forbidden in ['.pause(', '.resume(', 'reopenNetworkSockets', 'settingsUpdatePublisher', 'reannounceToAllTrackers']:
        assert forbidden not in runtime, forbidden
    for required in ['timeInterval: 60', '!s.isPaused', '.seeding', '.downloading', '.downloadingMetadata', 'forMode: .common']:
        assert required in runtime, required
    print('PASS V1.2.4: activity observes live snapshots, timer remains separate from core and payment')
