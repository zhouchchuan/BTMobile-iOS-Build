import Foundation
import Combine
final class TorrentHandle {
    var isPrivate = false
    var added: [String] = []
    func addTracker(_ address: String) { added.append(address) }
}
final class DisposeBag { var tokens = Set<AnyCancellable>() }
extension AnyCancellable { func store(in bag: DisposeBag) { bag.tokens.insert(self) } }
let defaults = UserDefaults.standard
let keys = ["TrackersListServiceDataKey", "btmobileV124DefaultTrackers", "btmobileManagedTrackersRevision"]
keys.forEach { defaults.removeObject(forKey: $0) }
defer { keys.forEach { defaults.removeObject(forKey: $0) } }
let source = TrackersListService.ListState.Source.local(UUID(uuidString: "B7120000-0000-4000-8000-000000000008")!)
let userSource = TrackersListService.ListState.Source.local(UUID())
let old: [TrackersListService.ListState.Source: TrackersListService.ListState] = [
    source: .init(source: source, title: "Old defaults", status: .updated, trackers: ["http://tracker.linkyou.win:6969/announce", "https://custom.example.test/announce"]),
    userSource: .init(source: userSource, title: "User list", status: .updated, trackers: ["https://other.example.test/announce"])]
defaults.set(try JSONEncoder().encode(old), forKey: "TrackersListServiceDataKey")
let service = TrackersListService()
assert(service.trackerSources.value.count == 3)
assert(service.trackerSources.value[source]!.trackers == TrackersListService.bundledTrackers)
assert(TrackersListService.bundledTrackers.count == 9)
assert(service.trackerSources.value.values.contains { $0.trackers == ["https://custom.example.test/announce"] })
assert(service.trackerSources.value[userSource]!.trackers == ["https://other.example.test/announce"])
service.applyManagedTrackers(["https://new.example.test/announce"], revision: 2)
service.applyManagedTrackers(["https://stale.example.test/announce"], revision: 1)
assert(service.trackerSources.value[source]!.trackers == ["https://new.example.test/announce"])
assert(TrackersListService().trackerSources.value[source]!.trackers == ["https://new.example.test/announce"])
service.applyManagedTrackers([], revision: 3)
assert(service.trackerSources.value[source]!.trackers.isEmpty)
assert(service.trackerSources.value[userSource]!.trackers.count == 1)
let privateTorrent = TorrentHandle(); privateTorrent.isPrivate = true
service.addAllTrackers(to: privateTorrent); assert(privateTorrent.added.isEmpty)
let publicTorrent = TorrentHandle(); service.addAllTrackers(to: publicTorrent)
assert(publicTorrent.added.count == 2)
for address in TrackersListService.bundledTrackers { assert(BTClientConfiguration.validTracker(address)) }
for address in ["file:///tmp/secret", "https://user:pass@example.test/a", "udp://example.test/a", "https://example.test/a#f", "https://example.test/a b", "javascript:alert(1)"] {
    assert(!BTClientConfiguration.validTracker(address), address)
}
let nonce = UUID().uuidString, now = Date().timeIntervalSince1970
func config(_ kind: String = "client-config", _ token: String? = nil, _ at: Double? = nil, _ list: [String]? = nil) -> BTClientConfiguration {
    .init(kind: kind, nonce: token ?? nonce, issuedAt: at ?? now, trackersRevision: 1, trackers: list ?? TrackersListService.bundledTrackers)
}
assert((try? config().validated(nonce: nonce, now: now)) != nil)
assert((try? config("wrong").validated(nonce: nonce, now: now)) == nil)
assert((try? config("client-config", "replay").validated(nonce: nonce, now: now)) == nil)
assert((try? config("client-config", nil, now-301).validated(nonce: nonce, now: now)) == nil)
assert((try? config("client-config", nil, nil, ["https://example.test/a", "https://example.test/a"]).validated(nonce: nonce, now: now)) == nil)
assert((try? config("client-config", nil, nil, []).validated(nonce: nonce, now: now)) != nil)
print("PASS V1.2.4: 9 bundled trackers; upgrade preserves custom lists; remote replace, clear, rollback defense, persistence; private torrents excluded; signed-config fields and URL validation")
