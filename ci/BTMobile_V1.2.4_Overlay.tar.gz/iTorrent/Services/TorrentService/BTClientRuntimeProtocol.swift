import Foundation
import CryptoKit

// A separate, signed operational channel. It never grants paid rights or changes quota.
struct BTClientConfiguration: Decodable, Sendable {
    let kind: String
    let nonce: String
    let issuedAt: Double
    let trackersRevision: Int
    let trackers: [String]
    func validated(nonce expected: String, now: Double = Date().timeIntervalSince1970) throws -> Self {
        guard kind == "client-config", nonce == expected, abs(now - issuedAt) < 300,
              trackersRevision > 0, trackers.count <= 100, Set(trackers).count == trackers.count,
              trackers.allSatisfy(Self.validTracker) else { throw BTSubscriptionError.damagedIdentity }
        return self
    }
    static func validTracker(_ text: String) -> Bool {
        guard text.utf8.count <= 512, !text.isEmpty,
              !text.unicodeScalars.contains(where: { CharacterSet.whitespacesAndNewlines.contains($0) || CharacterSet.controlCharacters.contains($0) }),
              !text.contains("\\"), let url = URLComponents(string: text),
              ["http", "https", "udp"].contains(url.scheme ?? ""),
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil,
              url.fragment == nil else { return false }
        if url.scheme == "udp" && url.port == nil { return false }
        if let port = url.port, !(1...65535).contains(port) { return false }
        return true
    }
}

struct BTClientActivity: Encodable, Sendable {
    let platform: String
    let version: String
    let foreground: Bool
    let downloading: Int
    let seeding: Int
    let metadata: Int
    let checking: Int
    let downloadRate: UInt64
    let uploadRate: UInt64
}

private final class BTRuntimeNoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

actor BTClientRuntimeNetwork {
    static let shared = BTClientRuntimeNetwork()
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 10
        config.timeoutIntervalForResource = 15
        config.httpShouldSetCookies = false
        return URLSession(configuration: config, delegate: BTRuntimeNoRedirect(), delegateQueue: nil)
    }()
    private var verifiedService = false
    private var lastRegistrationAttempt = Date.distantPast
    private struct Ack: Decodable {
        let kind: String; let nonce: String; let deviceID: String; let issuedAt: Double
    }
    func configuration() async throws -> BTClientConfiguration {
        let nonce = UUID().uuidString
        let base = await BTSubscriptionNetwork.shared.endpoint()
        let url = URL(string: base + "/v1/client-config?nonce=" + nonce)!
        let (data, response) = try await session.data(from: url)
        guard data.count <= 65536, (response as? HTTPURLResponse)?.statusCode == 200 else { throw BTSubscriptionError.damagedIdentity }
        let config: BTClientConfiguration = try BTSubscriptionVerifier.decode(data)
        let result = try config.validated(nonce: nonce)
        verifiedService = true
        return result
    }
    func report(_ activity: BTClientActivity) async throws {
        // Never transmit identity to an unverified endpoint, even when payment is disabled.
        guard verifiedService else { return }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let body = try encoder.encode(activity)
        let base = await BTSubscriptionNetwork.shared.endpoint()
        let path = "/v1/activity", nonce = UUID().uuidString
        let identity = BTSubscription.shared.snapshot
        guard identity.error == nil else { return }
        let time = String(Int(Date().timeIntervalSince1970))
        let digest = SHA256.hash(data: body).map { String(format: "%02x", $0) }.joined()
        let message = Data("POST\n\(path)\n\(time)\n\(nonce)\n\(digest)".utf8)
        let signature = try BTSubscription.shared.deviceKey().signature(for: message).derRepresentation.base64EncodedString()
        var request = URLRequest(url: URL(string: base + path)!)
        request.httpMethod = "POST"; request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(identity.deviceID, forHTTPHeaderField: "X-Device-ID")
        request.setValue(time, forHTTPHeaderField: "X-Time")
        request.setValue(nonce, forHTTPHeaderField: "X-Nonce")
        request.setValue(signature, forHTTPHeaderField: "X-Signature")
        let (data, response) = try await session.data(for: request)
        // An upgraded server may have no record yet. Reuse existing registration,
        // at most once per five minutes, without changing subscription semantics.
        if (response as? HTTPURLResponse)?.statusCode == 401,
           Date().timeIntervalSince(lastRegistrationAttempt) >= 300 {
            lastRegistrationAttempt = Date()
            try await BTSubscriptionNetwork.shared.refresh()
            return
        }
        guard data.count <= 65536, (response as? HTTPURLResponse)?.statusCode == 200 else { throw BTSubscriptionError.damagedIdentity }
        let ack: Ack = try BTSubscriptionVerifier.decode(data)
        guard ack.kind == "activity-ack", ack.nonce == nonce, ack.deviceID == identity.deviceID,
              abs(ack.issuedAt - Date().timeIntervalSince1970) < 300 else { throw BTSubscriptionError.damagedIdentity }
    }
}
