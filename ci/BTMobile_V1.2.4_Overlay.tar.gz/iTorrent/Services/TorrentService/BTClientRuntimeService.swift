import UIKit
import MvvmFoundation

// Read-only observation of the existing core. No session restart, pause, settings
// update, wake lock or background entitlement is introduced by this service.
@MainActor final class BTClientRuntimeService {
    static let shared = BTClientRuntimeService()
    @Injected private var trackers: TrackersListService
    private var timer: Timer?
    private var busy = false
    private var lastAttempt = Date.distantPast

    func start() {
        if timer == nil {
            let timer = Timer(timeInterval: 60, repeats: true) { _ in
                Task { @MainActor in await Self.shared.synchronize() }
            }
            RunLoop.main.add(timer, forMode: .common)
            self.timer = timer
        }
        Task { await synchronize() }
    }
    func enteredBackground() {
        Task {
            try? await Task.sleep(for: .milliseconds(500))
            await synchronize()
        }
    }
    private func synchronize() async {
        guard !busy, Date().timeIntervalSince(lastAttempt) >= 5 else { return }
        busy = true; lastAttempt = Date()
        defer { busy = false }
        do {
            let config = try await BTClientRuntimeNetwork.shared.configuration()
            trackers.applyManagedTrackers(config.trackers, revision: config.trackersRevision)
        } catch { /* Offline or old server: retain last valid trackers. */ }
        // Gather current snapshots after the network await, not a pre-suspension sample.
        var downloading = 0, seeding = 0, metadata = 0, checking = 0
        var downloadRate: UInt64 = 0, uploadRate: UInt64 = 0
        for handle in TorrentService.shared.torrents.values {
            let s = handle.snapshot
            guard !s.isPaused, !s.isStorageMissing else { continue }
            switch s.friendlyState {
            case .downloading: downloading += 1
            case .seeding: seeding += 1
            case .downloadingMetadata: metadata += 1
            case .checkingFiles, .checkingResumeData: checking += 1
            default: break
            }
            downloadRate &+= UInt64(max(0, s.downloadRate))
            uploadRate &+= UInt64(max(0, s.uploadRate))
        }
        let activity = BTClientActivity(platform: "ios",
            version: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.2.4",
            foreground: UIApplication.shared.applicationState == .active,
            downloading: downloading, seeding: seeding, metadata: metadata, checking: checking,
            downloadRate: downloadRate, uploadRate: uploadRate)
        try? await BTClientRuntimeNetwork.shared.report(activity)
    }
}
