//
//  TrackersListService.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 16/09/2024.
//

import Foundation
import LibTorrent
import MvvmFoundation
import Combine

extension TrackersListService.ListState {
    enum Status: Codable {
        case updated
        case error
    }

    enum Source: Identifiable, Codable, Hashable {
        var id: Self { self }

        case remote(URL)
        case local(UUID)
    }
}

extension TrackersListService {
    struct ListState: Identifiable, Codable {
        var id: Source { source }

        var source: Source
        var title: String
        var status: Status
        var trackers: [String]
    }
}

class TrackersListService: @unchecked Sendable {
    let trackerSources: CurrentValueSubject<[ListState.Source: ListState], Never>

    init() {
        var sources = (try? Self.load()) ?? [:]
        let defaults = UserDefaults.standard
        if !defaults.bool(forKey: "btmobileV124DefaultTrackers") {
            let source = Self.managedSource
            // Preserve addresses a user added to the old default list as a separate local source.
            let extras = sources[source]?.trackers.filter { !Self.legacyTrackers.contains($0) } ?? []
            if !extras.isEmpty {
                let custom = ListState.Source.local(UUID(uuidString: "B7124000-0000-4000-8000-000000000002")!)
                sources[custom] = ListState(source: custom, title: "原默认列表自定义 Tracker", status: .updated, trackers: extras)
            }
            sources[source] = ListState(source: source, title: "BTmobile 服务端 Tracker", status: .updated, trackers: Self.bundledTrackers)
            if (try? Self.safe(sources)) != nil { defaults.set(true, forKey: "btmobileV124DefaultTrackers") }
        }
        trackerSources = CurrentValueSubject<[ListState.Source: ListState], Never>(sources)

        trackerSources.sink { urls in
            try? Self.safe(urls)
        }.store(in: disposeBag)

        Task { await Self.refresh(trackerSources.value) }
    }

    private let disposeBag = DisposeBag()
    private static let key = "TrackersListServiceDataKey"
    private static let managedSource = ListState.Source.local(UUID(uuidString: "B7120000-0000-4000-8000-000000000008")!)
    private static let legacyTrackers = [
        "http://tracker.linkyou.win:6969/announce",
        "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://retracker.hotplug.ru:2710/announce",
        "udp://tracker.birkenwald.de:6969/announce",
        "udp://tracker.tryhackx.org:6969/announce",
        "udp://tracker.fnix.net:6969/announce",
        "udp://www.torrent.eu.org:451/announce"
    ]
    static let bundledTrackers = [
        "http://tracker1.linkyou.win:6969/announce",
        "http://tracker2.linkyou.win:6969/announce",
        "http://tracker2v4.linkyou.win:6969/announce",
        "http://tracker2v6.linkyou.win:6969/announce",
        "udp://open.stealth.si:80/announce",
        "udp://retracker.hotplug.ru:2710/announce",
        "udp://tracker.torrent.eu.org:451/announce",
        "udp://tracker.tryhackx.org:6969/announce",
        "udp://www.torrent.eu.org:451/announce"
    ]

    // Called on main after pinned-key validation. Only the managed list changes;
    // user sources, private torrents and the automatic-add preference remain untouched.
    func applyManagedTrackers(_ trackers: [String], revision: Int) {
        let defaults = UserDefaults.standard
        guard revision > 0, revision >= defaults.integer(forKey: "btmobileManagedTrackersRevision") else { return }
        if trackerSources.value[Self.managedSource]?.trackers != trackers {
            trackerSources.value[Self.managedSource] = ListState(source: Self.managedSource,
                title: "BTmobile 服务端 Tracker", status: .updated, trackers: trackers)
        }
        defaults.set(revision, forKey: "btmobileManagedTrackersRevision")
    }
}

extension TrackersListService {
    func addTrackersSource(_ url: URL, title: String) async throws {
        let (data, _) = try await URLSession.shared.data(from: url)
        let trackers = String(data: data, encoding: .utf8)?.components(separatedBy: "\n").filter { !$0.isEmpty } ?? []
        let listState = ListState(source: .remote(url), title: title, status: .updated, trackers: trackers)
        trackerSources.value[listState.source] = listState
    }

    func createLocalSource(title: String) {
        let listState: TrackersListService.ListState = .init(source: .local(UUID()), title: title, status: .updated, trackers: [])
        trackerSources.value[listState.source] = listState
    }

    func addAllTrackers(to torrent: TorrentHandle) {
        guard !torrent.isPrivate else { return }
        var seen = Set<String>()
        trackerSources.value.values.forEach { state in
            state.trackers.forEach { urlString in
                guard let url = URL(string: urlString), seen.insert(url.absoluteString).inserted else { return }
                torrent.addTracker(url.absoluteString)
            }
        }
    }
}

private extension TrackersListService {
    static func refresh(_ oldValues: [ListState.Source: ListState]) async -> [ListState.Source: ListState] {
        await withTaskGroup(of: ListState.self, returning: [ListState.Source: ListState].self) { taskGroup in
            oldValues.values.forEach { value in
                guard case let .remote(url) = value.source else { return }
                taskGroup.addTask {
                    do {
                        let (data, _) = try await URLSession.shared.data(from: url)
                        let trackers = String(data: data, encoding: .utf8)?.components(separatedBy: "\n").filter { !$0.isEmpty } ?? []
                        return ListState(source: value.source, title: value.title, status: .updated, trackers: trackers)
                    } catch {
                        return .init(source: value.source, title: value.title, status: .error, trackers: value.trackers)
                    }
                }
            }

            return await taskGroup.reduce(into: [ListState.Source: ListState]()) { partialResult, state in
                partialResult[state.source] = state
            }
        }
    }
}

private extension TrackersListService {
    static func load() throws -> [ListState.Source: ListState] {
        guard let data = UserDefaults.standard.data(forKey: key)
        else { return [:] }
        return try JSONDecoder().decode([ListState.Source: ListState].self, from: data)
    }

    static func safe(_ urls: [ListState.Source: ListState]) throws {
        let data = try JSONEncoder().encode(urls)
        UserDefaults.standard.set(data, forKey: key)
    }
}
