//
//  TorrentService.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 29/10/2023.
//

import Combine
@preconcurrency import LibTorrent
import MvvmFoundation
import UIKit
#if canImport(FirebaseCrashlytics)
import FirebaseCrashlytics
#endif

extension TorrentService {
    struct TorrentUpdateModel {
        let oldSnapshot: TorrentHandle.Snapshot
        let handle: TorrentHandle?
    }
}

class TorrentService: @unchecked Sendable, ObservableObject {
    @Published var torrents: [TorrentHashes: TorrentHandle] = [:]
    var updateNotifier = PassthroughSubject<TorrentUpdateModel, Never>()

    static let shared = TorrentService()
    static var version: String { Version.libtorrentVersion }

    init() { setup() }

    #if os(tvOS)
    static let downloadPath: URL = try! FileManager.default.url(for: .cachesDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    #else
    static let downloadPath: URL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    #endif
    private static let configurationPath: URL = {
        try! FileManager.default
            .url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            .appending(path: "config")
    }()
    private static let preparedConfigurationPath = TorrentMigration.prepareConfiguration(
        legacyURL: downloadPath.appending(path: "config"),
        destinationURL: configurationPath
    )
    static let torrentPath: URL = preparedConfigurationPath
    static let fastResumePath: URL = preparedConfigurationPath
    static let metadataPath: URL = preparedConfigurationPath

    private lazy var session: Session = {
        configureOpenSSLCerts()
        var settings = Session.Settings()
        print("Working directory: \(Self.downloadPath.path())")
        return .init(Self.downloadPath, torrentsPath: Self.torrentPath, fastResumePath: Self.fastResumePath, settings: .fromPreferences(with: []), storages: PreferencesStorage.shared.allStorageScopes)
    }()

    private let disposeBag = DisposeBag()
    private let foregroundRecoveryLock = NSLock()
    private var needsForegroundRecovery = false

    @Injected private var network: NetworkMonitoringService
    @Injected private var preferences: PreferencesStorage
    @Injected private var trackersListService: TrackersListService
}

extension TorrentService {
    var storages: [UUID: StorageModel] {
        get { session.storages }
        set { session.storages = newValue }
    }

    func checkTorrentExists(with hash: TorrentHashes) -> Bool {
        session.torrentsMap[hash] != nil
    }

    @discardableResult
    func addTorrent(by file: Downloadable, at storage: UUID? = nil) -> Bool {
        // A magnet may be the first action after iOS has kept the process
        // suspended for hours. Recover before adding it so the new torrent is
        // not attached to a session whose network sockets are already stale.
        recoverAfterForeground()

        guard session.torrentsMap[file.infoHashes] == nil
        else { return false }

        session.addTorrent(file, to: storage ?? preferences.effectiveDefaultStorage)
        return true
    }

    func removeTorrent(by infoHashes: TorrentHashes, deleteFiles: Bool) {
        guard let handle = session.torrentsMap[infoHashes]
        else { return }

        let oldSnapshot = handle.snapshot
        handle.deleteMetadata()
        session.removeTorrent(handle, deleteFiles: deleteFiles)
        let updateModel = TorrentService.TorrentUpdateModel(oldSnapshot: oldSnapshot, handle: nil)
        updateNotifier.send(updateModel)
    }

    func updateSettings(_ settings: Session.Settings) {
        session.settings = settings
    }

    func refreshStorage(_ storage: StorageModel) -> Bool {
        if preferences.btMobileManagedStorageScopes[storage.uuid] == nil {
            guard storage.resolveSequrityScopes() else { return false }
        } else {
            storage.resolved = FileManager.default.fileExists(atPath: storage.url.path)
            storage.allowed = storage.resolved
            guard storage.allowed else { return false }
        }

        let handles = torrents.values.filter { $0.storageUUID == storage.uuid }
        handles.forEach { $0.reload() }
        return true
    }

    func markEnteringBackground() {
        foregroundRecoveryLock.lock()
        needsForegroundRecovery = true
        foregroundRecoveryLock.unlock()
    }

    func recoverAfterForeground() {
        foregroundRecoveryLock.lock()
        guard needsForegroundRecovery else {
            foregroundRecoveryLock.unlock()
            return
        }
        needsForegroundRecovery = false
        foregroundRecoveryLock.unlock()

        resolveStorageScopes()
        session.storages = preferences.allStorageScopes

        // Reapply the current interface list first, then explicitly reopen
        // sockets. Session.resume() alone cannot repair descriptors that iOS
        // invalidated during suspension.
        session.settings = Session.Settings.fromPreferences(with: network.availableInterfaces)
        session.resume()
        session.reopenNetworkSockets()

        // Preserve intentional user pauses while clearing transient network
        // errors from torrents that were active before suspension.
        session.torrentsMap.values
            .filter { !$0.snapshot.isPaused && !$0.snapshot.isStorageMissing }
            .forEach {
                $0.clearError()
                $0.resume()
            }

        session.reannounceToAllTrackers()
    }
}

// MARK: - SessionDelegate
extension TorrentService: SessionDelegate {
    func torrentManager(_ manager: Session, didAddTorrent torrent: TorrentHandle) {
        torrent.prepareToAdd(into: self)
        torrents[torrent.snapshot.infoHashes] = torrent

        // Add trackers from torrent list service if needed
        if preferences.isTrackersAutoaddingEnabled, !torrent.isPrivate {
            trackersListService.addAllTrackers(to: torrent)
        }
    }

    func torrentManager(_ manager: Session, didRemoveTorrentWithHash hashesData: TorrentHashes) {
        guard let torrent = torrents[hashesData]
        else { return }

        torrent.removePublisher.send(torrent)
        torrents[hashesData] = nil
    }

    func torrentManager(_ manager: Session, didReceiveUpdateForTorrent torrent: TorrentHandle) {
        torrent.__unthrottledUpdatePublisher.send()
    }

    func torrentManager(_ manager: Session, didErrorOccur error: Error) {
        #if canImport(FirebaseCrashlytics)
        Crashlytics.crashlytics().record(error: error)
        #else
        print("LibTorrent error: \(error)")
        #endif
    }
}

private extension TorrentService {
    func setup() {
        // Managed downloads default to Documents/BTmobile on a fresh install,
        // while preserving an existing external default storage.
        BTFileManagerService.shared.prepareDefaultDownloadDirectoryIfNeeded()

        // Resolve storage scopes, so Core will be able to restore states
        resolveStorageScopes()

        // Pause the core, so it will not deadlock app on making first snapshots
        session.pause()
        torrents = session.torrentsMap.mapValues { torrent in
            torrent.prepareToAdd(into: self)
            return torrent
        }
        // After initialization is done we could resume core
        session.resume()
        session.add(self)

        disposeBag.bind {
            Publishers.combineLatest(
                preferences.settingsUpdatePublisher,
                network.$availableInterfaces
            ) { _, interfaces in
                interfaces
            }
            .sink { [unowned self] interfaces in
                DispatchQueue.main.async { [self] in // Need delay to complete settings apply
                    session.settings = Session.Settings.fromPreferences(with: interfaces)
                    session.reopenNetworkSockets()
                    session.reannounceToAllTrackers()
                }
            }

            Publishers.CombineLatest(
                preferences.$storageScopes,
                preferences.$btMobileManagedStorageScopes
            )
            .sink { [unowned self] values in
                let (external, managed) = values
                session.storages = external.merging(managed) { external, _ in external }
            }
        }
    }

    func resolveStorageScopes() {
        // Existing external security-scoped storages retain their permissions.
        preferences.storageScopes.values.forEach { scope in
            scope.resolveSequrityScopes()

            if !scope.allowed, preferences.defaultStorage == scope.uuid {
                preferences.defaultStorage = nil
            }
        }

        // BT Mobile managed storages are inside the app sandbox and do not
        // require security-scoped access.
        preferences.btMobileManagedStorageScopes.values.forEach { scope in
            scope.resolved = FileManager.default.fileExists(atPath: scope.url.path)
            scope.allowed = scope.resolved
            if !scope.allowed, preferences.btMobileManagedDefaultStorage == scope.uuid {
                preferences.btMobileManagedDefaultStorage = nil
            }
        }
    }
}

private extension TorrentHandle {
    func prepareToAdd(into torrentServide: TorrentService) {
        updateSnapshot()
        observableSnapshot.update()

        disposeBag.bind {
            __unthrottledUpdatePublisher
                .throttle(for: .seconds(0.1), scheduler: .main, latest: true)
                .receive(on: DispatchQueue.global(qos: .userInitiated))
                .sink { [weak self, weak torrentServide] in
                    guard let self, let torrentServide else { return }

                    _ = metadata // trigger to generate
                    let oldSnapshot = snapshot
                    updateSnapshot()
                    observableSnapshot.update()
                    let updateModel = TorrentService.TorrentUpdateModel(oldSnapshot: oldSnapshot, handle: self)

                    Task { @MainActor in
                        torrentServide.updateNotifier.send(updateModel)
                        self.__updatePublisher.send(updateModel)
                    }
                }
        }
    }
}

private extension TorrentService {
    func configureOpenSSLCerts() {
        guard let caPath = Bundle.main.path(forResource: "cacert", ofType: "pem") else {
            assertionFailure("cacert.pem not found in bundle")
            return
        }

        // This is the important line:
        setenv("SSL_CERT_FILE", caPath, 1)
    }
}
