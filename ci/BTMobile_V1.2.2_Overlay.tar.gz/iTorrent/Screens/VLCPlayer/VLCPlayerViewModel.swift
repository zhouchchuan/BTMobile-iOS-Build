//
//  VLCPlayerViewModel.swift
//  iTorrent
//
//  Created by Даниил Виноградов on 21.03.2026.
//

import Foundation
import MvvmFoundation
import LibTorrent
import SwiftVLC

extension VLCPlayerViewModel {
    struct Config {
        let url: URL
        let torrentPair: (handle: TorrentHandle, fileIndex: Int)?
    }
}

class VLCPlayerViewModel: BaseViewModelWith<VLCPlayerViewModel.Config>, ObservableObject {
    private static let supportedMediaExtensions: Set<String> = [
        // Video containers
        "mp4", "m4v", "mkv", "webm", "avi", "mov", "ts", "m2ts", "mts",
        "flv", "3gp", "mpg", "mpeg", "vob", "wmv", "asf", "ogv", "rm", "rmvb",
        // Audio containers and elementary streams
        "mp3", "aac", "flac", "wav", "ogg", "m4a", "opus", "wma", "aiff", "aif",
        "amr", "mid", "midi", "ac3", "eac3", "dts", "mka"
    ]

    private(set) var url: URL!
    private(set) var torrentPair: (handle: TorrentHandle, fileIndex: Int)?

    @Published var showOverlay: Bool = true
    @Published var isManualFullscreen: Bool = false
    @Published var segmentedProgress: [Double]?
    private var playbackTeardownHandler: (() -> Void)?
    private var lastStreamingBucket: Int?
    @Published var streamingMessage: String?
    @Published var streamingFailed = false
    private var streamingSource: BTTorrentHTTPStream?

    var isStreamingPlayback: Bool { streamingSource != nil }

    func playbackURL() throws -> URL {
        if streamingSource == nil, let torrentPair {
            let files = torrentPair.handle.snapshot.files
            guard files.indices.contains(torrentPair.fileIndex) else {
                throw NSError(domain: "BTMobile.Stream", code: 2,
                              userInfo: [NSLocalizedDescriptionKey: "任务文件已不可用"])
            }
            let file = files[torrentPair.fileIndex]
            if file.downloaded < file.size {
                streamingSource = try BTTorrentHTTPStream(fileURL: url, handle: torrentPair.handle,
                    fileIndex: torrentPair.fileIndex) { [weak self] status in
                    guard let self else { return }
                    switch status {
                    case .ready: self.streamingMessage = nil; self.streamingFailed = false
                    case .waiting: self.streamingMessage = "正在缓冲目标位置，等待下载分片…"; self.showOverlay = true
                    case .paused: self.streamingMessage = "BT任务已暂停，已下载内容仍可播放；请恢复任务以继续缓冲"; self.showOverlay = true
                    case .failed(let message): self.streamingMessage = message; self.streamingFailed = true; self.showOverlay = true
                    }
                }
            }
        }
        streamingFailed = false
        streamingMessage = streamingSource == nil ? nil : "正在准备播放数据…"
        return streamingSource?.nextURL() ?? url
    }

#if !os(visionOS)
    @Published var pipController: PiPController?
#endif

    override func prepare(with model: Config) {
        self.url = model.url
        self.torrentPair = model.torrentPair
        binding()
    }

    private func binding() {
        guard let torrentPair else { return }
        refreshSegmentedProgress()
        disposeBag.bind {
            torrentPair.handle.updatePublisher.sink { [weak self] update in
                guard let self else { return }
                refreshSegmentedProgress()
            }
        }
    }

    private func refreshSegmentedProgress() {
        guard let torrentPair else { return }
        let file = torrentPair.handle.snapshot.files[torrentPair.fileIndex]
        segmentedProgress = file.segmentedProgress
    }

    static func validateURL(_ url: URL) -> Bool {
        guard url.isFileURL else { return false }
        guard url.isFileURL, (try? url.checkResourceIsReachable()) == true else { return false }

        let resourceValues = try? url.resourceValues(forKeys: [.isRegularFileKey])
        return resourceValues?.isRegularFile != false
    }

    static func isSupportedMediaURL(_ url: URL) -> Bool {
        supportedMediaExtensions.contains(url.pathExtension.lowercased())
    }

    static func canOpenInVLC(_ url: URL, timeoutMilliseconds: Int32 = 3_000) async -> Media? {
        guard validateURL(url), isSupportedMediaURL(url), let media = try? Media(url: url) else {
            return nil
        }

        do {
            let metadata = try await media.parse(timeout: .milliseconds(Int64(timeoutMilliseconds)))
            if !media.tracks().isEmpty { return media }
            if (metadata.duration ?? media.duration)?.milliseconds ?? 0 > 0 { return media }
        } catch {}

        // A partially downloaded video can be valid even when metadata parsing
        // times out. The VLC player and libtorrent piece priorities will handle
        // buffering once playback begins.
        return media
    }

    static func canOpenInVLCSync(_ url: URL, timeoutMilliseconds: Int32 = 100) -> Media? {
        guard validateURL(url), isSupportedMediaURL(url), let media = try? Media(url: url) else {
            return nil
        }
        return media
    }

    func registerPlaybackTeardownHandler(_ handler: @escaping () -> Void) {
        playbackTeardownHandler = handler
    }

    func requestPlaybackTeardown() {
        let handler = playbackTeardownHandler
        playbackTeardownHandler = nil
        handler?()
    }

    func clearPlaybackTeardownHandler() {
        playbackTeardownHandler = nil
    }

    /// Keeps a short libtorrent deadline window in front of VLC's read head.
    /// Updates are bucketed so ordinary playback events do not flood the
    /// torrent session with duplicate piece-priority requests.
    func prioritizeStreaming(playbackTime: TimeInterval, duration: TimeInterval, force: Bool = false) {
        // Incomplete media is now scheduled by actual HTTP byte reads, never by time ratio.
        guard streamingSource == nil, let torrentPair, duration > 0 else { return }
        let file = torrentPair.handle.snapshot.files[torrentPair.fileIndex]
        guard file.downloaded < file.size else { return }

        let progress = min(max(playbackTime / duration, 0), 1)
        let bucket = Int((progress * 200).rounded(.down))
        guard force || bucket != lastStreamingBucket else { return }

        lastStreamingBucket = bucket
        torrentPair.handle.prioritizeStreaming(
            fileIndex: torrentPair.fileIndex,
            progress: progress,
            windowPieceCount: 64
        )
    }

    func finishStreamingPlayback() {
        streamingSource?.stop()
        streamingSource = nil
        streamingMessage = nil
        streamingFailed = false
        guard let torrentPair else { return }
        lastStreamingBucket = nil
        torrentPair.handle.clearStreamingPriorities()
    }
}
