import Foundation
import GCDWebServers
import LibTorrent

/// Private per-player byte-range source. Never exposes a directory or listens on the LAN.
final class BTTorrentHTTPStream: @unchecked Sendable {
    enum Status: Equatable {
        case ready, waiting, paused
        case failed(String)
    }
    private let queue = DispatchQueue(label: "BTMobile.stream.read", qos: .userInitiated)
    private let server = GCDWebServer()
    private let handle: TorrentHandle
    private let fileIndex: Int
    private let fileURL: URL
    private let size: Int64
    private let token = UUID().uuidString
    private var generation = 0
    private var running = true
    private var newestReader = UUID()
    private var lastStatus: Status?
    private let notify: (Status) -> Void
    private let waitTimeout: TimeInterval

    private final class Reader {
        let id = UUID()
        let generation: Int
        let end: Int64
        var offset: Int64
        var file: FileHandle?
        var cancelled = false
        var started = false
        var waitingSince: TimeInterval?
        init(range: BTStreamRange, generation: Int) {
            offset = range.start; end = range.end; self.generation = generation
        }
        deinit { try? file?.close() }
    }

    init(fileURL: URL, handle: TorrentHandle, fileIndex: Int, waitTimeout: TimeInterval = 90,
         notify: @escaping (Status) -> Void) throws {
        self.waitTimeout = waitTimeout
        self.fileURL = fileURL; self.handle = handle; self.fileIndex = fileIndex; self.notify = notify
        size = handle.streamingFileSize(fileIndex: fileIndex)
        guard size > 0 else { throw Self.error("任务文件信息暂不可用") }
        for method in ["GET", "HEAD"] {
            server.addDefaultHandler(forMethod: method, request: GCDWebServerRequest.self) { [weak self] request in
                guard let self else { return GCDWebServerResponse(statusCode: 410) }
                return self.queue.sync { self.response(request) }
            }
        }
        try server.start(options: [
            GCDWebServerOption_Port: 0,
            GCDWebServerOption_BindToLocalhost: true,
            GCDWebServerOption_AutomaticallyMapHEADToGET: true,
            GCDWebServerOption_AutomaticallySuspendInBackground: false
        ])
    }

    private var path: String { "/\(token)/\(generation)/video.\(fileURL.pathExtension.lowercased())" }

    /// A fresh URL cancels old reads before VLC is stopped/reloaded for a user seek.
    func nextURL() -> URL {
        queue.sync {
            generation += 1
            newestReader = UUID()
            lastStatus = nil
            handle.resetStreamingReadWindow()
            return URL(string: "http://127.0.0.1:\(server.port)\(path)")!
        }
    }

    func stop() {
        queue.sync {
            running = false
            generation += 1
            newestReader = UUID()
            handle.resetStreamingReadWindow()
        }
        server.stop()
    }

    private func response(_ request: GCDWebServerRequest) -> GCDWebServerResponse {
        guard running, request.path == path else { return GCDWebServerResponse(statusCode: 404) }
        // Do not accept a DNS-rebinding request from a web page or another host.
        let host = request.headers.first { $0.key.lowercased() == "host" }?.value
        guard host == "127.0.0.1:\(server.port)" else { return GCDWebServerResponse(statusCode: 403) }
        let header = request.headers.first { $0.key.lowercased() == "range" }?.value
        guard let range = BTStreamRange.parse(header, size: size) else {
            let response = GCDWebServerResponse(statusCode: 416)
            response.setValue("bytes */\(size)", forAdditionalHeader: "Content-Range")
            return response
        }
        let response: GCDWebServerResponse
        if request.method == "HEAD" {
            response = GCDWebServerResponse(statusCode: range.partial ? 206 : 200)
        } else {
            let reader = Reader(range: range, generation: generation)
            let stream = BTClosingStreamResponse(contentType: "application/octet-stream", asyncStreamBlock: { [weak self] completion in
                guard let self else { completion(nil, Self.error("播放已结束")); return }
                self.queue.async { self.read(reader, completion: completion) }
            })
            stream.onClose = { [weak self] in
                self?.queue.async { reader.cancelled = true; try? reader.file?.close(); reader.file = nil }
            }
            response = stream
        }
        response.statusCode = range.partial ? 206 : 200
        response.contentType = "application/octet-stream"
        response.contentLength = UInt(range.length)
        response.setValue("bytes", forAdditionalHeader: "Accept-Ranges")
        response.setValue("no-store", forAdditionalHeader: "Cache-Control")
        response.setValue("close", forAdditionalHeader: "Connection")
        if range.partial { response.setValue("bytes \(range.start)-\(range.end)/\(size)", forAdditionalHeader: "Content-Range") }
        return response
    }

    private func report(_ status: Status, generation expected: Int) {
        guard running, generation == expected, status != lastStatus else { return }
        lastStatus = status
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let valid = self.queue.sync { self.running && self.generation == expected }
            if valid { self.notify(status) }
        }
    }

    private func read(_ reader: Reader, completion: @escaping GCDWebServerBodyReaderCompletionBlock) {
        guard running, reader.generation == generation, !reader.cancelled else {
            completion(nil, Self.error("已取消旧的播放读取")); return
        }
        if !reader.started {
            reader.started = true
            newestReader = reader.id
            handle.resetStreamingReadWindow()
        }
        guard reader.id == newestReader else { completion(nil, Self.error("已有新的读取请求")); return }
        guard reader.offset <= reader.end else { completion(Data(), nil); return }
        let count = Int(min(64 * 1024, reader.end - reader.offset + 1))
        let state = handle.prepareStreamingRead(fileIndex: fileIndex, offset: reader.offset, length: count)
        if state == 0 || state == 2 {
            let now = ProcessInfo.processInfo.systemUptime
            if reader.waitingSince == nil { reader.waitingSince = now }
            guard now - reader.waitingSince! < waitTimeout else {
                let message = state == 2 ? "BT任务已暂停，请恢复任务后重试" : "目标分片暂未下载完成，请检查资源节点后重试"
                report(.failed(message), generation: reader.generation)
                completion(nil, Self.error(message)); return
            }
            report(state == 2 ? .paused : .waiting, generation: reader.generation)
            queue.asyncAfter(deadline: .now() + .milliseconds(150)) { self.read(reader, completion: completion) }
            return
        }
        guard state == 1 else {
            let message = "BT任务或文件已不可用，请检查任务状态"
            report(.failed(message), generation: reader.generation)
            completion(nil, Self.error(message)); return
        }
        do {
            if reader.file == nil { reader.file = try FileHandle(forReadingFrom: fileURL) }
            try reader.file!.seek(toOffset: UInt64(reader.offset))
            let data = try reader.file!.read(upToCount: count) ?? Data()
            guard data.count == count else { throw Self.error("视频文件读取不完整，请检查下载文件") }
            reader.offset += Int64(data.count)
            reader.waitingSince = nil
            report(.ready, generation: reader.generation)
            completion(data, nil)
        } catch {
            report(.failed("视频读取失败，请重试"), generation: reader.generation)
            completion(nil, error)
        }
    }

    private static func error(_ text: String) -> NSError {
        NSError(domain: "BTMobile.Stream", code: 1, userInfo: [NSLocalizedDescriptionKey: text])
    }
}

private final class BTClosingStreamResponse: GCDWebServerStreamedResponse {
    var onClose: (() -> Void)?
    override func close() { onClose?(); onClose = nil; super.close() }
}
