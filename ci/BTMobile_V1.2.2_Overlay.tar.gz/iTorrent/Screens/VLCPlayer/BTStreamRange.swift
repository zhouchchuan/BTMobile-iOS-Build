import Foundation

/// One inclusive HTTP byte range. Multi-range requests are deliberately rejected.
struct BTStreamRange: Equatable {
    let start: Int64
    let end: Int64
    let partial: Bool
    var length: Int64 { end - start + 1 }

    static func parse(_ header: String?, size: Int64) -> BTStreamRange? {
        guard size > 0 else { return nil }
        guard let header else { return .init(start: 0, end: size - 1, partial: false) }
        let value = header.trimmingCharacters(in: .whitespacesAndNewlines)
        guard value.lowercased().hasPrefix("bytes="), !value.contains(",") else { return nil }
        let parts = value.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        func number(_ s: Substring) -> Int64? {
            guard !s.isEmpty, s.allSatisfy({ $0 >= "0" && $0 <= "9" }) else { return nil }
            return Int64(s)
        }
        if parts[0].isEmpty {
            guard let suffix = number(parts[1]), suffix > 0 else { return nil }
            return .init(start: max(0, size - suffix), end: size - 1, partial: true)
        }
        guard let start = number(parts[0]), start < size else { return nil }
        let end: Int64
        if parts[1].isEmpty { end = size - 1 }
        else {
            guard let requested = number(parts[1]), requested >= start else { return nil }
            end = min(requested, size - 1)
        }
        return .init(start: start, end: end, partial: true)
    }
}
