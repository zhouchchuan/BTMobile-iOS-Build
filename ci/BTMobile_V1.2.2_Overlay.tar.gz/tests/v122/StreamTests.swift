import Foundation
import LibTorrent

@main struct StreamTests {
    @MainActor static func main() async throws {
        func check(_ value: Bool, _ message: String) { precondition(value, message) }
        let invalid = ["bytes=", "bytes=-0", "bytes=1000-", "bytes=50-4", "bytes=0-1,5-6", "bytes=+1-", "bytes=9223372036854775808-", "bytes=１-", "items=0-1"]
        for header in invalid { check(BTStreamRange.parse(header, size: 1000) == nil, "Reject \(header)") }
        check(BTStreamRange.parse(nil, size: 0) == nil, "Empty file")
        check(BTStreamRange.parse("bytes=-9999", size: 1000)?.length == 1000, "Large suffix")
        check(BTStreamRange.parse("bytes=7-9999", size: 1000)?.end == 999, "Clamped end")
        let data = Data((0..<200000).map { UInt8($0 % 251) })
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".mkv")
        try data.write(to: file)
        defer { try? FileManager.default.removeItem(at: file) }
        let handle = TorrentHandle(size: Int64(data.count))
        var statuses: [BTTorrentHTTPStream.Status] = []
        let source = try BTTorrentHTTPStream(fileURL: file, handle: handle, fileIndex: 0, waitTimeout: 1) { statuses.append($0) }
        defer { source.stop() }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 5
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        func request(_ url: URL, _ range: String? = nil, method: String = "GET") async throws -> (Data, HTTPURLResponse) {
            var req = URLRequest(url: url); req.httpMethod = method
            if let range { req.setValue(range, forHTTPHeaderField: "Range") }
            let (body, response) = try await session.data(for: req)
            return (body, response as! HTTPURLResponse)
        }
        let url = source.nextURL()
        let all = try await request(url)
        check(all.0 == data && all.1.statusCode == 200, "Complete GET exact bytes")
        let partial = try await request(url, "bytes=65530-65600")
        check(partial.0 == data.subdata(in: 65530..<65601) && partial.1.statusCode == 206, "Cross-boundary range")
        check(partial.1.value(forHTTPHeaderField: "Content-Range") == "bytes 65530-65600/200000", "Content-Range")
        let suffix = try await request(url, "bytes=-29")
        check(suffix.0 == data.suffix(29), "Tail index")
        let open = try await request(url, "bytes=199991-")
        check(open.0 == data.suffix(9), "Open-ended range")
        let head = try await request(url, method: "HEAD")
        check(head.0.isEmpty && head.1.value(forHTTPHeaderField: "Content-Length") == "200000", "HEAD length")
        let bad = try await request(url, "bytes=200000-")
        check(bad.1.statusCode == 416, "Unsatisfiable")
        let hidden = try await request(url.deletingLastPathComponent())
        check(hidden.1.statusCode == 404, "No directory browsing")
        handle.setState(0)
        let before = handle.readCalls
        let waiting = Task { try await request(url, "bytes=60000-60100") }
        try await Task.sleep(nanoseconds: 350_000_000)
        check(handle.readCalls > before && statuses.contains(.waiting), "Missing pieces wait")
        handle.setState(1)
        let resumed = try await waiting.value
        check(resumed.0 == data.subdata(in: 60000..<60101), "No zero-filled sparse bytes")
        handle.setState(0)
        let obsolete = Task { try await request(url, "bytes=70000-70100") }
        try await Task.sleep(nanoseconds: 200_000_000)
        let next = source.nextURL()
        do { let result = try await obsolete.value; check(result.1.statusCode == 404, "Old generation cannot produce data") } catch {}
        let stale = try await request(url)
        check(stale.1.statusCode == 404, "Old URL invalid")
        handle.setState(2)
        do { _ = try await request(next, "bytes=1-100"); preconditionFailure("Paused timeout must not be EOF") } catch {}
        check(statuses.contains(.paused), "Paused feedback; no forced resume")
        handle.setState(1)
        let retry = try await request(source.nextURL(), "bytes=1-100")
        check(retry.0 == data.subdata(in: 1..<101), "Retry works")
        print("PASS: production range parsing, HTTP headers, verified reads, buffering, stale-seek cancellation, pause and retry")
    }
}
