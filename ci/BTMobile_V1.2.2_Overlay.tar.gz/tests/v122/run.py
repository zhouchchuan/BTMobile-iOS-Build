"""Exercise production HTTP reader against real GCDWebServer and a deterministic BT stub."""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
tests = Path(__file__).parent
native = (root / 'Submodules/LibTorrent-Swift/LibTorrent/Core/TorrentHandle/TorrentHandle.mm').read_text()
body = native.split('- (NSInteger)prepareStreamingReadAtIndex:', 1)[1].split('- (void)addTracker:', 1)[0]
assert 'have_piece' in body and 'map_file(index, offset' in body
assert 'handle.resume()' not in body and 'clear_piece_deadlines' not in body
assert 'size - offset' in body and 'status.errc' in body
vc = (root / 'iTorrent/Screens/VLCPlayer/VLCPlayerViewController.swift').read_text()
assert 'if !fast { seekStreaming(to: clampedTime) }' in vc
assert 'generation == streamingSeekGeneration' in vc
assert 'configureChineseSubtitleFonts(for: media)' in vc
with tempfile.TemporaryDirectory(prefix='bt-stream-tests-') as folder:
    tmp = Path(folder)
    (tmp / 'Sources/LibTorrent').mkdir(parents=True)
    (tmp / 'Sources/StreamTests').mkdir(parents=True)
    package = '''// swift-tools-version:5.9
import PackageDescription
let package = Package(name: "StreamTests", platforms: [.macOS(.v12)],
 dependencies: [.package(path: %s)], targets: [
 .target(name: "LibTorrent"),
 .executableTarget(name: "StreamTests", dependencies: ["LibTorrent", .product(name: "GCDWebServers", package: "GCDWebServer")])
 ])
''' % json.dumps(str(root / 'Submodules/GCDWebServer'))
    (tmp / 'Package.swift').write_text(package)
    shutil.copyfile(tests / 'TorrentStub.swift', tmp / 'Sources/LibTorrent/TorrentStub.swift')
    shutil.copyfile(tests / 'StreamTests.swift', tmp / 'Sources/StreamTests/StreamTests.swift')
    for name in ['BTStreamRange.swift', 'BTTorrentHTTPStream.swift']:
        shutil.copyfile(root / 'iTorrent/Screens/VLCPlayer' / name, tmp / 'Sources/StreamTests' / name)
    subprocess.run(['swift', 'run', '--package-path', str(tmp), 'StreamTests'], check=True, timeout=300)
