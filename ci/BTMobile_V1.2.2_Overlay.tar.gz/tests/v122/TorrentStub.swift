import Foundation
public final class TorrentHandle: @unchecked Sendable {
    let lock = NSLock()
    let size: Int64
    var state = 1
    var calls = 0
    public init(size: Int64) { self.size = size }
    public func setState(_ value: Int) { lock.lock(); defer { lock.unlock() }; state = value }
    public var readCalls: Int { lock.lock(); defer { lock.unlock() }; return calls }
    public func streamingFileSize(fileIndex: Int) -> Int64 { size }
    public func resetStreamingReadWindow() {}
    public func prepareStreamingRead(fileIndex: Int, offset: Int64, length: Int) -> Int {
        lock.lock(); defer { lock.unlock() }; calls += 1
        precondition(fileIndex == 0 && offset >= 0 && Int64(length) <= size - offset)
        return state
    }
}
