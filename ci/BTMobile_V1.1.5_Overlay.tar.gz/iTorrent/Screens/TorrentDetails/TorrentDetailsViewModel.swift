//
//  TorrentDetailsViewModel.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 30/10/2023.
//

import Combine
import LibTorrent
import MvvmFoundation
import Perception
import UIKit

class TorrentDetailsViewModel: BaseCollectionViewModelWith<TorrentHandle>, @unchecked Sendable {
    private var torrentHandle: TorrentHandle!
    private var peerModels: [DetailCellViewModel] = []
    private var peerModelsByID: [String: DetailCellViewModel] = [:]
    private var lastPeerIDs: [String] = []
    private var isPeersExpanded = false
    private lazy var peerSummaryModel = DetailCellViewModel(
        title: "Peers",
        detail: "0",
        spacer: 72,
        isBold: true
    ) { [weak self] in
        guard let self else { return }
        isPeersExpanded.toggle()
        if isPeersExpanded {
            refreshPeers(forceReload: false)
        }
        reload()
    }

    @Published var title: String = ""
    @Published var isPaused: Bool = false
    @Published var canResume: Bool = false
    @Published var canPause: Bool = false

    @Published private var storageError: Bool = false

    let dismissSignal = PassthroughSubject<Void, Never>()

    override func prepare(with model: TorrentHandle) {
        torrentHandle = model
        title = torrentHandle.snapshot.name

        trackDataUpdate()
        trackReload()

        disposeBag.bind {
            torrentHandle.removePublisher.sink { [unowned self] _ in
                dismissSignal.send()
            }

            sequentialModel.$isOn.removeDuplicates().sink { [unowned self] value in
                torrentHandle.setSequentialDownload(value)
            }

            firstAndLastModel.$isOn.removeDuplicates().sink { [unowned self] value in
                torrentHandle.setFirstLastPriorityDownload(value)
            }

            $storageError.removeDuplicates().sink { [unowned self] error in
                runOnMainThreadIfNeeded { [self] in
                    downloadPathModel.accessories = error ?
                        [
                            .image(.init(systemName: "exclamationmark.triangle.fill"), options: .init(tintColor: .systemRed)),
                        ] :
                        [
                            //                        .popUpMenu(
//                            .init(title: %"details.path.migrate", children: [
//                                UIAction(title: "Default", state: .off) { _ in },
//                                UIAction(title: "Browse", state: .off) { _ in },
//                            ]), options: .init(tintColor: .tintColor)
//                        )
                        ]

                    downloadPathModel.selectAction = nil // error ? nil : {}
                }
            }

            torrentHandle.updatePublisher.compactMap { (update: TorrentService.TorrentUpdateModel) in
                guard let handle = update.handle else { return nil }
                return (handle.snapshot.isSequential, handle.snapshot.isFirstLastPiecePriority, handle)
            }.removeDuplicates(by: {
                $0.0 == $1.0 && $0.1 == $1.1
            }).sink { [weak self, downloadPrioritiesMenuModel] (_: Bool, _: Bool, _: TorrentHandle) in
                guard let self else { return }

                downloadPrioritiesMenuModel.value = makeDownloadPriorityValue(isSequential: torrentHandle.snapshot.isSequential, isFirstLastPiecePriority: torrentHandle.snapshot.isFirstLastPiecePriority)
                downloadPrioritiesMenuModel.menu = .init(options: [], children: [
                    UIAction(title: %"details.downloading.sequential",
                             image: .numbersCapsule,
                             attributes: [.keepsMenuPresented],
                             state: torrentHandle.snapshot.isSequential ? .on : .off)
                    { [unowned self] _ in
                        self.torrentHandle.setSequentialDownload(!self.torrentHandle.snapshot.isSequential)
                    },
                    UIAction(title: %"details.downloading.firstAndLast",
                             image: .arrowLeftAndRightCapsule,
                             attributes: [.keepsMenuPresented],
                             state: torrentHandle.snapshot.isFirstLastPiecePriority ? .on : .off)
                    { [unowned self] _ in
                        self.torrentHandle.setFirstLastPriorityDownload(!self.torrentHandle.snapshot.isFirstLastPiecePriority)
                    },
                ])
            }

            // Peer statistics are queried directly from libtorrent and are not
            // part of ObservableSnapshot. Poll while the card is expanded so
            // every row keeps moving even when the torrent snapshot itself did
            // not invalidate the collection view.
            Timer.publish(every: 0.8, on: .main, in: .common)
                .autoconnect()
                .sink { [weak self] _ in
                    guard let self, self.isPeersExpanded else { return }
                    self.refreshPeers(forceReload: false)
                }
        }

        hashModel.longPressAction = { [unowned self] in
            UIPasteboard.general.string = hashModel.detail
            alertWithTimer(message: %"details.copy.hash.title")
        }

        hashModelV2.longPressAction = { [unowned self] in
            UIPasteboard.general.string = hashModelV2.detail
            alertWithTimer(message: %"details.copy.hashV2.title")
        }

        creatorModel.longPressAction = { [unowned self] in
            UIPasteboard.general.string = creatorModel.detail
            alertWithTimer(message: %"details.copy.creator.title")
        }

        commentModel.longPressAction = { [unowned self] in
            UIPasteboard.general.string = commentModel.detail
            alertWithTimer(message: %"details.copy.comment.title")
        }
    }

    private let stateModel = DetailCellViewModel(title: %"details.state")

    private let downloadModel = DetailCellViewModel(title: %"details.speed.download")
    private let uploadModel = DetailCellViewModel(title: %"details.speed.upload")
    private let timeLeftModel = DetailCellViewModel(title: %"details.speed.timeRemains")

    private let sequentialModel = ToggleCellViewModel(title: %"details.downloading.sequential")
    private let firstAndLastModel = ToggleCellViewModel(title: %"details.downloading.firstAndLast")
    private lazy var downloadPrioritiesMenuModel = MenuButtonCellViewModel(with: .init(title: %"details.downloading.downloadPriorities", isBold: true, dismissSelection: { [weak self] in self?.dismissSelection.send() }))
    private let progressModel = TorrentDetailProgressCellViewModel(title: %"details.downloading.progress")

    private let hashModel = DetailCellViewModel(title: %"details.info.hash", spacer: 80)
    private let hashModelV2 = DetailCellViewModel(title: %"details.info.hashV2", spacer: 80)
    private let privateModel = DetailCellViewModel(title: %"details.info.private")
    private let creatorModel = DetailCellViewModel(title: %"details.info.creator", spacer: 80)
    private let commentModel = DetailCellViewModel(title: %"details.info.comment", spacer: 80)
    private let createdModel = DetailCellViewModel(title: %"details.info.created")
    private let addedModel = DetailCellViewModel(title: %"details.info.added")
    private let downloadPath2Model = DetailCellViewModel(title: "Download Path")

    private let selectedModel = DetailCellViewModel(title: %"details.transfer.selectedTotal")
    private let completedModel = DetailCellViewModel(title: %"details.transfer.completed")
    private let selectedProgressModel = DetailCellViewModel(title: %"details.transfer.progressSelectedTotal")
    private let downloadedModel = DetailCellViewModel(title: %"details.transfer.downloaded")
    private let uploadedModel = DetailCellViewModel(title: %"details.transfer.uploaded")
    private let seedersModel = DetailCellViewModel(title: %"details.transfer.seeders")
    private let leechersModel = DetailCellViewModel(title: %"details.transfer.leechers")

    private lazy var downloadPathModel = PRButtonViewModel(with: .init(title: %"details.path.browse", isBold: true, value: nil))

    private lazy var trackersModel = DetailCellViewModel(title: %"details.actions.trackers") { [unowned self] in
        navigate(to: TorrentTrackersViewModel.self, with: torrentHandle, by: .show)
    }
    private lazy var filesModel = DetailCellViewModel(title: %"details.actions.files") { [unowned self] in
        navigate(to: TorrentFilesViewModel.self, with: .init(torrentHandle: torrentHandle), by: .show)
    }

    @Injected private var torrentService: TorrentService
    @Injected private var preferences: PreferencesStorage
}

extension TorrentDetailsViewModel {
    var shareAvailable: AnyPublisher<Bool, Never> {
        torrentHandle.updatePublisher
            .map { !($0.handle?.snapshot.torrentFilePath).isNilOrEmpty }
            .eraseToAnyPublisher()
    }

    func resume() {
        torrentHandle.resume()
    }

    func pause() {
        torrentHandle.pause()
    }

    func rehash(from source: MvvmPresentationSource) {
        // If Storage is not available, try to reconnect storage
        if torrentHandle.snapshot.friendlyState == .storageError {
            return refreshStorage()
        }

        alert(title: %"details.rehash.title", message: %"details.rehash.message", style: .actionSheet, actions: [
            .init(title: %"common.cancel", style: .cancel),
            .init(title: %"details.rehash.action", style: .destructive, isPrimary: true, action: { [unowned self] in
                torrentHandle.rehash()
            }),
        ], sourceView: source)
    }

    func refreshStorage() {
        guard let storage = torrentHandle.storage else { return }
        alert(title: %"details.refreshStorage.title", message: %"details.refreshStorage.message", actions: [
            .init(title: %"common.cancel", style: .cancel),
            .init(title: %"common.continue", style: .default, isPrimary: true, action: { [self] in
                DispatchQueue.global(qos: .userInitiated).async { [self] in
                    guard !torrentService.refreshStorage(storage) else { return }
                    alert(title: %"common.error", message: %"details.refreshStorage.fail.message", actions: [
                        .init(title: %"common.close", style: .cancel, isPrimary: true),
                    ])
                }
            }),
        ])
    }

    func removeTorrent(from source: MvvmPresentationSource) {
        alert(title: %"torrent.remove.title", message: torrentHandle.snapshot.name, style: .actionSheet, actions: [
            .init(title: %"torrent.remove.action.dropData", style: .destructive, action: { [unowned self] in
                TorrentService.shared.removeTorrent(by: torrentHandle.snapshot.infoHashes, deleteFiles: true)
            }),
            .init(title: %"torrent.remove.action.keepData", style: .default, action: { [unowned self] in
                TorrentService.shared.removeTorrent(by: torrentHandle.snapshot.infoHashes, deleteFiles: false)
            }),
            .init(title: %"common.cancel", style: .cancel, isPrimary: true),
        ], sourceView: source)
    }

    func shareMagnet() {
        UIPasteboard.general.string = torrentHandle.snapshot.magnetLink
        alertWithTimer(message: %"details.share.magnetCopy.result")
    }

    var torrentFilePath: String? {
        torrentHandle.snapshot.torrentFilePath
    }

    var infoHashes: TorrentHashes {
        torrentHandle.snapshot.infoHashes
    }
}

private extension TorrentDetailsViewModel {
    func trackDataUpdate() {
        withContinuousPerceptionTracking { [weak self] in
            self?.dataUpdate()
        }
    }

    func trackReload() {
        withContinuousPerceptionTracking { [weak self] in
            self?.reload()
        }
    }

    func dataUpdate() {
        let snapshot = torrentHandle.observableSnapshot
        let friendlyState = snapshot.friendlyState

        isPaused = snapshot.isPaused
        canResume = snapshot.canResume
        canPause = snapshot.canPause
        storageError = friendlyState == .storageError

        stateModel.detail = friendlyState.name

        refreshPeers(forceReload: false)

        downloadModel.detail = "\(snapshot.downloadRate.bitrateToHumanReadable)/s"
        uploadModel.detail = "\(snapshot.uploadRate.bitrateToHumanReadable)/s"
        timeLeftModel.detail = snapshot.timeRemains

        sequentialModel.isOn = snapshot.isSequential
        firstAndLastModel.isOn = snapshot.isFirstLastPiecePriority
        progressModel.progress = snapshot.progress
        progressModel.segmentedProgress = snapshot.segmentedProgress

        if snapshot.infoHashes.hasV1 {
            hashModel.detail = snapshot.infoHashes.v1.hex
        }
        if snapshot.infoHashes.hasV2 {
            hashModelV2.detail = snapshot.infoHashes.v2.hex
        }
        privateModel.detail = torrentHandle.isPrivate ? %"common.yes" : %"common.no"
        creatorModel.detail = snapshot.creator ?? ""
        commentModel.detail = snapshot.comment ?? ""

        let formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/YYYY"
            return formatter
        }()

        if let created = snapshot.creationDate {
            createdModel.detail = formatter.string(from: created)
        }
        addedModel.detail = formatter.string(from: torrentHandle.metadata.dateAdded)

        selectedModel.detail = "\(snapshot.totalWanted.bitrateToHumanReadable) / \(snapshot.total.bitrateToHumanReadable)"
        completedModel.detail = "\(snapshot.totalDone.bitrateToHumanReadable)"
        selectedProgressModel.detail = "\(String(format: "%.2f", snapshot.progress * 100))% / \(String(format: "%.2f", snapshot.progressWanted * 100))%"
        downloadedModel.detail = "\(snapshot.totalDownload.bitrateToHumanReadable)"
        uploadedModel.detail = "\(snapshot.totalUpload.bitrateToHumanReadable)"
        seedersModel.detail = "\(snapshot.numberOfSeeds)(\(snapshot.numberOfTotalSeeds))"
        leechersModel.detail = "\(snapshot.numberOfLeechers)(\(snapshot.numberOfTotalLeechers))"

        downloadPath2Model.detail = snapshot.downloadPath?.path() ?? ""
        downloadPathModel.value = torrentHandle.storage.name

        filesModel.isEnabled = friendlyState != .storageError && snapshot.hasMetadata
    }

    func refreshPeers(forceReload: Bool) {
        guard torrentHandle != nil else { return }

        let peerStats = torrentHandle.peerStats
        let totalPeerDown = peerStats.reduce(UInt64(0)) { partial, peer in
            partial &+ (UInt64(peer["downloadRate"] ?? "") ?? 0)
        }
        let totalPeerUp = peerStats.reduce(UInt64(0)) { partial, peer in
            partial &+ (UInt64(peer["uploadRate"] ?? "") ?? 0)
        }
        peerSummaryModel.detail = "\(peerStats.count) 个  ↓ \(totalPeerDown.bitrateToHumanReadable)/s  ↑ \(totalPeerUp.bitrateToHumanReadable)/s  ·  \(isPeersExpanded ? "点击折叠" : "点击展开")"

        let sortedPeers = Array(peerStats
            .sorted { lhs, rhs in
                let lhsRate = (UInt64(lhs["downloadRate"] ?? "") ?? 0) &+ (UInt64(lhs["uploadRate"] ?? "") ?? 0)
                let rhsRate = (UInt64(rhs["downloadRate"] ?? "") ?? 0) &+ (UInt64(rhs["uploadRate"] ?? "") ?? 0)
                return lhsRate > rhsRate
            }
            .prefix(100))

        var refreshedModels: [DetailCellViewModel] = []
        var refreshedModelsByID: [String: DetailCellViewModel] = [:]
        var peerIDs: [String] = []

        for peer in sortedPeers {
            let ip = peer["ip"] ?? "?"
            let port = peer["port"] ?? "0"
            let host = ip.contains(":") ? "[\(ip)]" : ip
            let peerID = "\(host):\(port)"
            let down = UInt64(peer["downloadRate"] ?? "") ?? 0
            let up = UInt64(peer["uploadRate"] ?? "") ?? 0
            let progress = min(max(Double(peer["progressPPM"] ?? "") ?? 0, 0), 1_000_000) / 10_000
            let transport = peer["transport"] ?? "TCP"
            let direction = peer["direction"] == "OUT" ? "出" : "入"
            let holepunched = peer["holepunched"] == "1" ? " HP" : ""
            let client = peer["client"] ?? ""
            let clientPart = client.isEmpty ? "" : " · \(client)"

            let model = peerModelsByID[peerID] ?? DetailCellViewModel(
                title: peerID,
                spacer: 6,
                isBold: false,
                isCompactSingleLine: true
            )
            model.title = peerID
            model.detail = "↓\(down.bitrateToHumanReadable)/s ↑\(up.bitrateToHumanReadable)/s · \(String(format: "%.1f%%", progress)) · \(transport)\(direction)\(holepunched)\(clientPart)"
            refreshedModels.append(model)
            refreshedModelsByID[peerID] = model
            peerIDs.append(peerID)
        }

        let membershipChanged = peerIDs != lastPeerIDs
        peerModels = refreshedModels
        peerModelsByID = refreshedModelsByID
        lastPeerIDs = peerIDs

        if isPeersExpanded && (forceReload || membershipChanged) {
            reload()
        }
    }

    func reload() {
        let snapshot = torrentHandle.observableSnapshot
        let friendlyState = snapshot.friendlyState
        let showsSpeed = !snapshot.isPaused && friendlyState != .checkingFiles
        let isSeeding = friendlyState == .seeding
        let hasV1 = snapshot.infoHashes.hasV1
        let hasV2 = snapshot.infoHashes.hasV2

        var sections: [MvvmCollectionSectionModel] = []
        defer { self.sections = sections }

        sections.append(.init(id: "state") {
            stateModel
        })

        if showsSpeed {
            sections.append(.init(id: "speed", header: %"details.speed") {
                if !isSeeding {
                    downloadModel
                }
                uploadModel
                if !isSeeding {
                    timeLeftModel
                }
            })
        }

        sections.append(.init(id: "download", header: %"details.downloading") {
//            sequentialModel
//            firstAndLastModel
            downloadPrioritiesMenuModel
            progressModel
        })
//
        sections.append(.init(id: "info", header: %"details.info") {
            if hasV1 {
                hashModel
            }
            if hasV2 {
                hashModelV2
            }
            if snapshot.isPrivate {
                privateModel
            }

            if !creatorModel.detail.isEmpty {
                creatorModel
            }

            if !commentModel.detail.isEmpty {
                commentModel
            }

            if !creatorModel.detail.isEmpty {
                createdModel
            }
            addedModel
        })

        sections.append(.init(id: "transfer", header: %"details.transfer") {
            selectedModel
            completedModel
            selectedProgressModel
            downloadedModel
            uploadedModel
            seedersModel
            leechersModel
        })

        if !preferences.storageScopes.isEmpty {
            sections.append(.init(id: "path", header: %"details.path") {
                //            downloadPath2Model
                downloadPathModel
            })
        }

        let peerItems: [MvvmViewModel] = isPeersExpanded
            ? [peerSummaryModel] + peerModels.map { $0 as MvvmViewModel }
            : [peerSummaryModel]
        sections.append(.init(
            id: "peers",
            header: isPeersExpanded ? "Peer 连接详情" : "Peer 连接",
            items: peerItems
        ))

        sections.append(.init(id: "actions", header: %"details.actions") {
            trackersModel
            filesModel
        })
    }

    func makeDownloadPriorityValue(
        isSequential: Bool,
        isFirstLastPiecePriority: Bool
    ) -> NSAttributedString {
        guard isSequential || isFirstLastPiecePriority else {
            return NSAttributedString("None")
        }

        let result = NSMutableAttributedString()

        if isSequential {
            let attachment = NSTextAttachment()
            attachment.image = .numbersCapsule.withRenderingMode(.alwaysTemplate)
            result.append(NSAttributedString(attachment: attachment))
        }

        if isFirstLastPiecePriority {
            if result.length > 0 {
                result.append(NSAttributedString(string: " "))
            }

            let attachment = NSTextAttachment()
            attachment.image = .arrowLeftAndRightCapsule.withRenderingMode(.alwaysTemplate)
            result.append(NSAttributedString(attachment: attachment))
        }

        return NSAttributedString(attributedString: result)
    }
}

private extension TorrentHandle.ObservedSnapshot {
    var friendlyState: TorrentHandle.State {
        if isStorageMissing {
            return .storageError
        }

        switch state {
        case .downloading:
            if isPaused { return .paused }
            else { return .downloading }
        case .finished:
            if isPaused { return .finished }
            else { return .seeding }
        case .seeding:
            if isPaused { return .finished }
            else { return .seeding }
        default:
            return state
        }
    }

    var canResume: Bool {
        isPaused && friendlyState != .storageError
    }

    var canPause: Bool {
        !isPaused
    }

    var timeRemains: String {
        guard downloadRate > 0 else { return %"time.infinity" }
        guard totalWanted >= totalWantedDone else { return "Almost done" }
        return ((totalWanted - totalWantedDone) / downloadRate).timeString
    }

    var segmentedProgress: [Double] {
        pieces?.map { $0.doubleValue } ?? [0]
    }
}
