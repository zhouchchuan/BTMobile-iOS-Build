import Foundation
import Combine

// Exercise the production service with only its external torrent/DI adapters stubbed.
final class TorrentHandle {
    var isPrivate = false
    var added: [String] = []
    func addTracker(_ address: String) { added.append(address) }
}
final class DisposeBag { var tokens = Set<AnyCancellable>() }
extension AnyCancellable { func store(in bag: DisposeBag) { bag.tokens.insert(self) } }

let defaults = UserDefaults.standard
let keys = ["TrackersListServiceDataKey", "btmobileV120DefaultTrackers"]
keys.forEach { defaults.removeObject(forKey: $0) }
defer { keys.forEach { defaults.removeObject(forKey: $0) } }
let first = TrackersListService()
assert(first.trackerSources.value.count == 1)
assert(first.trackerSources.value.values.first!.trackers.count == 8)
assert(Set(TrackersListService.bundledTrackers).count == 8)
assert(TrackersListService.bundledTrackers.allSatisfy { !$0.contains("\n") && URL(string: $0)?.host != nil })
let custom = TrackersListService.ListState(source: .local(UUID()), title: "User custom",
    status: .updated, trackers: ["https://example.com/announce", TrackersListService.bundledTrackers[0]])
first.trackerSources.value[custom.source] = custom
// Upgrade from a user list with no V1.2.0 migration marker must preserve it.
defaults.removeObject(forKey: "btmobileV120DefaultTrackers")
let migrated = TrackersListService()
assert(migrated.trackerSources.value.count == 2)
assert(migrated.trackerSources.value[custom.source]?.trackers == custom.trackers)
let publicTorrent = TorrentHandle()
migrated.addAllTrackers(to: publicTorrent)
assert(publicTorrent.added.count == 9)
let privateTorrent = TorrentHandle(); privateTorrent.isPrivate = true
migrated.addAllTrackers(to: privateTorrent)
assert(privateTorrent.added.isEmpty)
// User deletion after upgrade must not be undone on every app launch.
migrated.trackerSources.value = [custom.source: custom]
assert(TrackersListService().trackerSources.value.count == 1)
print("PASS: 8 default trackers, upgrade preservation, deduplication, private torrent exclusion, user deletion persistence")
