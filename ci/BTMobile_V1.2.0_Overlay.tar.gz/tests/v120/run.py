"""macOS CI regression checks; all generated fixtures stay in a temporary directory."""
from pathlib import Path
import io
import os
import subprocess
import tarfile
import tempfile
import zipfile

root = Path.cwd()
def run(*args, **kwargs):
    subprocess.run([str(a) for a in args], check=True, **kwargs)

with tempfile.TemporaryDirectory(prefix="btmobile-v120-tests-") as directory:
    tmp = Path(directory)
    service = root / "iTorrent/Services/TrackersListService/TrackersListService.swift"
    source = service.read_text().replace("import LibTorrent\n", "").replace("import MvvmFoundation\n", "")
    (tmp / "TrackersListService.swift").write_text(source)
    (tmp / "main.swift").write_text((root / "tests/v120/trackers-main.swift").read_text())
    run("xcrun", "swiftc", tmp / "TrackersListService.swift", tmp / "main.swift", "-o", tmp / "trackers-tests")
    run(tmp / "trackers-tests")
    native = root / "Submodules/SwiftVLC/Sources/CLibVLC"
    run("xcrun", "clang", "-std=c11", "-I" + str(native / "include"), native / "archive_bridge.c",
        root / "tests/v120/archive-progress.c", "-larchive", "-o", tmp / "archive-tests")
    payload = os.urandom(2 * 1024 * 1024)
    for extension in ("zip", "tar.gz"):
        archive = tmp / ("fixture." + extension)
        if extension == "zip":
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as f:
                f.writestr("中文文件.bin", payload)
        else:
            with tarfile.open(archive, "w:gz") as f:
                info = tarfile.TarInfo("中文文件.bin"); info.size = len(payload)
                f.addfile(info, io.BytesIO(payload))
        target = tmp / ("output-" + extension); target.mkdir()
        run(tmp / "archive-tests", archive, target, "0")
        assert (target / "中文文件.bin").read_bytes() == payload
    (tmp / "secret.bin").write_bytes(payload)
    run("/usr/bin/zip", "-q", "-P", "fixture-only", "encrypted.zip", "secret.bin", cwd=tmp)
    for password, failure in (("fixture-only", "0"), ("wrong", "1")):
        target = tmp / ("password-" + failure); target.mkdir()
        run(tmp / "archive-tests", tmp / "encrypted.zip", target, failure, password)
        if failure == "0": assert (target / "secret.bin").read_bytes() == payload
    print("PASS: ZIP/TAR.GZ Chinese filenames, actual progress, encrypted ZIP, wrong password rejection")
