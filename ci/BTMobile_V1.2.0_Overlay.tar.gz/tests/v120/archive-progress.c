#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
typedef void (*progress_cb)(int64_t, int64_t, void *);
extern int swiftvlc_archive_extract_progress(const char *, char *const *, size_t,
    const char *, const char *, char *, size_t, progress_cb, void *);
struct state { int calls; int64_t total; int64_t highest; };
static void progress(int64_t read, int64_t total, void *context) {
    struct state *s = context;
    if (total != s->total || read < 0) abort();
    if (read > s->highest) s->highest = read;
    s->calls++;
}
int main(int argc, char **argv) {
    if (argc < 4) return 1;
    struct stat st;
    if (stat(argv[1], &st)) return 2;
    struct state s = {0, st.st_size, 0};
    char error[2048] = {0};
    int result = swiftvlc_archive_extract_progress(argv[1], NULL, 0, argv[2],
        argc > 4 ? argv[4] : NULL, error, sizeof(error), progress, &s);
    if (atoi(argv[3])) {
        if (result == 0 || !error[0]) return 3;
    } else {
        if (result != 0 || s.calls < 2 || s.highest <= 0) {
            fprintf(stderr, "result=%d callbacks=%d error=%s\n", result, s.calls, error);
            return 4;
        }
    }
    printf("PASS: archive callback and result (expectedFailure=%s, calls=%d)\n", argv[3], s.calls);
    return 0;
}
