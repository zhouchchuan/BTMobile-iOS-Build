//
//  PreferencesStorage.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 07/11/2023.
//

import Combine
import Foundation
import LibTorrent
import MvvmFoundation
import UIKit
import Network

class PreferencesStorage: Resolvable {
    private init() {
        #if !IS_SUPPORT_LOCATION_BG && !os(tvOS)
        // Location mode is not allowed by Apple policy
        backgroundMode = .audio
        #endif

        #if !os(tvOS)
        // V1.0.9 migrates older installs that persisted the upstream defaults
        // with background transfer or background seeding disabled. The marker
        // makes this a one-time upgrade so later user choices remain respected.
        let defaults = UserDefaults.standard
        if !defaults.bool(forKey: "btmobileV109BackgroundMigration") {
            isBackgroundDownloadEnabled = true
            isBackgroundSeedingEnabled = true
            backgroundMode = .audio
            defaults.set(true, forKey: "btmobileV109BackgroundMigration")
        }
        #endif

        // V1.2.0 enables the requested bundled Tracker source once. Subsequent
        // user toggles remain authoritative; background/session settings are unchanged.
        if !UserDefaults.standard.bool(forKey: "btmobileV120TrackerAutoadding") {
            isTrackersAutoaddingEnabled = true
            UserDefaults.standard.set(true, forKey: "btmobileV120TrackerAutoadding")
        }

        // Sanity check for the user-selected external storage. BT Mobile managed
        // folders use their own preference so they never alter the existing
        // external-storage behavior.
        if defaultStorage != nil, !storageScopes.contains(where: { $0.key == defaultStorage }) { defaultStorage = nil }

        if btMobileManagedDefaultStorage != nil,
           !btMobileManagedStorageScopes.contains(where: { $0.key == btMobileManagedDefaultStorage })
        {
            btMobileManagedDefaultStorage = nil
        }

        // Fix sorting array in case new status appeared
        if torrentListGroupsSortingArray.count != Self.defaultTorrentListGroupsSortingArray.count {
            torrentListGroupsSortingArray = Self.defaultTorrentListGroupsSortingArray
        }

        // TODO: REMOVE LATER!!!
        isStorageRulesAccepted = false


    }

    private var disposeBag: [AnyCancellable] = []
    static let shared = PreferencesStorage()

    static let defaultTorrentListGroupsSortingArray: [TorrentHandle.State] = [
        .checkingFiles,
        .downloadingMetadata,
        .downloading,
        .seeding,
        .finished,
        .checkingResumeData,
        .paused,
        .storageError
    ]

    @UserDefaultItem("torrentDefaultStorage", nil) var defaultStorage: UUID?
    @UserDefaultItem("torrentIsStorageRulesAccepted", false) var isStorageRulesAccepted: Bool
    @UserDefaultItem("torrentStorageScopes", [:]) var storageScopes: [UUID: StorageModel]

    // BT Mobile 0.1.4 managed folders live under Documents/BTmobile. They are
    // kept separate from security-scoped external storages so the V0.1.3
    // external-storage flow remains unchanged.
    @UserDefaultItem("btmobileManagedStorageScopes", [:]) var btMobileManagedStorageScopes: [UUID: StorageModel]
    @UserDefaultItem("btmobileManagedDefaultStorage", nil) var btMobileManagedDefaultStorage: UUID?

    var effectiveDefaultStorage: UUID? {
        btMobileManagedDefaultStorage ?? defaultStorage
    }

    var allStorageScopes: [UUID: StorageModel] {
        storageScopes.merging(btMobileManagedStorageScopes) { external, _ in external }
    }

    #if !os(tvOS)
    @UserDefaultItem("torrentListSortType", .alphabetically) var torrentListSortType: TorrentListViewModel.Sort
    #endif
    @UserDefaultItem("torrentListSortReverced", false) var torrentListSortReverced: Bool
    @UserDefaultItem("torrentListIsGroubedByState", false) var torrentListGroupedByState: Bool

    @UserDefaultItem("torrentListGroupsSortingArray", PreferencesStorage.defaultTorrentListGroupsSortingArray)
    var torrentListGroupsSortingArray: [TorrentHandle.State]

    @UserDefaultItem("preferencesAllocateMemory", false) var allocateMemory: Bool

    @UserDefaultItem("preferencesStopSeedingOnFinish", false) var stopSeedingOnFinish: Bool

    @UserDefaultItem("preferencesMaxActiveTorrents", 4) var maxActiveTorrents: Int
    @UserDefaultItem("preferencesMaxDownloadingTorrents", 3) var maxDownloadingTorrents: Int
    @UserDefaultItem("preferencesMaxUploadingTorrents", 3) var maxUploadingTorrents: Int

    @UserDefaultItem("preferencesMaxUploadSpeed", 0) var maxUploadSpeed: UInt
    @UserDefaultItem("preferencesMaxDownloadSpeed", 0) var maxDownloadSpeed: UInt

    @UserDefaultItem("preferencesTrackersAutoaddingEnabled", false) var isTrackersAutoaddingEnabled: Bool

    @UserDefaultItem("preferencesIsCellularEnabled", false) var isCellularEnabled: Bool
    @UserDefaultItem("preferencesUseAllAvailableInterfaces", false) var useAllAvailableInterfaces: Bool

    @UserDefaultItem("preferencesConnectionDht", true) var isDhtEnabled: Bool
    @UserDefaultItem("preferencesConnectionLsd", true) var isLsdEnabled: Bool
    @UserDefaultItem("preferencesConnectionUtp", true) var isUtpEnabled: Bool
    @UserDefaultItem("preferencesConnectionUpnp", true) var isUpnpEnabled: Bool
    @UserDefaultItem("preferencesConnectionNatPmp", true) var isNatEnabled: Bool

    @UserDefaultItem("preferencesEncryptionPolicy", .enabled) var encryptionPolicy: Session.Settings.EncryptionPolicy
    @UserDefaultItem("preferencesValidateHttpsTrackers", true) var validateHttpsTrackers: Bool


    @UserDefaultItem("preferencesUseDefaultPort", true) var useDefaultPort: Bool
    @UserDefaultItem("preferencesPort", 6881) var port: Int
    @UserDefaultItem("preferencesPortBindRetries", 10) var portBindRetries: Int

    @UserDefaultItem("preferencesProxyType", .none) var proxyType: Session.Settings.ProxyType
    @UserDefaultItem("preferencesProxyHostname", "") var proxyHostname: String
    @UserDefaultItem("preferencesProxyHostPort", 8080) var proxyHostPort: Int
    @UserDefaultItem("preferencesProxyAuthRequired", false) var proxyAuthRequired: Bool
    @UserDefaultItem("preferencesProxyUsername", "") var proxyUsername: String
    @UserDefaultItem("preferencesProxyPassword", "") var proxyPassword: String
    @UserDefaultItem("preferencesProxyPeerConnections", true) var proxyPeerConnections: Bool

    #if !os(tvOS)
    @UserDefaultItem("preferencesApplicationAppearance", .unspecified) var appAppearance: UIUserInterfaceStyle
    @NSUserDefaultItem("preferencesTintColor", .accent) var tintColor: UIColor
    #endif

    @UserDefaultItem("preferencesNotificationsDownload", true) var isDownloadNotificationsEnabled: Bool
    @UserDefaultItem("preferencesNotificationsSeed", true) var isSeedNotificationsEnabled: Bool

    #if !os(tvOS)
    @UserDefaultItem("preferencesBackgroundDownloadEnabled", true) var isBackgroundDownloadEnabled: Bool
    @UserDefaultItem("preferencesBackgroundMode", .audio) var backgroundMode: BackgroundService.Mode
    @UserDefaultItem("preferencesBackgroundAllowSeeding", true) var isBackgroundSeedingEnabled: Bool
    @UserDefaultItem("preferencesBackgroundLocationIndicator", false) var isBackgroundLocationIndicatorEnabled: Bool
    #endif

    @UserDefaultItem("preferencesIsFileSharingEnabled", false) var isFileSharingEnabled: Bool
    @UserDefaultItem("preferencesIsWebServerEnabled", false) var isWebServerEnabled: Bool
    @UserDefaultItem("preferencesIsWebDavServerEnabled", false) var isWebDavServerEnabled: Bool
    @UserDefaultItem("preferencesWebServerPort", 80) var webServerPort: Int
    @UserDefaultItem("preferencesWebDavServerPort", 81) var webDavServerPort: Int
    @UserDefaultItem("preferencesWebServerLogin", "") var webServerLogin: String
    @UserDefaultItem("preferencesWebServerPassword", "") var webServerPassword: String

    #if !os(tvOS)
    @UserDefaultItem("preferencesPatreonAccount", nil) var patreonAccount: PatreonAccount?
    @UserDefaultItem("preferencesPatreonToken", nil) var patreonToken: PatreonToken?
    @UserDefaultItem("preferencesPatreonCredentials", nil) var patreonCredentials: PatreonCredentials?
    #endif

    @UserDefaultItem("initialSetupCellularPassed", false) var initialSetupCellularPassed: Bool

    var settingsUpdatePublisher: AnyPublisher<Void, Never> {
        Just<Void>(())
            .combineLatest($maxActiveTorrents)
            .combineLatest($maxDownloadingTorrents)
            .combineLatest($maxUploadingTorrents)
            .combineLatest($maxUploadSpeed)
            .combineLatest($maxDownloadSpeed)
            .combineLatest($isDhtEnabled)
            .combineLatest($isLsdEnabled)
            .combineLatest($isUtpEnabled)
            .combineLatest($isUpnpEnabled)
            .combineLatest($isNatEnabled)
            .combineLatest($encryptionPolicy)
            .combineLatest($validateHttpsTrackers)
            .combineLatest($useDefaultPort)
            .combineLatest($port)
            .combineLatest($portBindRetries)
            .combineLatest($proxyType)
            .combineLatest($proxyHostname)
            .combineLatest($proxyHostPort)
            .combineLatest($proxyAuthRequired)
            .combineLatest($proxyUsername)
            .combineLatest($proxyPassword)
            .combineLatest($proxyPeerConnections)
            .combineLatest($useAllAvailableInterfaces)
            .map { _ in /* ignore result */ }
            .eraseToAnyPublisher()
    }
}

extension Session.Settings {
    static func fromPreferences(with interfaces: [NWInterface]) -> Self {
        let settings = Self()
        let preferences = PreferencesStorage.shared

        let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        settings.agentName = "iTorrent/\(appVersion)"
        settings.peerFingerprint = peerFingerprint(for: appVersion)

        settings.maxActiveTorrents = preferences.maxActiveTorrents
        settings.maxDownloadingTorrents = preferences.maxDownloadingTorrents
        settings.maxUploadingTorrents = preferences.maxUploadingTorrents

        settings.maxUploadSpeed = preferences.maxUploadSpeed
        settings.maxDownloadSpeed = preferences.maxDownloadSpeed

        settings.isDhtEnabled = preferences.isDhtEnabled
        settings.isLsdEnabled = preferences.isLsdEnabled
        settings.isUtpEnabled = preferences.isUtpEnabled
        settings.isUpnpEnabled = preferences.isUpnpEnabled
        settings.isNatEnabled = preferences.isNatEnabled

        settings.encryptionPolicy = preferences.encryptionPolicy
        settings.validateHttpsTrackers = preferences.validateHttpsTrackers

        settings.port = preferences.useDefaultPort ? 6881 : preferences.port
        settings.portBindRetries = preferences.portBindRetries

        settings.proxyType = preferences.proxyType
        settings.proxyHostname = preferences.proxyHostname
        settings.proxyHostPort = preferences.proxyHostPort
        settings.proxyAuthRequired = preferences.proxyAuthRequired
        settings.proxyUsername = preferences.proxyUsername
        settings.proxyPassword = preferences.proxyPassword
        settings.proxyPeerConnections = preferences.proxyPeerConnections

        var interfacesToUse = interfaces
        if !preferences.useAllAvailableInterfaces {
            interfacesToUse = [interfacesToUse.first].compactMap { $0 }
        }
        let interfacesNamesToUse = interfacesToUse.map { $0.name } + ["lo0"]
        settings.outgoingInterfaces = interfacesNamesToUse.joined(separator: ",")
        settings.listenInterfaces = interfacesNamesToUse.map { "\($0):\(settings.port)" }.joined(separator: ",")

        print("--- \(settings.listenInterfaces)")

        return settings
    }

    private static func peerFingerprint(for version: String) -> String {
        var components = version.split(separator: ".").prefix(4).map { component in
            let numericPrefix = component.prefix { $0.isNumber }
            return min(Int(numericPrefix) ?? 0, 35)
        }
        components.append(contentsOf: repeatElement(0, count: 4 - components.count))

        let versionCharacters = components.map { value -> Character in
            if value < 10 {
                return Character(String(value))
            }
            return Character(UnicodeScalar(65 + value - 10)!)
        }

        return "-IT\(String(versionCharacters))-"
    }
}
