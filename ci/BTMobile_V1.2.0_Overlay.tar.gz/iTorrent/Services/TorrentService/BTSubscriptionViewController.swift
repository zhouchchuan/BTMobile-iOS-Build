import UIKit
import WebKit

enum BTSubscriptionPresentation {
    @MainActor private static var timer: Timer?
    @MainActor private static var pendingShow = false
    @MainActor private static var pendingNotice: String?
    @MainActor private static var presentationTask: Task<Void, Never>?
    // Subscription-only polling; never changes the torrent session or its lifecycle.
    @MainActor static func refreshWhileActive() {
        drainPresentation()
        Task { try? await BTSubscriptionNetwork.shared.refresh() }
        guard timer == nil else { return }
        timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in
            Task { @MainActor in
                guard UIApplication.shared.applicationState == .active else { return }
                try? await BTSubscriptionNetwork.shared.refresh()
            }
        }
    }
    static func show(message: String? = nil) {
        DispatchQueue.main.async {
            pendingShow = true
            if let message { pendingNotice = message }
            drainPresentation()
        }
    }

    @MainActor private static func drainPresentation() {
        guard pendingShow, presentationTask == nil else { return }
        presentationTask = Task { @MainActor in
            defer { presentationTask = nil }
            while pendingShow && !Task.isCancelled {
                guard UIApplication.shared.applicationState == .active else { return }
                if let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene })
                    .first(where: { $0.activationState == .foregroundActive }),
                   let root = scene.windows.first(where: \.isKeyWindow)?.rootViewController {
                    var presenter = root
                    var transitioning = root.isBeingPresented || root.isBeingDismissed || root.transitionCoordinator != nil
                    while let next = presenter.presentedViewController {
                        presenter = next
                        transitioning = transitioning || next.isBeingPresented || next.isBeingDismissed || next.transitionCoordinator != nil
                    }
                    // UIAlertAction runs before its input alert finishes dismissing.
                    // Never present from that disappearing alert or dismiss unrelated UI.
                    if !transitioning && !(presenter is UIAlertController) && presenter.viewIfLoaded?.window != nil {
                        if let existing = (presenter as? UINavigationController)?.viewControllers.first as? BTSubscriptionViewController {
                            existing.showNotice(pendingNotice)
                        } else {
                            let page = BTSubscriptionViewController(); page.notice = pendingNotice
                            presenter.present(UINavigationController(rootViewController: page), animated: true)
                        }
                        pendingShow = false; pendingNotice = nil
                        return
                    }
                }
                try? await Task.sleep(nanoseconds: 100_000_000)
            }
        }
    }
}

private enum BTSubscriptionUI {
    static func date(_ timestamp: Double?) -> String {
        guard let timestamp, timestamp > 0 else { return "—" }
        let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .short
        return f.string(from: Date(timeIntervalSince1970: timestamp))
    }
    static func orderStatus(_ value: String) -> String {
        switch value { case "paid": return "已支付"; case "closed": return "已关闭"
        case "expired": return "支付页已过期"; default: return "待支付" }
    }
}

final class BTSubscriptionViewController: UIViewController {
    var notice: String?
    private let noticeLabel = UILabel()
    func showNotice(_ message: String?) {
        guard let message else { return }
        notice = message
        if isViewLoaded { noticeLabel.text = message; noticeLabel.isHidden = false }
    }
    private let stack = UIStackView(), history = UIStackView()
    private let channels = UISegmentedControl(items: ["支付宝", "微信支付"])
    private let identity = UILabel(), quota = UILabel(), expiry = UILabel(), stateLabel = UILabel()
    private let syncLabel = UILabel(), paymentHint = UILabel()
    private let purchase = UIButton(type: .system)
    private var busy = false
    private var observer: NSObjectProtocol?
    override func viewDidLoad() {
        super.viewDidLoad(); title = "订阅与使用额度"; view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(close))
        let scroll = UIScrollView(); scroll.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical; stack.spacing = 14; stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll); scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor), scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 20), stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 20), stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -20),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -40)
        ])
        add(noticeLabel, size: 15, weight: .semibold, color: .systemOrange)
        noticeLabel.text = notice; noticeLabel.isHidden = notice == nil
        label("我的权益", size: 22, weight: .bold)
        add(stateLabel, size: 19, weight: .semibold); add(quota, size: 16); add(expiry, size: 13); add(syncLabel, size: 12, color: .secondaryLabel)
        button("刷新权益与订单", action: #selector(refreshSubscription))
        label("30天订阅 · ¥8.00", size: 22, weight: .bold)
        label("有效期内无限添加磁力任务。手动续费，不自动扣款；有效期内续费延长原到期日，过期后购买从到账确认时重新计算30天。", size: 13, color: .secondaryLabel)
        channels.selectedSegmentIndex = 0; stack.addArrangedSubview(channels)
        var config = UIButton.Configuration.filled(); config.title = "订阅 / 续费 · ¥8"; config.cornerStyle = .medium
        purchase.configuration = config; purchase.heightAnchor.constraint(greaterThanOrEqualToConstant: 48).isActive = true
        purchase.addTarget(self, action: #selector(payment), for: .touchUpInside); stack.addArrangedSubview(purchase); add(paymentHint, size: 13, color: .secondaryLabel)
        label("使用规则", size: 18, weight: .semibold)
        label("开启订阅限制：未订阅每天免费添加3次，有效订阅无限次。关闭限制：未订阅仍显示未订阅，但可免费无限添加；已订阅用户的记录与到期时间不变，不自动延期。", size: 13)
        label("北京时间00:00重置免费额度，仅新增成功的磁力任务计次。重复、失败、暂停和继续不计次；已添加任务的下载、做种、文件管理与播放不受影响。重新开启限制不会重置当日已用额度。", size: 13, color: .secondaryLabel)
        label("联网进入App或本页自动同步，前台每60秒更新。离线沿用已验签权益最多24小时；超过时限或首次未同步时按每日3次处理，请联网刷新。", size: 12, color: .secondaryLabel)
        label("最近订单（最多20条）", size: 18, weight: .semibold); history.axis = .vertical; history.spacing = 12; stack.addArrangedSubview(history)
        label("匿名设备身份", size: 18, weight: .semibold); add(identity, size: 12); identity.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        button("复制 UUID", action: #selector(copyIdentity))
        label("无需注册。此UUID为应用生成的设备身份，不是硬件序列号。换机或重置后不保证保留；请妥善保存UUID及订单号以便人工核查。", size: 12, color: .secondaryLabel)
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.2.0"
        label("BTmobile V\(version)", size: 12, color: .secondaryLabel)
        observer = NotificationCenter.default.addObserver(forName: BTSubscription.changed, object: nil, queue: .main) { [weak self] _ in
            DispatchQueue.main.async { self?.render() }
        }
        render()
    }
    deinit { if let observer { NotificationCenter.default.removeObserver(observer) } }
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated); render(); sync() }
    private func add(_ label: UILabel, size: CGFloat, weight: UIFont.Weight = .regular, color: UIColor = .label) {
        label.numberOfLines = 0; label.font = .systemFont(ofSize: size, weight: weight); label.textColor = color; stack.addArrangedSubview(label)
    }
    private func label(_ text: String, size: CGFloat = 15, weight: UIFont.Weight = .regular, color: UIColor = .label) {
        let l = UILabel(); l.text = text; add(l, size: size, weight: weight, color: color)
    }
    private func button(_ title: String, action: Selector) {
        let b = UIButton(type: .system); var config = UIButton.Configuration.tinted(); config.title = title; config.cornerStyle = .medium
        b.configuration = config; b.heightAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
        b.addTarget(self, action: action, for: .touchUpInside); stack.addArrangedSubview(b)
    }
    private func render() {
        let s = BTSubscription.shared.snapshot; identity.text = s.deviceID
        stateLabel.text = s.error ?? s.statusText; stateLabel.textColor = s.paid ? .systemGreen : .label; quota.text = s.allowanceText
        expiry.text = "订阅开始：\(BTSubscriptionUI.date(s.startsAt?.timeIntervalSince1970))\n订阅到期：\(BTSubscriptionUI.date(s.expiresAt?.timeIntervalSince1970))"
        for (index, channel) in ["alipay", "wxpay"].enumerated() { channels.setEnabled(s.paymentChannels.contains(channel), forSegmentAt: index) }
        let selected = channels.selectedSegmentIndex
        if selected < 0 || selected > 1 || !channels.isEnabledForSegment(at: selected) {
            channels.selectedSegmentIndex = s.paymentChannels.contains("alipay") ? 0 : s.paymentChannels.contains("wxpay") ? 1 : UISegmentedControl.noSegment
        }
        purchase.isHidden = !s.subscriptionEnabled; channels.isHidden = !s.subscriptionEnabled
        purchase.isEnabled = !busy && s.subscriptionEnabled && s.paymentsEnabled && !s.paymentChannels.isEmpty && s.error == nil
        paymentHint.text = !s.subscriptionEnabled ? "运营方已免费开放无限添加，无需购买订阅。" : s.paymentsEnabled ? "支付页面在App内打开；如通道要求唤起支付宝或微信，请确认后完成付款并返回。只以服务端验签结果确认到账。" : "当前暂未开放收款或权益需联网确认，请刷新；已有任务不受影响。"
    }
    private func sync() {
        guard !busy else { return }; busy = true; syncLabel.text = "正在同步权益与订单…"; render()
        Task { @MainActor in
            defer { busy = false; render() }
            do {
                try await BTSubscriptionNetwork.shared.refresh(); syncLabel.text = "权益已同步：\(BTSubscriptionUI.date(Date().timeIntervalSince1970))"
                do { showOrders(try await BTSubscriptionNetwork.shared.orders()) }
                catch { syncLabel.text = "权益已同步；订单暂时无法读取，请稍后刷新（需1.1.9服务端）。" }
            } catch { syncLabel.text = "同步失败，保留有效缓存：\(error.localizedDescription)" }
        }
    }
    private func showOrders(_ records: [BTSubscriptionNetwork.OrderRecord]) {
        for v in history.arrangedSubviews { history.removeArrangedSubview(v); v.removeFromSuperview() }
        if records.isEmpty { let l = UILabel(); l.text = "暂无订单"; l.font = .systemFont(ofSize: 13); history.addArrangedSubview(l) }
        for o in records {
            let l = UILabel(); l.numberOfLines = 0; l.font = .systemFont(ofSize: 12); l.textColor = .secondaryLabel
            l.text = "\(BTSubscriptionUI.orderStatus(o.status)) · \(o.channel == "alipay" ? "支付宝" : "微信") · ¥\(String(format: "%.2f", Double(o.priceCents) / 100)) / \(o.days)天\n订单号：\(o.id)\n创建：\(BTSubscriptionUI.date(o.createdAt))\n到账：\(BTSubscriptionUI.date(o.paidAt))"
            history.addArrangedSubview(l)
        }
    }
    @objc private func close() { dismiss(animated: true) }
    @objc private func refreshSubscription() { sync() }
    @objc private func copyIdentity() {
        let s = BTSubscription.shared.snapshot; guard s.error == nil else { return }; UIPasteboard.general.string = s.deviceID; syncLabel.text = "UUID已复制"
    }
    @objc private func payment() {
        guard !busy, purchase.isEnabled, (0...1).contains(channels.selectedSegmentIndex) else { return }
        busy = true; render(); let channel = channels.selectedSegmentIndex == 0 ? "alipay" : "wxpay"
        Task { @MainActor in
            defer { busy = false; render() }
            do {
                let order = try await BTSubscriptionNetwork.shared.createOrder(channel: channel)
                navigationController?.pushViewController(BTSubscriptionCheckoutController(order: order), animated: true)
            } catch { syncLabel.text = error.localizedDescription }
        }
    }
}

// Web content receives only an opaque checkout token, never device keys or entitlement data.
final class BTSubscriptionCheckoutController: UIViewController, WKNavigationDelegate {
    private let order: BTSubscriptionNetwork.Order
    private let web: WKWebView
    private let status = UILabel()
    private var polling: Task<Void, Never>?
    private var checking = false, confirmed = false
    init(order: BTSubscriptionNetwork.Order) {
        self.order = order; let config = WKWebViewConfiguration(); config.websiteDataStore = .nonPersistent()
        web = WKWebView(frame: .zero, configuration: config); super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func viewDidLoad() {
        super.viewDidLoad(); title = "安全支付 · ¥8 / 30天"; view.backgroundColor = .systemBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "查询到账", style: .plain, target: self, action: #selector(checkPayment))
        status.text = "订单已创建，请在下方支付。未确认到账前请勿重复付款。"; status.font = .systemFont(ofSize: 12); status.numberOfLines = 0
        let layout = UIStackView(arrangedSubviews: [status, web]); layout.axis = .vertical; layout.spacing = 10; layout.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(layout)
        NSLayoutConstraint.activate([layout.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8), layout.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            layout.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 12), layout.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12)])
        web.navigationDelegate = self; if let url = URL(string: order.checkoutURL) { web.load(URLRequest(url: url)) }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        polling = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                if UIApplication.shared.applicationState == .active { self?.checkPayment() }
                do { try await Task.sleep(nanoseconds: 5_000_000_000) } catch { break }
            }
        }
    }
    override func viewDidDisappear(_ animated: Bool) { super.viewDidDisappear(animated); polling?.cancel(); polling = nil }
    @objc private func checkPayment() {
        guard !checking && !confirmed else { return }; checking = true
        Task { @MainActor [weak self] in
            guard let self else { return }; defer { checking = false }
            do {
                try await BTSubscriptionNetwork.shared.refresh(); let records = try await BTSubscriptionNetwork.shared.orders()
                guard let result = records.first(where: { $0.id == order.orderID }) else { return }
                if result.status == "paid" {
                    // Callback may arrive between the first entitlement refresh and order lookup.
                    try await BTSubscriptionNetwork.shared.refresh()
                    confirmed = true; polling?.cancel(); web.stopLoading(); web.isHidden = true; status.textColor = .systemGreen
                    status.text = "支付成功，服务器已确认到账。\n订阅到期：\(BTSubscriptionUI.date(BTSubscription.shared.snapshot.expiresAt?.timeIntervalSince1970))\n可返回继续使用。"
                } else if result.status != "pending" { status.text = "\(BTSubscriptionUI.orderStatus(result.status))。如已扣款，请勿重复支付，可点“查询到账”等待确认。" }
            } catch { status.text = "暂未确认到账，可点击“查询到账”重试。若已付款请勿重复支付。" }
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }; let scheme = url.scheme?.lowercased() ?? ""
        if scheme == "https", url.user == nil, url.password == nil {
            if action.targetFrame == nil { decisionHandler(.cancel); web.load(action.request) } else { decisionHandler(.allow) }; return
        }
        if url.absoluteString == "about:blank" { decisionHandler(.allow); return }; decisionHandler(.cancel)
        guard ["alipay", "alipays", "weixin"].contains(scheme) else { status.text = "已阻止不安全或不支持的支付跳转，请联系管理员检查HTTPS支付通道。"; return }
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: "打开支付App", message: "此通道需要打开\(scheme == "weixin" ? "微信" : "支付宝")完成付款，付款后请返回BTmobile查询到账。", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "继续支付", style: .default) { [weak self] _ in
            UIApplication.shared.open(url, options: [:]) { opened in
                if !opened { DispatchQueue.main.async { self?.status.text = "无法打开支付App，请确认已安装，或返回选择其他通道。" } }
            }
        }); present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { status.text = "支付页加载失败。若已扣款请先查询到账，不要重复付款。" }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        self.webView(webView, didFailProvisionalNavigation: navigation, withError: error)
    }
}
