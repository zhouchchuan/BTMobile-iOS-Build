//
//  VLCPlayerViewModel.swift
//  iTorrent
//
//  Created by Даниил Виноградов on 21.03.2026.
//

import Foundation
import MvvmFoundation
import LibTorrent
import SwiftVLC

extension VLCPlayerViewModel {
    struct Config {
        let url: URL
        let torrentPair: (handle: TorrentHandle, fileIndex: Int)?
    }
}

class VLCPlayerViewModel: BaseViewModelWith<VLCPlayerViewModel.Config>, ObservableObject {
    private static let supportedMediaExtensions: Set<String> = [
        // Video containers
        "mp4", "m4v", "mkv", "webm", "avi", "mov", "ts", "m2ts", "mts",
        "flv", "3gp", "mpg", "mpeg", "vob", "wmv", "asf", "ogv", "rm", "rmvb",
        // Audio containers and elementary streams
        "mp3", "aac", "flac", "wav", "ogg", "m4a", "opus", "wma", "aiff", "aif",
        "amr", "mid", "midi", "ac3", "eac3", "dts", "mka"
    ]

    private(set) var url: URL!
    private(set) var torrentPair: (handle: TorrentHandle, fileIndex: Int)?

    @Published var showOverlay: Bool = true
    @Published var isManualFullscreen: Bool = false
    @Published var segmentedProgress: [Double]?
    private var playbackTeardownHandler: (() -> Void)?
    private var lastStreamingBucket: Int?

#if !os(visionOS)
    @Published var pipController: PiPController?
#endif

    override func prepare(with model: Config) {
        self.url = model.url
        self.torrentPair = model.torrentPair
        binding()
    }

    private func binding() {
        guard let torrentPair else { return }
        refreshSegmentedProgress()
        disposeBag.bind {
            torrentPair.handle.updatePublisher.sink { [weak self] update in
                guard let self else { return }
                refreshSegmentedProgress()
            }
        }
    }

    private func refreshSegmentedProgress() {
        guard let torrentPair else { return }
        let file = torrentPair.handle.snapshot.files[torrentPair.fileIndex]
        segmentedProgress = file.segmentedProgress
    }

    static func validateURL(_ url: URL) -> Bool {
        guard url.isFileURL else { return false }
        guard url.isFileURL, (try? url.checkResourceIsReachable()) == true else { return false }

        let resourceValues = try? url.resourceValues(forKeys: [.isRegularFileKey])
        return resourceValues?.isRegularFile != false
    }

    static func isSupportedMediaURL(_ url: URL) -> Bool {
        supportedMediaExtensions.contains(url.pathExtension.lowercased())
    }

    static func canOpenInVLC(_ url: URL, timeoutMilliseconds: Int32 = 3_000) async -> Media? {
        guard validateURL(url), isSupportedMediaURL(url), let media = try? Media(url: url) else {
            return nil
        }

        do {
            let metadata = try await media.parse(timeout: .milliseconds(Int64(timeoutMilliseconds)))
            if !media.tracks().isEmpty { return media }
            if (metadata.duration ?? media.duration)?.milliseconds ?? 0 > 0 { return media }
        } catch {}

        // A partially downloaded video can be valid even when metadata parsing
        // times out. The VLC player and libtorrent piece priorities will handle
        // buffering once playback begins.
        return media
    }

    static func canOpenInVLCSync(_ url: URL, timeoutMilliseconds: Int32 = 100) -> Media? {
        guard validateURL(url), isSupportedMediaURL(url), let media = try? Media(url: url) else {
            return nil
        }
        return media
    }

    func registerPlaybackTeardownHandler(_ handler: @escaping () -> Void) {
        playbackTeardownHandler = handler
    }

    func requestPlaybackTeardown() {
        let handler = playbackTeardownHandler
        playbackTeardownHandler = nil
        handler?()
    }

    func clearPlaybackTeardownHandler() {
        playbackTeardownHandler = nil
    }

    /// Keeps a short libtorrent deadline window in front of VLC's read head.
    /// Updates are bucketed so ordinary playback events do not flood the
    /// torrent session with duplicate piece-priority requests.
    func prioritizeStreaming(playbackTime: TimeInterval, duration: TimeInterval, force: Bool = false) {
        guard let torrentPair, duration > 0 else { return }

        let progress = min(max(playbackTime / duration, 0), 1)
        let bucket = Int((progress * 200).rounded(.down))
        guard force || bucket != lastStreamingBucket else { return }

        lastStreamingBucket = bucket
        torrentPair.handle.prioritizeStreaming(
            fileIndex: torrentPair.fileIndex,
            progress: progress,
            windowPieceCount: 64
        )
    }

    func finishStreamingPlayback() {
        guard let torrentPair else { return }
        lastStreamingBucket = nil
        torrentPair.handle.clearStreamingPriorities()
    }
}
