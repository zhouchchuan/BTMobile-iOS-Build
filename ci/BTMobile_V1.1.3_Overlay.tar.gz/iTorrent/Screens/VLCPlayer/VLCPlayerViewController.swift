//
//  VLCPlayerViewController.swift
//  iTorrent
//
//  Created by Даниил Виноградов on 21.03.2026.
//

import Combine
import MvvmFoundation
import SwiftUI
import UIKit
import AVKit
import MediaPlayer
import SwiftVLC

private enum VLCPlaybackConfiguration {
    static let subtitleFontURL = Bundle.main.url(
        forResource: "NotoSansSC-VF",
        withExtension: "ttf",
        subdirectory: "Fonts"
    )

    static let instance: VLCInstance = {
        var arguments = VLCInstance.defaultArguments
        if let fontURL = subtitleFontURL {
            arguments.append("--ssa-fontsdir=\(fontURL.deletingLastPathComponent().path)")
            arguments.append("--freetype-font=Noto Sans SC")
            arguments.append("--freetype-monofont=Noto Sans SC")
        }

        let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        return (try? VLCInstance(
            arguments: arguments,
            applicationName: "BT Mobile",
            httpUserAgent: "BTMobile/\(appVersion)"
        )) ?? .shared
    }()
}

struct TracksMenuView: View {
    let tracks: [Track]
    @Binding var selectedTrack: Track?
    let title: LocalizedStringKey
    let systemImage: String

    var body: some View {
        Menu {
            Section {
                ForEach(tracks) { track in
                    Toggle(track.title, isOn: .init(get: {
                        selectedTrack?.id == track.id
                    }, set: { value in
                        guard value else { return }
                        selectedTrack = track
                    }))
                }
            } header: {
                Text(title)
            }
        } label: {
            Image(systemName: systemImage)
        }
        .menuOrder(.fixed)
        .labelStyle(.iconOnly)
        .imageScale(.medium)
        .accessibilityLabel(title)
    }
}

struct PlaybackRateMenuView: View {
    let rates: [Float]
    @Binding var selectedRate: Float

    var body: some View {
        Menu {
            Section {
                ForEach(rates, id: \.self) { rate in
                    Toggle(rate.formattedRate, isOn: .init(get: {
                        selectedRate == rate
                    }, set: { value in
                        guard value else { return }
                        selectedRate = rate
                    }))
                }
            } header: {
                Text("Playback Speed")
            }
        } label: {
            Image(systemName: "speedometer")
        }
        .menuOrder(.fixed)
        .labelStyle(.iconOnly)
        .imageScale(.medium)
        .accessibilityLabel("Playback Speed")
    }
}

private extension Float {
    var formattedRate: String {
        if self == floor(self) {
            return "\(Int(self))x"
        }

        return String(format: "%.2gx", self)
    }
}

private extension Track {
    var title: String {
        [trackDescription ?? name, (localizedLanguageName ?? language).map { "[\($0)]" }]
            .compactMap { $0 }
            .joined(separator: " - ")
    }

    var localizedLanguageName: String? {
        guard let language else { return nil }
        return Locale(identifier: "en").localizedString(forLanguageCode: language)
    }

    var chineseSubtitleScore: Int? {
        let normalizedLanguage = language?
            .lowercased()
            .replacingOccurrences(of: "_", with: "-")
        let chineseLanguageCodes = ["zh", "chi", "zho", "chs", "cht", "cmn", "yue"]
        let label = [name, trackDescription, language]
            .compactMap { $0 }
            .joined(separator: " ")
            .lowercased()

        var score = 0
        if let normalizedLanguage,
           chineseLanguageCodes.contains(where: {
               normalizedLanguage == $0 || normalizedLanguage.hasPrefix("\($0)-")
           }) {
            score = 100
        }

        let chineseLabels = [
            "中文", "简体", "簡體", "简中", "簡中", "繁体", "繁體", "繁中",
            "中字", "中英", "chinese", "mandarin", "cantonese"
        ]
        if chineseLabels.contains(where: { label.contains($0) }) {
            score = max(score, 80)
        }

        guard score > 0 else { return nil }

        let prefersTraditional = Locale.preferredLanguages.contains {
            let value = $0.lowercased()
            return value.contains("hant") || value.contains("-tw") || value.contains("-hk")
        }
        let simplifiedLabels = ["简体", "簡體", "简中", "簡中", "chs", "hans"]
        let traditionalLabels = ["繁体", "繁體", "繁中", "cht", "hant"]

        if prefersTraditional {
            if traditionalLabels.contains(where: { label.contains($0) }) { score += 20 }
        } else if simplifiedLabels.contains(where: { label.contains($0) }) {
            score += 20
        }

        return score
    }
}

class VLCPlayerViewController: BaseHostingController<VLCPlayerViewController.Body>, MvvmViewControllerProtocol {
    var viewModel: VLCPlayerViewModel
    private var disposeBag = DisposeBag() // [AnyCancellable] = []
#if !os(visionOS)
    private var pipEventsTask: Task<Void, Never>?
    private weak var observedPictureInPictureController: PiPController?
    private var isDismissedForPictureInPicture = false
    private var isRestoringFromPictureInPicture = false
    private var pictureInPicturePresentationController: UIViewController?
#endif

    override var useMarqueeLabel: Bool { true }
    override var shouldAutorotate: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        viewModel.isManualFullscreen ? .landscape : .allButUpsideDown
    }
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        viewModel.isManualFullscreen ? .landscapeRight : .portrait
    }

    required init(viewModel: VLCPlayerViewModel) {
        self.viewModel = viewModel
        super.init(rootView: Body(viewModel: viewModel))
    }

    @available(*, unavailable)
    @MainActor @preconcurrency dynamic required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = viewModel.url.lastPathComponent
        navigationItem.largeTitleDisplayMode = .never

        do {
            try AVAudioSession.sharedInstance().setCategory(
                .playback,
                mode: .moviePlayback,
                options: [.mixWithOthers]
            )
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {}

        navigationItem.rightBarButtonItem = .init(systemItem: .close, primaryAction: .init { [unowned self] _ in
            setManualFullscreen(false)
            dismiss()
        })

        disposeBag.bind {
#if !os(visionOS)
            viewModel.$pipController
                .compactMap { $0 }
                .sink { [weak self] controller in
                    self?.configurePictureInPicture(controller)
                }
#endif
            viewModel.$isManualFullscreen
                .removeDuplicates()
                .dropFirst()
                .receive(on: DispatchQueue.main)
                .sink { [weak self] isFullscreen in
                    self?.applyManualFullscreen(isFullscreen)
                }
            #if !os(visionOS)
            Air.shared.$connected.combineLatest(viewModel.$showOverlay)
                .sink { [weak self] aired, value in
                    let show = aired || value
                    self?.navigationController?.setNavigationBarHidden(!show, animated: true)
                }
            #else
            viewModel.$showOverlay
                .sink { [weak self] show in
                    self?.navigationController?.setNavigationBarHidden(!show, animated: true)
                }
            #endif
        }
    }

    private func setManualFullscreen(_ enabled: Bool) {
        guard viewModel.isManualFullscreen != enabled else { return }
        viewModel.isManualFullscreen = enabled
    }

    private func applyManualFullscreen(_ enabled: Bool) {
        setNeedsUpdateOfSupportedInterfaceOrientations()
        navigationController?.setNeedsUpdateOfSupportedInterfaceOrientations()

#if !os(visionOS)
        guard let scene = view.window?.windowScene ?? UIApplication.shared.keySceneWindow?.windowScene else { return }
        let orientations: UIInterfaceOrientationMask = enabled ? .landscape : .portrait
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: orientations)) { error in
            print("BTMobile manual fullscreen geometry update failed: \(error.localizedDescription)")
        }
#endif
    }

#if !os(visionOS)
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if let controller = viewModel.pipController {
            configurePictureInPicture(controller)
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        if viewModel.isManualFullscreen, viewModel.pipController?.isActive != true {
            setManualFullscreen(false)
        }
        guard viewModel.pipController?.isActive != true else { return }
        isDismissedForPictureInPicture = false
        isRestoringFromPictureInPicture = false
        pictureInPicturePresentationController = nil
        pipEventsTask?.cancel()
        pipEventsTask = nil
        observedPictureInPictureController?.onRestoreUserInterface = nil
        observedPictureInPictureController = nil
    }

    private func configurePictureInPicture(_ controller: PiPController) {
        guard viewModel.pipController === controller else { return }

        controller.onRestoreUserInterface = { [weak self] completion in
            Task { @MainActor in
                self?.restoreFromPictureInPicture(completion: completion) ?? completion(false)
            }
        }

        guard observedPictureInPictureController !== controller else { return }
        observedPictureInPictureController?.onRestoreUserInterface = nil
        pipEventsTask?.cancel()
        observedPictureInPictureController = controller
        pipEventsTask = Task { @MainActor [self, weak controller] in
            guard let controller else { return }
            for await event in controller.pipEvents {
                guard !Task.isCancelled else { return }
                switch event {
                case .didStart:
                    dismissForPictureInPicture()
                case .didStop:
                    let shouldTearDownPlayback = isDismissedForPictureInPicture && !isRestoringFromPictureInPicture
                    isDismissedForPictureInPicture = false
                    isRestoringFromPictureInPicture = false
                    pictureInPicturePresentationController = nil

                    if shouldTearDownPlayback {
                        viewModel.requestPlaybackTeardown()
                        controller.onRestoreUserInterface = nil
                        pipEventsTask?.cancel()
                        pipEventsTask = nil
                        observedPictureInPictureController = nil
                    }
                default:
                    break
                }
            }
        }
    }

    private func dismissForPictureInPicture() {
        guard !isDismissedForPictureInPicture else { return }
        let controllerToRestore = navigationController ?? self
        pictureInPicturePresentationController = controllerToRestore
        isDismissedForPictureInPicture = true
        isRestoringFromPictureInPicture = false
        controllerToRestore.dismiss(animated: true)
    }

    private func restoreFromPictureInPicture(completion: @escaping @MainActor (Bool) -> Void) {
        let controllerToPresent = pictureInPicturePresentationController ?? navigationController ?? self
        isRestoringFromPictureInPicture = true

        if controllerToPresent.presentingViewController != nil || controllerToPresent.view.window != nil {
            didRestoreFromPictureInPicture()
            completion(true)
            return
        }

        guard let presenter = UIApplication.shared.keySceneWindow?.rootViewController?.topPresented else {
            isRestoringFromPictureInPicture = false
            completion(false)
            return
        }

        presenter.present(controllerToPresent, animated: true) {
            self.didRestoreFromPictureInPicture()
            completion(true)
        }
    }

    private func didRestoreFromPictureInPicture() {
        isDismissedForPictureInPicture = false
        isRestoringFromPictureInPicture = false
        pictureInPicturePresentationController = nil
    }
#endif

    struct Body: View {
        @ObservedObject var viewModel: VLCPlayerViewModel

        var body: some View {
            VLCPlayerView(viewModel: viewModel)
#if !os(visionOS)
                .environmentObject(Air.shared)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            viewModel.pipController?.toggle()
                        } label: {
                            Image(systemName: "pip")
                                .font(.callout)
                                .fontWeight(.semibold)
                        }
                    }
                }
#endif
        }
    }

    struct VLCPlayerView: View {
#if !os(visionOS)
        @EnvironmentObject var airPlay: Air
#endif
        @ObservedObject var viewModel: VLCPlayerViewModel
        @State private var player = Player(instance: VLCPlaybackConfiguration.instance)
        @StateObject private var rendererRouteController = RendererRouteController()
        @State private var currentPlaybackTime: TimeInterval = 0
        @State private var mediaTimeDuration: TimeInterval = 60 * 6
        @State private var isSeeking: Bool = false
        @State private var audioTracks: [Track] = []
        @State private var textTracks: [Track] = []
        @State private var selectedAudioTrack: Track?
        @State private var selectedTextTrack: Track?
        @State private var requestedSubtitleTrackID: String?
        @State private var didSelectInitialSubtitle = false
        @State private var playbackRate: Float = 1
        @State private var didStartPlayback = false
        @State private var isRestoringPlayback = false
        @State private var pendingPausedSeekRefreshTime: TimeInterval?
        @State private var remoteCommands = RemoteCommandController()
        @Namespace private var glassNamespace
        private let playbackRates: [Float] = [0.5, 0.75, 1, 1.25, 1.5, 2]
        private let nowPlayingCenter = MPNowPlayingInfoCenter.default()

        var body: some View {
            WithPerceptionTracking {
                content
            }
            .task {
                await preparePlaybackIfNeeded()
            }
            .task {
                await observePlayerEvents()
            }
            .onAppear {
                rendererRouteController.start()
                configureRemoteCommandCenter()
                viewModel.registerPlaybackTeardownHandler {
                    tearDownPlayback(force: true)
                }
            }
            .onDisappear {
                tearDownPlayback()
            }
            .onChange(of: playbackRate) { newRate in
                setPlaybackRate(newRate)
            }
            .onChange(of: selectedAudioTrack) { track in
                player.selectedAudioTrack = track
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                restorePlaybackAfterForeground()
            }
        }
    }
}

// MARK: - Overlay State
private extension VLCPlayerViewController.VLCPlayerView {
    var showOverlay: Bool {
#if !os(visionOS)
        viewModel.showOverlay || airPlay.connected
#else
        viewModel.showOverlay
#endif
    }

    var showsPlayingState: Bool {
        isRestoringPlayback ? false : player.isPlaying
    }
}

// MARK: - Layout
private extension VLCPlayerViewController.VLCPlayerView {
    var content: some View {
        ZStack(alignment: .bottom) {
            Color(showOverlay ? .systemGroupedBackground : .black)
                .ignoresSafeArea()

            videoOutput
                .ignoresSafeArea()

            if showOverlay {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
            }

            Color.clear
                .contentShape(Rectangle())
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.28)) {
                        viewModel.showOverlay.toggle()
                    }
                }

            ZStack {
                CompatibilityGlassContainer(spacing: 24) {
                    VStack {
#if !os(visionOS)
                        if airPlay.connected {
                            Label("Displaying via AirPlay", systemImage: "airplayvideo")
                                .font(.title3.weight(.semibold))
                                .padding(.horizontal, 20)
                                .padding(.vertical, 14)
                        }
#endif
                        if showOverlay {
                            overlayButtons
                                .transition(.opacity.combined(with: .scale(scale: 0.96)))
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .ignoresSafeArea()

                CompatibilityGlassContainer(spacing: 16) {
                    if showOverlay {
                        VStack(alignment: .trailing, spacing: 16) {
                            controlsBar

                            TimelineView(
                                mediaLengthTime: mediaTimeDuration,
                                currentPlaybackTime: $currentPlaybackTime,
                                isSeeking: $isSeeking,
                                availability: viewModel.segmentedProgress,
                                onScrubChanged: { time in
                                    seek(to: time, fast: true)
                                },
                                onScrubEnded: { time in
                                    seek(to: time, fast: false)
                                }
                            )
                            .compatibilityGlassID("timeline", in: glassNamespace)
                            .compatibilityGlassTransition()
                        }
                        .padding()
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    var controlsBar: some View {
        HStack {
            HStack(spacing: 16) {
                PlaybackRateMenuView(
                    rates: playbackRates,
                    selectedRate: $playbackRate
                )

                RendererRouteMenuView(
                    player: player,
                    routeController: rendererRouteController
                )
            }
            .padding(.horizontal)
            .frame(height: 44)
            .compatibilityGlassEffect(interactive: true)
            .compatibilityGlassID("controls", in: glassNamespace)
            .compatibilityGlassTransition()

            Spacer()

            HStack(spacing: 16) {
                TracksMenuView(
                    tracks: audioTracks,
                    selectedTrack: $selectedAudioTrack,
                    title: "Audio",
                    systemImage: "waveform"
                )

                TracksMenuView(
                    tracks: textTracks,
                    selectedTrack: Binding(
                        get: { selectedTextTrack },
                        set: { selectSubtitleTrack($0) }
                    ),
                    title: "Subtitles",
                    systemImage: "text.alignleft"
                )

#if !os(visionOS)
                Button {
                    viewModel.isManualFullscreen.toggle()
                } label: {
                    Image(systemName: viewModel.isManualFullscreen
                          ? "arrow.down.right.and.arrow.up.left"
                          : "arrow.up.left.and.arrow.down.right")
                }
                .accessibilityLabel(viewModel.isManualFullscreen ? "退出全屏" : "全屏播放")
#endif
            }
            .padding(.horizontal)
            .frame(height: 44)
            .compatibilityGlassEffect(interactive: true)
            .compatibilityGlassID("controls", in: glassNamespace)
            .compatibilityGlassTransition()
        }
        .tint(Color.secondary)
        .font(.title3.weight(.semibold))
    }

    var overlayButtons: some View {
        HStack(spacing: 32) {
            PlayerButton(size: .small, imageName: "10.arrow.trianglehead.counterclockwise") {
                skip(by: -10)
            }
            .compatibilityGlassID("backward", in: glassNamespace)

            PlayerButton(size: .big, imageName: showsPlayingState ? "pause.fill" : "play.fill") {
                guard !isRestoringPlayback else { return }
                togglePlayback()
            }
            .compatibilityGlassID("playPause", in: glassNamespace)

            PlayerButton(size: .small, imageName: "10.arrow.trianglehead.clockwise") {
                skip(by: 10)
            }
            .compatibilityGlassID("forward", in: glassNamespace)
        }
    }
}

// MARK: - AirPlay and Picture in Picture
private extension VLCPlayerViewController.VLCPlayerView {
    @ViewBuilder
    var videoOutput: some View {
#if !os(visionOS)
        PiPVideoView(
            player,
            controller: $viewModel.pipController,
            onSurfaceReady: { surface in
                Air.play(surface) {
                    player.refreshVideoOutputAfterDisplayMove()
                }
            }
        )
#else
        VideoView(player)
#endif
    }
}

// MARK: - Playback Lifecycle
private extension VLCPlayerViewController.VLCPlayerView {
    func preparePlaybackIfNeeded() async {
        guard !didStartPlayback else { return }
        didStartPlayback = true
        configureNowPlayingMetadata()

        do {
            let media = try Media(url: viewModel.url)
            configureChineseSubtitleFonts(for: media)
            if let metadata = try? await media.parse(timeout: .seconds(1)), let duration = metadata.duration {
                updateMediaTimeDuration(duration.timeInterval)
                updateNowPlaying(duration: duration.timeInterval)
                viewModel.prioritizeStreaming(playbackTime: 0, duration: duration.timeInterval, force: true)
            }
            try Task.checkCancellation()
            try player.play(media)
            setPlaybackRate(playbackRate)
            syncTracksFromPlayer()
            updateNowPlayingPlaybackState()
        } catch is CancellationError {
            player.stop()
        } catch {
            didStartPlayback = false
        }
    }

    /// The bundled libVLC build predates the Apple/libass CoreText provider
    /// fix. Give both subtitle paths an explicit CJK-capable font: libass
    /// scans the directory for embedded ASS/SSA tracks, while FreeType uses
    /// the registered family for SRT/WebVTT and other text subtitle formats.
    func configureChineseSubtitleFonts(for media: Media) {
        guard let fontURL = VLCPlaybackConfiguration.subtitleFontURL else { return }

        media.addOption(":ssa-fontsdir=\(fontURL.deletingLastPathComponent().path)")
        media.addOption(":freetype-font=Noto Sans SC")
        media.addOption(":freetype-monofont=Noto Sans SC")
    }

    func observePlayerEvents() async {
        for await event in player.events {
            switch event {
            case .timeChanged(let time):
                guard !isSeeking else { continue }
                let newPlaybackTime = max(time.timeInterval, 0)
                if abs(currentPlaybackTime - newPlaybackTime) > 0.05 {
                    currentPlaybackTime = newPlaybackTime
                }
                viewModel.prioritizeStreaming(playbackTime: newPlaybackTime, duration: mediaTimeDuration)
                updateNowPlaying()
            case .lengthChanged(let duration):
                updateMediaTimeDuration(duration.timeInterval)
                updateNowPlaying(duration: duration.timeInterval)
            case .tracksChanged, .mediaChanged:
                syncTracksFromPlayer()
            case .stateChanged:
                updateNowPlayingPlaybackState()
            case .encounteredError:
                rendererRouteController.handlePlaybackFailure(on: player)
                updateNowPlayingPlaybackState()
            case .endReached:
                currentPlaybackTime = mediaTimeDuration
                updateNowPlayingPlaybackState()
            default:
                break
            }
        }
    }

    func tearDownPlayback(force: Bool = false) {
#if !os(visionOS)
        guard force || viewModel.pipController?.isActive != true else { return }
        Air.stop()
#endif
        rendererRouteController.stop()
        player.stop()
        remoteCommands.tearDown()
        viewModel.finishStreamingPlayback()
        viewModel.clearPlaybackTeardownHandler()
    }

    private func updateMediaTimeDuration(_ duration: TimeInterval) {
        guard mediaTimeDuration != duration else { return }
        mediaTimeDuration = duration
    }
}

// MARK: - Remote Commands
private extension VLCPlayerViewController.VLCPlayerView {
    func configureRemoteCommandCenter() {
        remoteCommands.configure(
            supportedPlaybackRates: playbackRates,
            play: {
                try? player.play()
                refreshVideoAfterPausedSeekIfNeeded()
                updateNowPlayingPlaybackState()
            },
            pause: {
                player.pause()
                updateNowPlayingPlaybackState()
            },
            toggle: {
                togglePlayback()
            },
            seek: { time in
                seek(to: time)
            },
            skip: { interval in
                skip(by: interval)
            },
            rate: { rate in
                playbackRate = rate
                setPlaybackRate(rate)
            }
        )
    }
}

// MARK: - Tracks
private extension VLCPlayerViewController.VLCPlayerView {
    func syncTracksFromPlayer() {
        audioTracks = player.audioTracks
        textTracks = player.subtitleTracks

        if let selected = player.selectedAudioTrack {
            selectedAudioTrack = selected
        } else if selectedAudioTrack == nil {
            selectedAudioTrack = audioTracks.first
        }

        if !didSelectInitialSubtitle, !textTracks.isEmpty {
            didSelectInitialSubtitle = true
            let preferredChinese = textTracks
                .compactMap { track in track.chineseSubtitleScore.map { (track, $0) } }
                .max { $0.1 < $1.1 }?.0
            let preferred = preferredChinese ?? player.selectedSubtitleTrack ?? textTracks.first

            selectSubtitleTrack(preferred)
        } else if let requestedSubtitleTrackID,
                  let requested = textTracks.first(where: { $0.id == requestedSubtitleTrackID }) {
            // Track-change events can briefly report VLC's previous selection.
            // Preserve the user's requested track until VLC confirms it.
            selectedTextTrack = requested
            if player.selectedSubtitleTrack?.id != requestedSubtitleTrackID {
                player.selectedSubtitleTrack = requested
            }
        } else if let selected = player.selectedSubtitleTrack {
            selectedTextTrack = selected
            requestedSubtitleTrackID = selected.id
        } else if selectedTextTrack == nil {
            selectSubtitleTrack(textTracks.first)
        }
    }

    func selectSubtitleTrack(_ track: Track?) {
        requestedSubtitleTrackID = track?.id
        selectedTextTrack = track
        player.selectedSubtitleTrack = track

        guard let requestedID = track?.id else { return }

        // libVLC may publish an intermediate tracksChanged event while the
        // embedded subtitle decoder is being attached. Reapply the selected
        // stable track ID a few times so Chinese/English switching cannot be
        // undone by a stale event.
        Task { @MainActor in
            for delay in [80, 180, 350] {
                try? await Task.sleep(for: .milliseconds(delay))
                guard requestedSubtitleTrackID == requestedID else { return }
                guard let current = player.subtitleTracks.first(where: { $0.id == requestedID }) else { continue }
                selectedTextTrack = current
                if player.selectedSubtitleTrack?.id != requestedID {
                    player.selectedSubtitleTrack = current
                }
            }
        }
    }
}

// MARK: - Transport Controls
private extension VLCPlayerViewController.VLCPlayerView {
    func setPlaybackRate(_ rate: Float) {
        try? player.setPlaybackRate(PlaybackRate(rate))
        updateNowPlayingPlaybackState()
    }

    func togglePlayback() {
        player.togglePlayPause()
        refreshVideoAfterPausedSeekIfNeeded()
        updateNowPlayingPlaybackState()
    }

    func refreshVideoAfterPausedSeekIfNeeded() {
        guard let time = pendingPausedSeekRefreshTime else { return }

        Task { @MainActor in
            for _ in 0..<5 {
                try? await Task.sleep(for: .milliseconds(80))
                guard pendingPausedSeekRefreshTime == time else { return }
                guard player.isPlaying else { continue }
                pendingPausedSeekRefreshTime = nil
                seek(to: time)
                return
            }
        }
    }

    func seek(to time: TimeInterval, fast: Bool = false) {
        let duration = max(mediaTimeDuration, 0)
        let clampedTime = min(max(time, 0), duration)
        let wasPlaying = player.isPlaying
        currentPlaybackTime = clampedTime
        viewModel.prioritizeStreaming(playbackTime: clampedTime, duration: duration, force: !fast)

        guard player.isSeekable || player.duration != nil else {
            updateNowPlaying()
            return
        }

        try? player.seek(to: .milliseconds(Int64((clampedTime * 1_000).rounded())), fast: fast)
        if wasPlaying {
            pendingPausedSeekRefreshTime = nil
        } else if !fast {
            pendingPausedSeekRefreshTime = clampedTime
        }
        updateNowPlaying()
    }

    func skip(by interval: TimeInterval) {
        seek(to: currentPlaybackTime + interval)
    }
}

// MARK: - Foreground Restore
private extension VLCPlayerViewController.VLCPlayerView {
    func restorePlaybackAfterForeground() {
        guard didStartPlayback, !player.isPlaying, !isRestoringPlayback else { return }
        let playbackTime = currentPlaybackTime
        isRestoringPlayback = true
        Task { @MainActor in
            defer {
                isRestoringPlayback = false
                updateNowPlayingPlaybackState()
            }
            await player.stopAndWait()
            try? player.play()
            try? await Task.sleep(for: .milliseconds(200))
            seek(to: playbackTime)
            await scrubMinimallyForRestoredVideoFrame(around: playbackTime)
            player.pause()
            currentPlaybackTime = playbackTime
        }
    }

    private func scrubMinimallyForRestoredVideoFrame(around time: TimeInterval) async {
        guard let scrubTime = minimalScrubTime(around: time) else { return }
        try? await Task.sleep(for: .milliseconds(80))
        seek(to: scrubTime, fast: true)
        try? await Task.sleep(for: .milliseconds(80))
        seek(to: time)
    }

    private func minimalScrubTime(around time: TimeInterval) -> TimeInterval? {
        let duration = max(mediaTimeDuration, 0)
        guard duration > 0 else { return nil }

        let offset: TimeInterval = 0.05
        if time + offset <= duration {
            return time + offset
        }
        if time - offset >= 0 {
            return time - offset
        }
        return nil
    }
}

// MARK: - Now Playing
private extension VLCPlayerViewController.VLCPlayerView {
    func configureNowPlayingMetadata() {
        var info = nowPlayingCenter.nowPlayingInfo ?? [:]
        info[MPMediaItemPropertyTitle] = viewModel.url.deletingPathExtension().lastPathComponent
        info[MPMediaItemPropertyPlaybackDuration] = max(mediaTimeDuration, 0)
        info[MPNowPlayingInfoPropertyMediaType] = MPNowPlayingInfoMediaType.video.rawValue

        let artworkImage = UIImage.icon(forFileURL: viewModel.url, size: 512)
        info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: artworkImage.size) { _ in artworkImage }

        nowPlayingCenter.nowPlayingInfo = info
        updateNowPlayingPlaybackState()
    }

    func updateNowPlaying(duration: TimeInterval? = nil) {
        var info = nowPlayingCenter.nowPlayingInfo ?? [:]
        if let duration {
            info[MPMediaItemPropertyPlaybackDuration] = max(duration, 0)
        }
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = max(currentPlaybackTime, 0)
        info[MPNowPlayingInfoPropertyPlaybackRate] = player.isPlaying ? Double(playbackRate) : 0
        nowPlayingCenter.nowPlayingInfo = info
    }

    func updateNowPlayingPlaybackState() {
        nowPlayingCenter.playbackState = player.isPlaying ? .playing : .paused
        updateNowPlaying()
    }
}

// MARK: - Player Button
private extension VLCPlayerViewController.VLCPlayerView {
    struct PlayerButton: View {
        enum Size {
            case small
            case big

            var view: Double {
                switch self {
                case .small:
                    62
                case .big:
                    92
                }
            }

            var font: Double {
                switch self {
                case .small:
                    32
                case .big:
                    46
                }
            }
        }

        var size: Size
        var imageName: String
        var action: () -> Void

        var body: some View {
            let button = Button {
                action()
            } label: {
                let image = Image(systemName: imageName)
                    .frame(width: size.view, height: size.view)
                    .font(.system(size: size.font, weight: .medium))
                    .foregroundStyle(Color.white)

                if #available(iOS 17.0, *) {
                    image.contentTransition(.symbolEffect(.replace.downUp, options: .speed(3)))
                } else {
                    image
                }
            }

            button
                .compatibilityGlassEffect(isClear: true, interactive: true)
                .compatibilityGlassTransition()
        }
    }
}

private final class RemoteCommandController {
    private var remoteCommandTargets: [Any] = []
    private let remoteCommandCenter = MPRemoteCommandCenter.shared()
    private let nowPlayingCenter = MPNowPlayingInfoCenter.default()

    func configure(
        supportedPlaybackRates: [Float],
        play: @escaping @MainActor @Sendable () -> Void,
        pause: @escaping @MainActor @Sendable () -> Void,
        toggle: @escaping @MainActor @Sendable () -> Void,
        seek: @escaping @MainActor @Sendable (TimeInterval) -> Void,
        skip: @escaping @MainActor @Sendable (TimeInterval) -> Void,
        rate: @escaping @MainActor @Sendable (Float) -> Void
    ) {
        guard remoteCommandTargets.isEmpty else { return }

        let playTarget = remoteCommandCenter.playCommand.addTarget { _ in
            Self.perform(play)
        }
        let pauseTarget = remoteCommandCenter.pauseCommand.addTarget { _ in
            Self.perform(pause)
        }
        let toggleTarget = remoteCommandCenter.togglePlayPauseCommand.addTarget { _ in
            Self.perform(toggle)
        }
        let seekTarget = remoteCommandCenter.changePlaybackPositionCommand.addTarget { event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            let positionTime = event.positionTime
            return Self.perform { seek(positionTime) }
        }
        let skipForwardTarget = remoteCommandCenter.skipForwardCommand.addTarget { _ in
            Self.perform { skip(10) }
        }
        let skipBackwardTarget = remoteCommandCenter.skipBackwardCommand.addTarget { _ in
            Self.perform { skip(-10) }
        }
        let rateTarget = remoteCommandCenter.changePlaybackRateCommand.addTarget { event in
            guard let event = event as? MPChangePlaybackRateCommandEvent else { return .commandFailed }
            let playbackRate = Float(event.playbackRate)
            return Self.perform { rate(playbackRate) }
        }

        remoteCommandTargets = [playTarget, pauseTarget, toggleTarget, seekTarget, skipForwardTarget, skipBackwardTarget, rateTarget]
        remoteCommandCenter.playCommand.isEnabled = true
        remoteCommandCenter.pauseCommand.isEnabled = true
        remoteCommandCenter.togglePlayPauseCommand.isEnabled = true
        remoteCommandCenter.changePlaybackPositionCommand.isEnabled = true
        remoteCommandCenter.skipForwardCommand.isEnabled = true
        remoteCommandCenter.skipForwardCommand.preferredIntervals = [10]
        remoteCommandCenter.skipBackwardCommand.isEnabled = true
        remoteCommandCenter.skipBackwardCommand.preferredIntervals = [10]
        remoteCommandCenter.changePlaybackRateCommand.isEnabled = true
        remoteCommandCenter.changePlaybackRateCommand.supportedPlaybackRates = supportedPlaybackRates.map(NSNumber.init(value:))
    }

    func tearDown() {
        remoteCommandTargets.forEach { target in
            remoteCommandCenter.playCommand.removeTarget(target)
            remoteCommandCenter.pauseCommand.removeTarget(target)
            remoteCommandCenter.togglePlayPauseCommand.removeTarget(target)
            remoteCommandCenter.changePlaybackPositionCommand.removeTarget(target)
            remoteCommandCenter.skipForwardCommand.removeTarget(target)
            remoteCommandCenter.skipBackwardCommand.removeTarget(target)
            remoteCommandCenter.changePlaybackRateCommand.removeTarget(target)
        }
        remoteCommandTargets.removeAll()
        nowPlayingCenter.nowPlayingInfo = nil
        nowPlayingCenter.playbackState = .stopped
    }

    private static func perform(_ action: @escaping @MainActor @Sendable () -> Void) -> MPRemoteCommandHandlerStatus {
        Task { @MainActor in
            action()
        }
        return .success
    }
}

private extension Duration {
    var timeInterval: TimeInterval {
        TimeInterval(milliseconds) / 1_000
    }
}

#Preview {
    UINavigationController(rootViewController: VLCPlayerViewController(viewModel: .init(with: .init(url: URL(string: "ttest.com")!, torrentPair: nil))))
        .asView
        .ignoresSafeArea()
}
