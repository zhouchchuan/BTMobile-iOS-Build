//
//  TextDocumentPreviewViewController.swift
//  iTorrent
//
//  BT Mobile 1.0.9
//

import CoreFoundation
import UIKit

final class TextDocumentPreviewViewController: UIViewController, UITextViewDelegate {
    private static let previewLimit = 1_048_576
    private static let supportedExtensions: Set<String> = [
        "txt", "text", "log", "md", "nfo", "csv", "srt", "vtt"
    ]

    private let fileURL: URL
    private let textView = UITextView()
    private let statusLabel = UILabel()

    static func canPreview(_ url: URL) -> Bool {
        supportedExtensions.contains(url.pathExtension.lowercased())
    }

    init(url: URL) {
        fileURL = url
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = fileURL.lastPathComponent
        view.backgroundColor = .systemBackground
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            systemItem: .done,
            primaryAction: UIAction { [weak self] _ in
                self?.dismiss(animated: true)
            }
        )

        configureTextView()
        configureStatusLabel()
        loadDocument()
    }

    private func configureTextView() {
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = .systemBackground
        textView.delegate = self
        textView.isEditable = false
        textView.isSelectable = true
        textView.alwaysBounceVertical = true
        textView.adjustsFontForContentSizeCategory = false
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 16, right: 10)
        textView.textContainer.lineFragmentPadding = 0
        textView.linkTextAttributes = [
            .foregroundColor: view.tintColor,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]

        view.addSubview(textView)
    }

    private func configureStatusLabel() {
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.backgroundColor = .secondarySystemBackground
        statusLabel.font = .systemFont(ofSize: 11)
        statusLabel.textColor = .secondaryLabel
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 1

        view.addSubview(statusLabel)

        NSLayoutConstraint.activate([
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            statusLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            statusLabel.heightAnchor.constraint(equalToConstant: 28),

            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: statusLabel.topAnchor)
        ])
    }

    private func loadDocument() {
        do {
            let document = try Self.readDocument(at: fileURL)
            let rendered = Self.render(document.text)
            textView.attributedText = rendered.text

            let truncation = document.isTruncated ? " · 仅预览前 1 MiB" : ""
            statusLabel.text = "\(document.encoding) · \(rendered.linkCount) 个链接\(truncation)"
        } catch {
            textView.font = .systemFont(ofSize: 11.5)
            textView.textColor = .secondaryLabel
            textView.text = error.localizedDescription
            statusLabel.text = fileURL.lastPathComponent
        }
    }

    func textView(
        _ textView: UITextView,
        shouldInteractWith url: URL,
        in characterRange: NSRange,
        interaction: UITextItemInteraction
    ) -> Bool {
        guard let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme) else {
            return false
        }

        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        return false
    }
}

private extension TextDocumentPreviewViewController {
    struct Document {
        let text: String
        let encoding: String
        let isTruncated: Bool
    }

    struct RenderedDocument {
        let text: NSAttributedString
        let linkCount: Int
    }

    enum PreviewError: LocalizedError {
        case unreadable
        case unsupportedEncoding

        var errorDescription: String? {
            switch self {
            case .unreadable:
                return "Unable to read this text file."
            case .unsupportedEncoding:
                return "The text encoding could not be recognized."
            }
        }
    }

    static func readDocument(at url: URL) throws -> Document {
        guard url.isFileURL, (try? url.checkResourceIsReachable()) == true else {
            throw PreviewError.unreadable
        }

        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }

        guard let data = try handle.read(upToCount: previewLimit + 1) else {
            throw PreviewError.unreadable
        }

        let isTruncated = data.count > previewLimit
        let previewData = isTruncated ? Data(data.prefix(previewLimit)) : data

        if previewData.starts(with: [0xEF, 0xBB, 0xBF]),
           let text = decode(previewData.dropFirst(3), as: .utf8, tolerateTruncatedTail: isTruncated) {
            return .init(text: text, encoding: "UTF-8 BOM", isTruncated: isTruncated)
        }

        if previewData.starts(with: [0xFF, 0xFE]),
           let text = decode(previewData.dropFirst(2), as: .utf16LittleEndian, tolerateTruncatedTail: isTruncated) {
            return .init(text: text, encoding: "UTF-16LE", isTruncated: isTruncated)
        }

        if previewData.starts(with: [0xFE, 0xFF]),
           let text = decode(previewData.dropFirst(2), as: .utf16BigEndian, tolerateTruncatedTail: isTruncated) {
            return .init(text: text, encoding: "UTF-16BE", isTruncated: isTruncated)
        }

        if let text = decode(previewData, as: .utf8, tolerateTruncatedTail: isTruncated) {
            return .init(text: text, encoding: "UTF-8", isTruncated: isTruncated)
        }

        let gb18030 = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0632))
        )
        if let text = decode(previewData, as: gb18030, tolerateTruncatedTail: isTruncated) {
            return .init(text: text, encoding: "GB18030", isTruncated: isTruncated)
        }

        throw PreviewError.unsupportedEncoding
    }

    static func decode<S: DataProtocol>(
        _ bytes: S,
        as encoding: String.Encoding,
        tolerateTruncatedTail: Bool
    ) -> String? {
        let data = Data(bytes)
        let maximumTailBytes = tolerateTruncatedTail ? min(4, data.count) : 0

        for tailBytes in 0...maximumTailBytes {
            let end = data.count - tailBytes
            if let result = String(data: data.prefix(end), encoding: encoding) {
                return result
            }
        }
        return nil
    }

    static func render(_ source: String) -> RenderedDocument {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 1.5
        paragraphStyle.paragraphSpacing = 2
        let attributed = NSMutableAttributedString(
            string: source,
            attributes: [
                .font: UIFont.systemFont(ofSize: 11.5),
                .foregroundColor: UIColor.label,
                .paragraphStyle: paragraphStyle
            ]
        )
        let fullRange = NSRange(location: 0, length: attributed.length)
        var links = Set<String>()

        // NSDataDetector can absorb Chinese prose after a URL into the link.
        // Match HTTP(S) explicitly and stop at both western and CJK punctuation.
        let rawURLPattern = #"https?://[^\s<>\"'\[\](){}，。！？；：、“”‘’]+"#
        if let regex = try? NSRegularExpression(pattern: rawURLPattern, options: [.caseInsensitive]) {
            regex.enumerateMatches(in: source, options: [], range: fullRange) { result, _, _ in
                guard let result,
                      let matchRange = Range(result.range, in: source)
                else { return }

                let rawCandidate = String(source[matchRange])
                let candidate = trimmedURLCandidate(rawCandidate)
                guard !candidate.isEmpty,
                      let url = makeWebURL(candidate),
                      isWebURL(url)
                else { return }

                let linkRange = NSRange(location: result.range.location, length: (candidate as NSString).length)
                attributed.addAttribute(.link, value: url, range: linkRange)
                links.insert(url.absoluteString)
            }
        }

        let markdownPattern = #"\[([^\]\r\n]+)\]\((https?://[^\s)]+)\)"#
        if let regex = try? NSRegularExpression(pattern: markdownPattern, options: [.caseInsensitive]) {
            regex.enumerateMatches(in: source, options: [], range: fullRange) { result, _, _ in
                guard let result,
                      result.numberOfRanges > 2,
                      let urlRange = Range(result.range(at: 2), in: source),
                      let url = makeWebURL(trimmedURLCandidate(String(source[urlRange]))),
                      isWebURL(url)
                else { return }

                // Make the readable Markdown title tappable. The raw URL inside
                // the parentheses is already handled by the HTTP(S) matcher.
                attributed.addAttribute(.link, value: url, range: result.range(at: 1))
                links.insert(url.absoluteString)
            }
        }

        return .init(text: attributed, linkCount: links.count)
    }

    static func isWebURL(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        return ["http", "https"].contains(scheme)
    }

    static func trimmedURLCandidate(_ candidate: String) -> String {
        candidate.trimmingCharacters(in: CharacterSet(charactersIn: ".,;:!?)]}>。，；：！？）】》」』”’"))
    }

    static func makeWebURL(_ candidate: String) -> URL? {
        if let url = URL(string: candidate), isWebURL(url) {
            return url
        }
        guard let encoded = candidate.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed),
              let url = URL(string: encoded),
              isWebURL(url)
        else { return nil }
        return url
    }
}
