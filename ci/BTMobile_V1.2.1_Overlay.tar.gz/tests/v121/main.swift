var checks = 0
func check(_ result: @autoclosure () -> Bool, _ name: String) {
    precondition(result(), name); checks += 1; print("PASS: \(name)")
}
let pref = PreferencesStorage.shared
check(BackgroundService.isBackgroundNeeded, "empty enabled app keeps background demand")
pref.isBackgroundDownloadEnabled = false
check(!BackgroundService.isBackgroundNeeded, "background opt-out is respected")
pref.isBackgroundDownloadEnabled = true
BackgroundService.shared.stop()
check(AudioBackgroundService.stopCount == 1, "stop cancels a pending start even without an assertion")

let idle = TorrentService()
idle.markEnteringBackground()
idle.backgroundCheckpoint = (Date().addingTimeInterval(-28800), 0)
idle.ensureCoreReadyForForeground()
check(idle.session.reopenCount == 1, "overnight idle foreground restores sockets")
check(idle.addTorrent(by: MagnetURI("first")), "first idle magnet is added")
check(idle.session.idleCount == 1, "first addition bootstraps even after foreground marker was consumed")
check(idle.scheduler.callbacks.count == 1, "exactly one bounded metadata fallback")
idle.scheduler.fire()
check(idle.session.idleCount == 2, "stalled first magnet gets fallback")
idle.scheduler.fire()
check(idle.session.idleCount == 2, "fallback never becomes a periodic reset")
check(!idle.addTorrent(by: MagnetURI("first")), "duplicate still rejected")
check(idle.session.idleCount == 2, "duplicate does not bootstrap")

let live = TorrentService()
let existing = TorrentHandle("live"); existing.snapshot.friendlyState = .seeding
existing.peerStats = [1]; live.session.torrentsMap["live"] = existing
live.markEnteringBackground(); live.backgroundCheckpoint = (Date().addingTimeInterval(-28800), 0)
live.ensureCoreReadyForForeground()
check(live.session.reopenCount == 0 && live.session.settingsCount == 0, "live foreground seeding is not disconnected")
check(live.addTorrent(by: MagnetURI("next")), "add alongside existing transfer")
check(live.session.idleCount == 0 && live.scheduler.callbacks.isEmpty, "active-session add keeps existing path")

let paused = TorrentService(); let ph = TorrentHandle("paused"); ph.snapshot.isPaused = true
paused.session.torrentsMap["paused"] = ph
check(paused.addTorrent(by: MagnetURI("afterpause")), "idle includes intentionally paused tasks")
check(ph.snapshot.isPaused && ph.resumeCount == 0, "manual pause is never undone")

let rejected = TorrentService(); BTSubscription.shared.allow = false
let before = BTSubscription.shared.used
check(!rejected.addTorrent(by: MagnetURI("blocked")), "subscription quota remains enforced")
check(rejected.session.idleCount == 0 && rejected.session.torrentsMap.isEmpty, "quota rejection never starts idle add")
check(BTSubscription.shared.used == before, "rejection does not consume quota")
BTSubscription.shared.allow = true

for reason in ["metadata", "pause", "storage", "peers", "remove", "other-active"] {
    let service = TorrentService()
    _ = service.addTorrent(by: MagnetURI("target"))
    let h = service.session.torrentsMap["target"]!
    switch reason {
    case "metadata": h.snapshot.friendlyState = .downloading
    case "pause": h.snapshot.isPaused = true
    case "storage": h.snapshot.isStorageMissing = true
    case "peers": h.peerStats = [1]
    case "remove": service.session.torrentsMap.removeAll()
    default: service.session.torrentsMap["other"] = TorrentHandle("other")
    }
    service.scheduler.fire()
    check(service.session.idleCount == 1, "cancel fallback on \(reason)")
}
print("V1.2.1 idle lifecycle regression: \(checks) checks passed")
