"""Compile and exercise the production recovery/add/background method bodies.

Only the platform/BT transport and delayed scheduler are substituted. The full
app build type-checks these same methods against UIKit/LibTorrent afterwards.
"""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / 'iTorrent/Services/TorrentService/TorrentService.swift').read_text()

def method(name):
    start = source.index('    func ' + name + '(')
    opening = source.index('{', start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

# Include the private method without changing its body except the test clock.
private = source.replace('    private func scheduleIdleMetadataRecovery', '    func scheduleIdleMetadataRecovery')
original = source
source = private
names = ['addTorrent', 'scheduleIdleMetadataRecovery', 'markEnteringBackground',
         'ensureCoreReadyForForeground', 'recoverAfterForeground', 'transferredBytes']
# transferredBytes is generic, so include it separately.
methods = [method(name) for name in names[:-1]]
start = source.index('    func transferredBytes<')
end = source.index('\n    }', start) + len('\n    }')
methods.append(source[start:end])
body = '\n'.join(methods).replace('DispatchQueue.main.asyncAfter', 'scheduler.asyncAfter')
background = (root / 'iTorrent/Services/BackgroundService/BackgroundService.swift').read_text()
background = background.replace('import Combine', '').replace('import LibTorrent', '')
native = (root / 'Submodules/LibTorrent-Swift/LibTorrent/Core/Session/Session.mm').read_text()
idle = native.split('- (void)recoverIdleNetwork {', 1)[1].split('- (void)dealloc', 1)[0]
assert 'status.num_peers > 0' in idle and 'status.upload_payload_rate > 0' in idle
assert 'get_bool(lt::settings_pack::enable_dht)' in idle
assert '_session->pause()' not in idle and 'handle.resume()' not in idle
assert 'preferences.isTrackersAutoaddingEnabled, !torrent.isPrivate' in original

with tempfile.TemporaryDirectory() as tmp:
    main = Path(tmp) / 'main.swift'
    stub = (Path(__file__).parent / 'stubs.swift').read_text()
    tests = (Path(__file__).parent / 'main.swift').read_text()
    main.write_text(stub + '\n' + body + '\n}\n' + background + '\n' + tests)
    binary = str(Path(tmp) / 'idle-tests')
    subprocess.run(['xcrun', 'swiftc', '-swift-version', '5', str(main), '-o', binary], check=True)
    subprocess.run([binary], check=True)

