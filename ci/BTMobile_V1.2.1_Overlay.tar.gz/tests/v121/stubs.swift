import Foundation

@propertyWrapper struct Published<Value> {
    var wrappedValue: Value
    init(wrappedValue: Value) { self.wrappedValue = wrappedValue }
}
enum State { case checkingFiles, checkingResumeData, downloading, downloadingMetadata, seeding, paused }
class TorrentHandle {
    struct Snapshot {
        var infoHashes: String
        var isPaused = false
        var isStorageMissing = false
        var friendlyState: State = .downloadingMetadata
        var downloadRate = 0
        var uploadRate = 0
        var totalDownload: UInt64 = 0
        var totalUpload: UInt64 = 0
    }
    var snapshot: Snapshot
    var peerStats: [Int] = []
    var resumeCount = 0
    init(_ hash: String) { snapshot = Snapshot(infoHashes: hash) }
    func clearError() {}
    func resume() { resumeCount += 1; snapshot.isPaused = false }
}
class Downloadable { let infoHashes: String; init(_ hash: String) { infoHashes = hash } }
class MagnetURI: Downloadable {}
class PreferencesStorage {
    static let shared = PreferencesStorage()
    var isBackgroundDownloadEnabled = true
    var isBackgroundSeedingEnabled = true
    var allStorageScopes = [String]()
    var effectiveDefaultStorage: UUID? = nil
}
class Session {
    struct Settings { static func fromPreferences(with interfaces: [String]) -> Settings { .init() } }
    var settings = Settings() { didSet { settingsCount += 1 } }
    var storages = [String]()
    var settingsCount = 0, reopenCount = 0, idleCount = 0, announceCount = 0
    var torrentsMap: [String: TorrentHandle] = [:]
    func resume() {}
    func reopenNetworkSockets() { reopenCount += 1 }
    func recoverIdleNetwork() { idleCount += 1 }
    func reannounceToAllTrackers() { announceCount += 1 }
    func addTorrent(_ file: Downloadable, to storage: UUID?) -> TorrentHandle? {
        let h = TorrentHandle(file.infoHashes); torrentsMap[file.infoHashes] = h; return h
    }
}
class Network { var availableInterfaces = ["en0"] }
class Scheduler {
    var callbacks = [() -> Void]()
    func asyncAfter(deadline: DispatchTime, execute: @escaping () -> Void) { callbacks.append(execute) }
    func fire() { let work = callbacks; callbacks.removeAll(); work.forEach { $0() } }
}
class BTSubscription {
    enum Result { case added, rejected, quotaExceeded, unavailable(String) }
    static let shared = BTSubscription()
    var allow = true
    var used = 0
    func addMagnet(_ add: () -> Bool) -> Result {
        guard allow else { return .quotaExceeded }
        guard add() else { return .rejected }
        used += 1; return .added
    }
}
enum BTSubscriptionPresentation { static func show(message: String) {} }
class AudioBackgroundService: BackgroundServiceProtocol {
    static var stopCount = 0
    var isRunning = false
    func start() -> Bool { true }
    func stop() { Self.stopCount += 1 }
    func prepare() async -> Bool { true }
}
class LocationBackgroundService: AudioBackgroundService {}
class TorrentService {
    static let shared = TorrentService()
    let session = Session(), network = Network(), scheduler = Scheduler()
    let preferences = PreferencesStorage.shared
    let foregroundRecoveryLock = NSLock(), additionLock = NSRecursiveLock()
    var needsForegroundRecovery = false
    var backgroundCheckpoint: (enteredAt: Date, transferredBytes: UInt64)?
    var torrents: [String: TorrentHandle] { session.torrentsMap }
    func resolveStorageScopes() {}

