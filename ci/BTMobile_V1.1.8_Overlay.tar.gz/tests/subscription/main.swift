import Foundation
import CryptoKit

func date(_ value: String) -> Date { ISO8601DateFormatter().date(from: value)! }
let now = date("2026-09-17T10:00:00Z")
var ledger = BTMagnetLedger(deviceID: UUID(), day: BTMagnetLedger.dayKey(now), used: 0, lastSeen: now)
for _ in 0..<3 { assert(ledger.reserve(at: now)) }
assert(!ledger.reserve(at: now))
assert(!ledger.reserve(at: date("2026-09-16T10:00:00Z")))
assert(!ledger.reserve(at: date("2026-09-17T15:59:59Z")))
assert(ledger.reserve(at: date("2026-09-17T16:00:00Z")))
assert(ledger.used == 1)
assert(ledger.day == "2026-09-18")
let restored = try JSONDecoder().decode(BTMagnetLedger.self, from: JSONEncoder().encode(ledger))
assert(restored.used == 1 && restored.deviceID == ledger.deviceID)
let fake = Data("{\"payload\":\"e30=\",\"signature\":\"AA==\"}".utf8)
do { let _: BTSubscriptionClaim = try BTSubscriptionVerifier.decode(fake); fatalError("accepted forged entitlement") }
catch { }
// P256 DER signatures are the wire format shared by CryptoKit and the server.
let key = P256.Signing.PrivateKey()
let bytes = Data("wire-test".utf8)
let signature = try key.signature(for: bytes)
let decodedSignature = try P256.Signing.ECDSASignature(derRepresentation: signature.derRepresentation)
assert(key.publicKey.isValidSignature(decodedSignature, for: bytes))
print("PASS: daily quota, fourth rejection, backwards clock, Beijing rollover, persistence, forged entitlement, DER signature")
