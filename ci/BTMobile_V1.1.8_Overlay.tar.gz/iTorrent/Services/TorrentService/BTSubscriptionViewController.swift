import UIKit

enum BTSubscriptionPresentation {
    static func show(message: String? = nil) {
        DispatchQueue.main.async {
            guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }),
                var presenter = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
            while let next = presenter.presentedViewController { presenter = next }
            if presenter is UINavigationController,
               (presenter as? UINavigationController)?.topViewController is BTSubscriptionViewController { return }
            let page = BTSubscriptionViewController()
            page.notice = message
            presenter.present(UINavigationController(rootViewController: page), animated: true)
        }
    }
}

final class BTSubscriptionViewController: UIViewController {
    var notice: String?
    private let stack = UIStackView()
    private let channels = UISegmentedControl(items: ["支付宝", "微信支付"])
    private let identity = UILabel()
    private let quota = UILabel()
    private let expiry = UILabel()
    private var busy = false
    private var observer: NSObjectProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "BTmobile 订阅"
        view.backgroundColor = .systemGroupedBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(close))
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.spacing = 18
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor), scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 24),
            stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
            stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -20),
            stack.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -40)
        ])
        if let notice { label(notice, color: .systemOrange) }
        label("30天订阅", size: 24, weight: .semibold)
        label("¥8.00 / 30天", size: 30, weight: .bold)
        label("订阅生效期间可无限添加磁力任务。手动续费，不自动扣款。")
        label("部署订阅服务并开放收款后可购买。请先配置运营方提供的 HTTPS 服务地址；此 App 会校验服务器签名。", size: 13, color: .secondaryLabel)
        channels.selectedSegmentIndex = 0
        stack.addArrangedSubview(channels)
        button("订阅 / 续费 · ¥8", action: #selector(payment))
        button("刷新订阅", action: #selector(refreshSubscription))
        button("配置订阅服务地址", action: #selector(configureService))
        label("我的使用状态", size: 19, weight: .semibold)
        quota.font = .systemFont(ofSize: 15)
        quota.numberOfLines = 0
        stack.addArrangedSubview(quota)
        expiry.font = .systemFont(ofSize: 15)
        expiry.numberOfLines = 0
        stack.addArrangedSubview(expiry)
        label("每天北京时间 00:00 重置免费额度。仅新增成功的磁力任务计次；重复添加、失败、暂停和继续不计次。已添加任务不受额度或订阅到期影响。付费凭证最多离线使用24小时，联网刷新后恢复已购权益。", size: 13, color: .secondaryLabel)
        label("匿名设备身份", size: 19, weight: .semibold)
        identity.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        identity.numberOfLines = 0
        stack.addArrangedSubview(identity)
        button("复制 UUID", action: #selector(copyIdentity))
        label("无需注册。UUID 是本应用随机生成并保存在此设备钥匙串中的身份，不是硬件序列号。换机或设备重置后不保证保留，后续订阅恢复需联系支持。", size: 13, color: .secondaryLabel)
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.1.8"
        label("BTmobile  V\(version)", size: 13, color: .secondaryLabel)
        refresh()
        observer = NotificationCenter.default.addObserver(forName: BTSubscription.changed, object: nil, queue: .main) { [weak self] _ in
            // UIKit is isolated to the main queue; defer also supports strict concurrency builds.
            DispatchQueue.main.async { self?.refresh() }
        }
    }
    deinit { if let observer { NotificationCenter.default.removeObserver(observer) } }
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated); refresh() }
    private func label(_ text: String, size: CGFloat = 15, weight: UIFont.Weight = .regular, color: UIColor = .label) {
        let label = UILabel()
        label.text = text
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: size, weight: weight)
        label.textColor = color
        stack.addArrangedSubview(label)
    }
    private func button(_ title: String, action: Selector) {
        let button = UIButton(type: .system)
        var config = UIButton.Configuration.tinted()
        config.title = title
        config.cornerStyle = .medium
        button.configuration = config
        button.heightAnchor.constraint(greaterThanOrEqualToConstant: 48).isActive = true
        button.addTarget(self, action: action, for: .touchUpInside)
        stack.addArrangedSubview(button)
    }
    private func refresh() {
        let state = BTSubscription.shared.snapshot
        identity.text = state.deviceID
        quota.text = state.error ?? (state.paid ? "订阅已生效 · 磁力任务不限次数" : "免费额度 · 今日剩余 \(state.remaining) / 3 次")
        if let expires = state.expiresAt {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium; formatter.timeStyle = .short
            expiry.text = "订阅到期：\(formatter.string(from: expires))" + (state.paid ? "" : "\n已到期或凭证需联网刷新")
        } else { expiry.text = "订阅到期：未开通" }
    }
    @objc private func close() { dismiss(animated: true) }
    @objc private func copyIdentity() {
        let state = BTSubscription.shared.snapshot
        guard state.error == nil else { return }
        UIPasteboard.general.string = state.deviceID
        let alert = UIAlertController(title: "UUID 已复制", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }
    @objc private func payment() {
        guard !busy else { return }
        let channel = channels.selectedSegmentIndex == 0 ? "alipay" : "wxpay"
        busy = true
        Task { @MainActor in
            defer { busy = false; refresh() }
            do {
                let url = try await BTSubscriptionNetwork.shared.createOrder(channel: channel)
                let opened = await UIApplication.shared.open(url)
                if !opened { showMessage("无法打开支付页面，请检查默认浏览器设置。") }
            } catch { showMessage(error.localizedDescription) }
        }
    }
    @objc private func refreshSubscription() {
        guard !busy else { return }; busy = true
        Task { @MainActor in
            defer { busy = false; refresh() }
            if await BTSubscriptionNetwork.shared.endpoint().isEmpty { showMessage("请先配置订阅服务地址。"); return }
            do { try await BTSubscriptionNetwork.shared.refresh(); showMessage("订阅状态已更新。") }
            catch { showMessage(error.localizedDescription) }
        }
    }
    @objc private func configureService() {
        Task { @MainActor in
            let address = await BTSubscriptionNetwork.shared.endpoint()
            let alert = UIAlertController(title: "订阅服务地址", message: "填写运营方部署的订阅站点，不是易支付网关。服务签名校验通过后才保存。", preferredStyle: .alert)
            alert.addTextField { field in
                field.placeholder = "https://订阅站点域名"
                field.text = address; field.keyboardType = .URL
                field.autocapitalizationType = .none; field.autocorrectionType = .no
            }
            alert.addAction(UIAlertAction(title: "取消", style: .cancel))
            alert.addAction(UIAlertAction(title: "验证并保存", style: .default) { [weak self, weak alert] _ in
                guard let self, !self.busy else { return }
                let text = alert?.textFields?.first?.text ?? ""
                self.busy = true
                Task { @MainActor in
                    defer { self.busy = false; self.refresh() }
                    do { try await BTSubscriptionNetwork.shared.configure(text); self.showMessage("服务地址已验证并保存。") }
                    catch { self.showMessage(error.localizedDescription) }
                }
            })
            present(alert, animated: true)
        }
    }
    private func showMessage(_ message: String) {
        let alert = UIAlertController(title: "BTmobile", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }
}
