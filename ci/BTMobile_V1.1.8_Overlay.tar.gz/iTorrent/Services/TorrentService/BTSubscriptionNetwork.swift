import Foundation
import CryptoKit

private final class BTNoRedirect: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

actor BTSubscriptionNetwork {
    static let shared = BTSubscriptionNetwork()
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 25
        config.httpShouldSetCookies = false
        return URLSession(configuration: config, delegate: BTNoRedirect(), delegateQueue: nil)
    }()
    private var refreshing = false
    enum NetworkError: LocalizedError {
        case message(String)
        var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
    }
    private struct Bootstrap: Decodable { let nonce: String; let serverTime: Double }
    private struct Order: Decodable { let orderID: String; let checkoutURL: String }
    func endpoint() -> String { (try? BTSubscriptionKeychain.read("endpoint")).flatMap { String(data: $0, encoding: .utf8) } ?? "" }

    func configure(_ input: String) async throws {
        guard let parts = URLComponents(string: input.trimmingCharacters(in: .whitespacesAndNewlines)),
              parts.scheme == "https", parts.host?.isEmpty == false, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil, parts.path.isEmpty || parts.path == "/",
              let url = parts.url else { throw NetworkError.message("请输入不含路径的 HTTPS 服务地址。") }
        let base = url.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let nonce = UUID().uuidString
        let data = try await request(base: base, path: "/v1/bootstrap?nonce=\(nonce)")
        let response: Bootstrap = try BTSubscriptionVerifier.decode(data)
        guard response.nonce == nonce, abs(response.serverTime - Date().timeIntervalSince1970) < 300 else {
            throw NetworkError.message("服务身份或时间校验失败，请检查手机自动时间设置。")
        }
        // Do not disclose the device identity/key to an unverified server.
        try BTSubscriptionKeychain.write(Data(base.utf8), account: "endpoint")
        try await refresh()
    }

    func refresh() async throws {
        let base = endpoint()
        guard !base.isEmpty, !refreshing else { return }
        refreshing = true; defer { refreshing = false }
        let identity = BTSubscription.shared.snapshot
        guard identity.error == nil else { throw NetworkError.message(identity.error!) }
        let key = try BTSubscription.shared.deviceKey()
        let proof = try key.signature(for: Data("register\n\(identity.deviceID)".utf8)).derRepresentation.base64EncodedString()
        let body = try JSONSerialization.data(withJSONObject: ["deviceID": identity.deviceID,
            "publicKey": key.publicKey.x963Representation.base64EncodedString(), "proof": proof], options: [.sortedKeys])
        let data = try await request(base: base, path: "/v1/register", method: "POST", body: body)
        try BTSubscription.shared.storeEntitlement(data)
    }

    func createOrder(channel: String) async throws -> URL {
        guard ["alipay", "wxpay"].contains(channel), !endpoint().isEmpty else { throw NetworkError.message("请先配置订阅服务地址。") }
        try await refresh()
        guard BTSubscription.shared.snapshot.paymentsEnabled else { throw NetworkError.message("服务端尚未开放收款。") }
        let base = endpoint()
        let body = try JSONSerialization.data(withJSONObject: ["channel": channel, "requestID": UUID().uuidString], options: [.sortedKeys])
        let data = try await request(base: base, path: "/v1/orders", method: "POST", body: body, authenticated: true)
        let order = try JSONDecoder().decode(Order.self, from: data)
        guard let url = URL(string: order.checkoutURL), let server = URL(string: base),
              url.scheme == "https", url.host == server.host, url.port == server.port,
              url.user == nil, url.password == nil, url.path == "/checkout" else { throw NetworkError.message("支付地址校验失败。") }
        return url
    }

    private func request(base: String, path: String, method: String = "GET", body: Data = Data(), authenticated: Bool = false) async throws -> Data {
        guard let url = URL(string: base + path) else { throw NetworkError.message("服务地址无效。") }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if method != "GET" { request.httpBody = body }
        if authenticated {
            let state = BTSubscription.shared.snapshot
            guard state.error == nil else { throw NetworkError.message(state.error!) }
            let time = String(Int(Date().timeIntervalSince1970)), nonce = UUID().uuidString
            let digest = SHA256.hash(data: body).map { String(format: "%02x", $0) }.joined()
            let signed = Data("\(method)\n\(path)\n\(time)\n\(nonce)\n\(digest)".utf8)
            let signature = try BTSubscription.shared.deviceKey().signature(for: signed)
            request.setValue(state.deviceID, forHTTPHeaderField: "X-Device-ID")
            request.setValue(time, forHTTPHeaderField: "X-Time")
            request.setValue(nonce, forHTTPHeaderField: "X-Nonce")
            request.setValue(signature.derRepresentation.base64EncodedString(), forHTTPHeaderField: "X-Signature")
        }
        let (data, response) = try await session.data(for: request)
        guard data.count <= 65536, let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw NetworkError.message("订阅服务请求失败，请检查服务配置或稍后重试。重复付款前请先刷新订阅。")
        }
        return data
    }
}
