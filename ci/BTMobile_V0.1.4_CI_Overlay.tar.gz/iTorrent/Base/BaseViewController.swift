//
//  BaseViewController.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 29/10/2023.
//

import MvvmFoundation
import UIKit
import SwiftUI

protocol ToolbarHidingProtocol {
    var isToolbarItemsHidden: Bool { get }
}

class BaseHostingController<V: View>: UIHostingController<V> {
    var useMarqueeLabel: Bool { false }

    override var title: String? {
        get { super.title }
        set {
            super.title = newValue
            titleLabel.text = newValue
            titleLabel.sizeToFit()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        #if os(visionOS)
        view.backgroundColor = nil
        #endif

        #if !os(visionOS) // Not renders properly on VisionOS
        if useMarqueeLabel {
            navigationItem.titleView = titleLabel
            titleLabel.sizeToFit()
        }
        #endif
    }

    private let titleLabel: UILabel = UIViewController.makeTitleLabel()
}

class BaseViewController<ViewModel: MvvmViewModelProtocol>: SAViewController<ViewModel>, ToolbarHidingProtocol {
    var isToolbarItemsHidden: Bool { toolbarItems?.isEmpty ?? true }
    var useMarqueeLabel: Bool { false }

    override var title: String? {
        get { super.title }
        set {
            super.title = newValue
            titleLabel.text = newValue
            titleLabel.sizeToFit()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        #if os(visionOS)
        view.backgroundColor = nil
        #endif

        #if !os(visionOS) // Not renders properly on VisionOS
        if useMarqueeLabel {
            navigationItem.titleView = titleLabel
            titleLabel.sizeToFit()
        }
        #endif
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setToolbarHidden(isToolbarItemsHidden, animated: false)
    }

    private let titleLabel: UILabel = UIViewController.makeTitleLabel()
}

private extension UIViewController {
    static func makeTitleLabel() -> UILabel {
        let titleLabel = UILabel()
#if !os(visionOS)
        titleLabel.font = .preferredFont(forTextStyle: .headline)
#else
        titleLabel.font = .preferredFont(forTextStyle: .title1)
#endif
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.textAlignment = .center
        if #available(iOS 18.0, visionOS 2.0, *) {
            titleLabel.enableMarquee()
        }
        return titleLabel
    }
}

class BaseHostingViewController<View: MvvmSwiftUIViewProtocol>: SAHostingViewController<View>, ToolbarHidingProtocol {
    var isToolbarItemsHidden: Bool { toolbarItems?.isEmpty ?? true }
    var useMarqueeLabel: Bool { false }

//    override var title: String? {
//        get { super.title }
//        set {
//            super.title = newValue
//            titleLabel.text = newValue
//            titleLabel.sizeToFit()
//        }
//    }

    override func viewDidLoad() {
        super.viewDidLoad()
        #if os(visionOS)
        view.backgroundColor = nil
        #endif

//        #if !os(visionOS) // Not renders properly on VisionOS
//        if useMarqueeLabel {
//            navigationItem.titleView = titleLabel
//            titleLabel.sizeToFit()
//        }
//        #endif

        title = rootView.title
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setToolbarHidden(isToolbarItemsHidden, animated: false)

        if navigationController?.viewControllers.count == 1 {
            navigationItem.trailingItemGroups = [.fixedGroup(items: [
                UIBarButtonItem(systemItem: .close, primaryAction: .init { [unowned self] _ in
                    dismiss(animated: true)
                })
            ])]
        }
    }

    private let titleLabel: UILabel = {
        let titleLabel = UILabel()
#if !os(visionOS)
        titleLabel.font = .preferredFont(forTextStyle: .headline)
#else
        titleLabel.font = .preferredFont(forTextStyle: .title1)
#endif
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.textAlignment = .center
        if #available(iOS 18.0, visionOS 2.0, *) {
            titleLabel.enableMarquee()
        }
        return titleLabel
    }()
}
