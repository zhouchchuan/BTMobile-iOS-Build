//
//  TorrentFilesViewModel.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 03/11/2023.
//

import LibTorrent
import MvvmFoundation


extension TorrentFilesViewModel {
    struct Config {
        var torrentHandle: TorrentHandle
        var rootDirectory: PathNode?
    }
}

class TorrentFilesViewModel: BaseViewModelWith<TorrentFilesViewModel.Config> {
    private(set) var torrentHandle: TorrentHandle!
    private var rootDirectory: PathNode!
    private var keys: [String] = []

    override func prepare(with model: Config) {
        torrentHandle = model.torrentHandle
        rootDirectory = model.rootDirectory ?? generateRoot()
        keys = rootDirectory.makeKeys()
    }
}

extension TorrentFilesViewModel {
    var title: String {
        rootDirectory.name
    }

    var filesCount: Int {
        keys.count
    }

    var downloadPath: URL {
        guard let downloadPath = torrentHandle.snapshot.downloadPath
        else {
            assertionFailure("downloadPath cannot be nil for this object")
            return URL(string: "/")!
        }

        return downloadPath
    }

    var filesForPreview: [FileEntry] {
        filesForPreviewUnfiltered
        .filter {
            $0.downloaded >= $0.size
        }
    }

    var filesForPreviewUnfiltered: [FileEntry] {
        keys.flatMap {
            switch rootDirectory.storage[$0] {
            case let path as PathNode:
                return path.files
            case let file as FileNode:
                return [file.index]
            default:
                return []
            }
        }
        .map { torrentHandle.snapshot.files[$0] }
    }

    func canShareSelected(_ indexPaths: [IndexPath]) -> Bool {
        !shareURLs(for: indexPaths).isEmpty
    }

    func shareURLs(for indexPaths: [IndexPath]) -> [URL] {
        indexPaths.flatMap { indexPath in
            switch rootDirectory.storage[keys[indexPath.item]] {
            case let path as PathNode:
                return path.files
            case let file as FileNode:
                return [file.index]
            default:
                return []
            }
        }.filter {
            let file = torrentHandle.snapshot.files[$0]
            return file.downloaded >= file.size
        }
        .map {
            downloadPath.appending(path: torrentHandle.snapshot.files[$0].path)
        }
    }

    func canChangePriorityForSelected(_ indexPaths: [IndexPath]) -> Bool {
        indexPaths.flatMap { indexPath in
            switch rootDirectory.storage[keys[indexPath.item]] {
            case let path as PathNode:
                return path.files
            case let file as FileNode:
                return [file.index]
            default:
                return []
            }
        }.contains {
            let file = torrentHandle.snapshot.files[$0]
            return file.downloaded < file.size
        }
    }

    func node(at index: Int) -> Node {
        rootDirectory.storage[keys[index]]!
    }

    func fileModel(for index: Int) -> TorrentFilesFileItemViewModel {
        .init(with: (torrentHandle, index))
    }

    func fileURL(at fileIndex: Int) -> URL {
        downloadPath.appending(path: torrentHandle.snapshot.files[fileIndex].path)
    }

    func isStreamableVideo(at fileIndex: Int) -> Bool {
        let file = torrentHandle.snapshot.files[fileIndex]
        let ext = URL(fileURLWithPath: file.path).pathExtension.lowercased()
        return Self.streamableVideoExtensions.contains(ext)
    }

    func isPartiallyDownloaded(at fileIndex: Int) -> Bool {
        let file = torrentHandle.snapshot.files[fileIndex]
        return file.downloaded < file.size
    }

    /// Prepares an in-progress media file for progressive playback without
    /// changing the torrent's discovery, tracker, DHT or peer behavior.
    func prepareForStreaming(fileIndex: Int) {
        torrentHandle.setFilePriority(.topPriority, at: fileIndex)
        torrentHandle.setSequentialDownload(true)
        torrentHandle.setFirstLastPriorityDownload(true)
        torrentHandle.resume()
    }

    func pathModel(for path: PathNode) -> TorrentFilesDictionaryItemViewModel {
        .init(with: (torrentHandle, path, path.name))
    }

    func select(at index: Int) -> Bool {
        switch rootDirectory.storage[keys[index]] {
        case let path as PathNode:
            navigate(to: TorrentFilesViewModel.self, with: .init(torrentHandle: torrentHandle, rootDirectory: path), by: .show)
            return false
        default:
            return true
        }
    }

    func setPriority(_ priority: FileEntry.Priority, at indexPaths: [IndexPath]) {
        let files = indexPaths.flatMap { indexPath in
            switch rootDirectory.storage[keys[indexPath.item]] {
            case let path as PathNode:
                return path.files
            case let file as FileNode:
                return [file.index]
            default:
                return []
            }
        }.filter {
            let file = torrentHandle.snapshot.files[$0]
            return file.downloaded < file.size || priority != .dontDownload
        }

        torrentHandle.setFilesPriority(priority, at: files.map { NSNumber(integerLiteral: $0) })
    }
}

private extension TorrentFilesViewModel {
    static let streamableVideoExtensions: Set<String> = [
        "mp4", "m4v", "mov", "mkv", "avi", "flv", "webm", "ts", "m2ts",
        "wmv", "mpg", "mpeg", "3gp", "3g2", "ogv"
    ]

    func generateRoot() -> PathNode {
        .generateRoot(rootName: "", files: torrentHandle.snapshot.files)
    }
}
