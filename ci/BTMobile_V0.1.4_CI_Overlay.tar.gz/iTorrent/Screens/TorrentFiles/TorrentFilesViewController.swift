//
//  TorrentFilesViewController.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 03/11/2023.
//

import AVKit
import MvvmFoundation
import QuickLook
import UIKit

class TorrentFilesViewController<VM: TorrentFilesViewModel>: BaseViewController<VM> {
    @IBOutlet private var collectionView: UICollectionView!

    private lazy var collectionDelegates = CollectionDeletates(parent: self)
    private lazy var previewDelegates = PreviewDeletates(parent: self)
    private let moreMenuButton = UIBarButtonItem()

    override var useMarqueeLabel: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = viewModel.title

        collectionView.register(TorrentFilesDictionaryItemViewCell<TorrentFilesDictionaryItemViewModel>.self, forCellWithReuseIdentifier: TorrentFilesDictionaryItemViewCell<TorrentFilesDictionaryItemViewModel>.reusableId)
        collectionView.register(type: TorrentFilesFileListCell<TorrentFilesFileItemViewModel>.self, hasXib: false)

        collectionView.dataSource = collectionDelegates
        collectionView.delegate = collectionDelegates
        collectionView.collectionViewLayout = UICollectionViewCompositionalLayout.list(using: .init(appearance: .plain))

        collectionView.allowsMultipleSelectionDuringEditing = true
        navigationItem.trailingItemGroups = [.fixedGroup(items: [editButtonItem])]
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        smoothlyDeselectRows(in: collectionView)
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        collectionView.isEditing = editing

        reloadMoreMenuButton()
        toolbarItems = editing ?
            [moreMenuButton] :
            []
        navigationController?.setToolbarHidden(isToolbarItemsHidden, animated: true)
    }
}

private extension TorrentFilesViewController {
    func reloadMoreMenuButton() {
        moreMenuButton.isEnabled = true // !collectionView.indexPathsForSelectedItems.isNilOrEmpty

        let selectAllAction = UIAction(title: %"list.selectAll") { [unowned self] _ in
            for section in 0..<collectionView.numberOfSections {
                for item in 0..<collectionView.numberOfItems(inSection: section) {
                    let indexPath = IndexPath(item: item, section: section)
                    collectionView.selectItem(at: indexPath, animated: false, scrollPosition: [])
                }
            }
            reloadMoreMenuButton()
        }

        guard !collectionView.indexPathsForSelectedItems.isNilOrEmpty else {
            moreMenuButton.menu = nil
            moreMenuButton.primaryAction = selectAllAction
            moreMenuButton.image = nil
            return
        }

        let priorityMenu = UIMenu.makeForChangePriority(options: [.displayInline]) { [unowned self] priority in
            viewModel.setPriority(priority, at: collectionView.indexPathsForSelectedItems ?? [])
        }

        let shareAction = UIAction(title: %"common.share", image: .init(systemName: "square.and.arrow.up")) { [unowned self] _ in
            shareSelectedItems()
        }

        var menuElements: [UIMenuElement] = []

        if viewModel.canChangePriorityForSelected(collectionView.indexPathsForSelectedItems ?? []) {
            menuElements.append(priorityMenu)
        }

        if viewModel.canShareSelected(collectionView.indexPathsForSelectedItems ?? []) {
            guard !menuElements.isEmpty else {
                moreMenuButton.menu = nil
                moreMenuButton.primaryAction = shareAction
                return
            }
            menuElements.append(shareAction)
        }

        let menu = UIMenu(children: menuElements)

        moreMenuButton.menu = menu
        moreMenuButton.primaryAction = nil
        moreMenuButton.image = .systemEllipsis
    }

    func shareSelectedItems() {
        let urls = viewModel.shareURLs(for: collectionView.indexPathsForSelectedItems ?? [])
        guard !urls.isEmpty else { return }

        let controller = UIActivityViewController(activityItems: urls, applicationActivities: nil)
        controller.popoverPresentationController?.barButtonItem = moreMenuButton
        controller.popoverPresentationController?.permittedArrowDirections = .any
        present(controller, animated: true)
    }
}

private extension TorrentFilesViewController {
    class CollectionDeletates: DelegateObject<TorrentFilesViewController>, UICollectionViewDataSource, UICollectionViewDelegate {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            parent.viewModel.filesCount
        }

        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let node = parent.viewModel.node(at: indexPath.item)
            switch node {
            case let node as FileNode:
                let cell = collectionView.dequeue(for: indexPath) as TorrentFilesFileListCell<TorrentFilesFileItemViewModel>
                let vm = parent.viewModel.fileModel(for: node.index)
                vm.previewAction = { [unowned self] in
                    parent.openPreview(from: indexPath, start: node.index)
                }
                cell.setup(with: vm)
                return cell
            case let node as PathNode:
                let cell = collectionView.dequeue(for: indexPath) as TorrentFilesDictionaryItemViewCell<TorrentFilesDictionaryItemViewModel>
                cell.prepare(with: parent.viewModel.pathModel(for: node))
                return cell
            default:
                return UICollectionViewCell()
            }
        }

        func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemsAt indexPaths: [IndexPath], point: CGPoint) -> UIContextMenuConfiguration? {
            guard indexPaths.count == 1,
                  let node = parent.viewModel.node(at: indexPaths[0].item) as? FileNode
            else { return nil }

            let url = parent.viewModel.fileURL(at: node.index)
            var actions: [UIMenuElement] = []

            if parent.viewModel.isStreamableVideo(at: node.index),
               parent.viewModel.isPartiallyDownloaded(at: node.index) {
                actions.append(UIAction(title: "边下边播", image: .init(systemName: "play.circle")) { [unowned self] _ in
                    parent.startStreaming(url: url, fileIndex: node.index)
                })
            }

            if VLCPlayerViewModel.canOpenInVLCSync(url) != nil {
                actions.append(UIAction(title: %"details.files.openVlcMediaPlayer") { [unowned self] _ in
                    parent.vlcPlayerAction(url: url, index: node.index)
                })
            }

            guard !actions.isEmpty else { return nil }
            return .init(actionProvider: { _ in UIMenu(children: actions) })
        }

        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            guard !collectionView.isEditing else {
                return parent.reloadMoreMenuButton()
            }

            if let node = parent.viewModel.node(at: indexPath.item) as? FileNode,
               parent.viewModel.isStreamableVideo(at: node.index),
               parent.viewModel.isPartiallyDownloaded(at: node.index) {
                parent.startStreaming(url: parent.viewModel.fileURL(at: node.index), fileIndex: node.index)
                collectionView.deselectItem(at: indexPath, animated: true)
                return
            }

            if let cell = collectionView.cellForItem(at: indexPath) as? TorrentFilesFileListCell<TorrentFilesFileItemViewModel> {
                cell.viewModel.selectAction?()
            }

            if parent.viewModel.select(at: indexPath.item) {
                collectionView.deselectItem(at: indexPath, animated: true)
            }
        }

        func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
            parent.reloadMoreMenuButton()
        }
    }

    class PreviewDeletates: DelegateObject<TorrentFilesViewController>, QLPreviewControllerDataSource {
//        @MainActor
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
            parent.viewModel.filesForPreview.count
        }

//        @MainActor
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            let path = parent.viewModel.filesForPreview[index].path
            let res = parent.viewModel.downloadPath.appending(path: path).standardized as NSURL
            return res
        }
    }

    func openPreview(from indexPath: IndexPath, start fileIndex: Int) {
        guard let startIndex = viewModel.filesForPreview.firstIndex(where: { $0.index == fileIndex }),
              let cell = collectionView.cellForItem(at: indexPath)
        else { return }

        let path = viewModel.filesForPreview[startIndex].path
        let url = viewModel.downloadPath.appending(path: path)

        Task {
            let filePlayable = await checkFilePlayable(url: url)
            let fileVLCPlayable = await VLCPlayerViewModel.canOpenInVLC(url, timeoutMilliseconds: 300) != nil

            // Allow to choose be
            guard filePlayable && fileVLCPlayable else {
                if filePlayable {
                    playerAction(start: startIndex)
                    return
                }

                if fileVLCPlayable {
                    vlcPlayerAction(url: url, index: fileIndex)
                    return
                }

                previewAction(start: startIndex)
                return
            }

            let alert = UIAlertController(title: %"details.files.previewMode", message: nil, preferredStyle: .actionSheet)
            alert.addAction(.init(title: %"details.files.quickLookPreview", style: .default) { [self] _ in
                previewAction(start: startIndex)
            })
            if filePlayable {
                alert.addAction(.init(title: %"details.files.mediaPlayerPreview", style: .default) { [self] _ in
                    playerAction(start: startIndex)
                })
            }
            if fileVLCPlayable {
                alert.addAction(.init(title: %"details.files.vlcMediaPlayerPreview", style: .default) { [self] _ in
                    vlcPlayerAction(url: url, index: fileIndex)
                })
            }
            alert.addAction(.init(title: %"common.cancel", style: .cancel))

            alert.popoverPresentationController?.sourceView = cell
            alert.popoverPresentationController?.sourceRect = cell.bounds

            present(alert, animated: true)
        }
    }

    func previewAction(start startIndex: Int) {
        let vc = QLPreviewController()
        vc.dataSource = previewDelegates
        vc.currentPreviewItemIndex = startIndex
        present(vc, animated: true)
    }

    func playerAction(start startIndex: Int) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {}

        let path = viewModel.filesForPreview[startIndex].path
        let url = viewModel.downloadPath.appending(path: path)
        let player = AVPlayer(url: url)
        let playerController = AVPlayerViewController.resolve()
        playerController.canStartPictureInPictureAutomaticallyFromInline = true
        playerController.allowsPictureInPicturePlayback = true
        playerController.player = player

        let title = AVMutableMetadataItem()
        title.identifier = .commonIdentifierTitle
        title.value = (url.deletingPathExtension().lastPathComponent) as NSString
        title.extendedLanguageTag = "und"

        let artwork = AVMutableMetadataItem()
        if let imageData = UIImage.icon(forFileURL: url).jpegData(compressionQuality: 1.0) {
            artwork.identifier = .commonIdentifierArtwork
            artwork.value = imageData as NSData
            artwork.dataType = kCMMetadataBaseDataType_JPEG as String
            artwork.extendedLanguageTag = "und"
        }

        // Set external metadata for the current AVPlayerItem
        player.currentItem?.externalMetadata = [title, artwork]

        present(playerController, animated: true)
    }

    func vlcPlayerAction(url: URL, index: Int) {
        viewModel.navigate(to: VLCPlayerViewModel.self, with: .init(url: url, torrentPair: (viewModel.torrentHandle, index)), by: .present(wrapInNavigation: true, from: nil, style: .fullScreen))
    }

    func startStreaming(url: URL, fileIndex: Int) {
        viewModel.prepareForStreaming(fileIndex: fileIndex)

        let loading = UIAlertController(title: "正在准备边下边播", message: "正在优先下载视频开头/结尾数据…", preferredStyle: .alert)
        loading.addAction(.init(title: %"common.cancel", style: .cancel))
        present(loading, animated: true)

        Task { @MainActor [weak self, weak loading] in
            guard let self else { return }

            // Give libtorrent a short window to create the sparse file and fetch
            // enough header/tail metadata for containers such as MP4/MKV.
            for _ in 0..<24 {
                if Task.isCancelled { return }
                if VLCPlayerViewModel.canOpenInVLCSync(url, timeoutMilliseconds: 100) != nil {
                    if loading?.presentingViewController != nil {
                        loading?.dismiss(animated: true) { [weak self] in
                            self?.vlcPlayerAction(url: url, index: fileIndex)
                        }
                    } else {
                        vlcPlayerAction(url: url, index: fileIndex)
                    }
                    return
                }
                try? await Task.sleep(nanoseconds: 250_000_000)
            }

            if loading?.presentingViewController != nil {
                loading?.dismiss(animated: true)
            }

            let alert = UIAlertController(
                title: "视频数据还未准备好",
                message: "已经开启顺序下载并提高该视频优先级。继续下载片刻后再次点击视频即可播放。",
                preferredStyle: .alert
            )
            alert.addAction(.init(title: %"common.close", style: .default))
            present(alert, animated: true)
        }
    }

    func checkFilePlayable(url: URL) async -> Bool {
        let disposeBag = DisposeBag()
        let player = AVPlayer(url: url)

        return await withCheckedContinuation { continuation in
            player.currentItem?.publisher(for: \.status).sink { status in
                guard status != .unknown else { return }
                continuation.resume(returning: status == .readyToPlay)
            }.store(in: disposeBag)
        }
    }
}
