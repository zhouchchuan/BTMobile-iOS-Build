//
//  TorrentListViewController.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 29/10/2023.
//

import Combine
import CombineCocoa
import LibTorrent
import MvvmFoundation
import SwiftUI
import SwiftVLC
import UIKit

class TLSearchController: UISearchController {
    let isActivePublisher = PassthroughRelay<Bool>()

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isActivePublisher.send(true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isActivePublisher.send(false)
        transitionCoordinator?.animate(alongsideTransition: { _ in }, completion: { [self] ctx in
            if ctx.isCancelled {
                isActivePublisher.send(true)
            }
        })
    }
}

class TorrentListViewController<VM: TorrentListViewModel>: BaseViewController<VM> {
    @IBOutlet private var collectionView: MvvmCollectionView!
    @IBOutlet private var adView: AdView!

    private let addButton = UIBarButtonItem(title: %"common.add", image: .init(systemName: "plus"))
    private let preferencesButton = UIBarButtonItem(title: %"preferences", image: .init(systemName: "gearshape.fill"))
    private let filesButton = UIBarButtonItem(title: "文件", image: .init(systemName: "folder.fill"))
    private let sortButton = UIBarButtonItem(title: %"list.sort", image: .icSort)
    private let rssButton = UIBarButtonItem()

    private let shareButton = UIBarButtonItem(title: %"common.share", image: .init(systemName: "square.and.arrow.up"))
    private let playButton = UIBarButtonItem()
    private let pauseButton = UIBarButtonItem()
    private let rehashButton = UIBarButtonItem()
    private let deleteButton = UIBarButtonItem()

    private lazy var delegates = Delegates(parent: self)
    private lazy var searchVC: TLSearchController = {
        let rssSeacrchViewController = viewModel.rssSearchViewModel.resolveVC()
        let searchController = TLSearchController(searchResultsController: rssSeacrchViewController)
        return searchController
    }()

    private lazy var documentPicker = makeDocumentPicker()
    private let tagsView = makeTagsView()

    private var getToolBarItems: [UIBarButtonItem] {
        collectionView.isEditing ?
            [
                playButton,
                fixedSpacing,
                pauseButton,
                fixedSpacing,
                rehashButton,
                .flexibleSpace(),
                deleteButton
            ].compactMap { $0 } :
            [
                addButton,
                .init(systemItem: .flexibleSpace),
                filesButton,
                .init(systemItem: .flexibleSpace),
                preferencesButton
            ]
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()

        searchVC.searchBar.textDidChangePublisher.assign(to: &viewModel.$searchQuery)

        searchVC.searchBar.cancelButtonClickedPublisher
            .map { "" }.assign(to: &viewModel.$searchQuery)

        addButton.menu = UIMenu(title: %"list.add.title", children: [
            UIAction(title: %"list.add.files", image: .init(systemName: "doc.fill.badge.plus")) { [unowned self] _ in
                if #available(iOS 26.0, visionOS 26.0, *) {
                    documentPicker.preferredTransition = .zoom(sourceBarButtonItemProvider: { [unowned self] _ in
                        addButton
                    })
                    documentPicker.modalPresentationStyle = .formSheet
                }
                present(documentPicker, animated: true)
            },
            UIAction(title: %"list.add.magnet", image: .init(resource: .icMagnet)) { [unowned self] _ in
                present(makeMagnetAlert(), animated: true)
            },
            UIAction(title: %"list.add.url", image: .init(systemName: "link.badge.plus")) { [unowned self] _ in
                present(makeUrlAlert(), animated: true)
            }
        ])

        filesButton.primaryAction = UIAction(title: "文件管理", image: .init(systemName: "folder.fill")) { [weak self] _ in
            guard let self else { return }
            BTFileManagerService.shared.ensureRootDirectory()
            let controller = BTFileManagerViewController(directoryURL: BTFileManagerService.rootURL)
            navigationController?.pushViewController(controller, animated: true)
        }

        playButton.primaryAction = .init(title: %"details.start", image: .init(systemName: "play.fill"), handler: { [unowned self] _ in
            viewModel.resumeAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        pauseButton.primaryAction = .init(title: %"details.pause", image: .init(systemName: "pause.fill"), handler: { [unowned self] _ in
            viewModel.pauseAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        rehashButton.primaryAction = .init(title: %"details.rehash", image: .init(systemName: "arrow.clockwise"), handler: { [unowned self] _ in
            viewModel.rehashAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        deleteButton.primaryAction = .init(title: %"common.delete", image: .init(systemName: "trash"), handler: { [unowned self] _ in
            viewModel.deleteAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        Task {
            // Delay to show SearchBar on screen appear
            disposeBag.bind {
                viewModel.$sections.uiSink { [unowned self] sections in
                    collectionView.sections.send(sections)
                }
            }
        }

        binding()

        navigationItem.leadingItemGroups.append(.fixedGroup(items: [editButtonItem]))
        navigationItem.trailingItemGroups.append(.fixedGroup(items: [rssButton, sortButton]))
        toolbarItems = getToolBarItems

        collectionView.contextMenuConfigurationForItemsAt = { [unowned self] indexPaths, _ in
            guard indexPaths.count > 0 else { return nil }

            if indexPaths.count == 1 {
                guard let indexPath = indexPaths.first,
                      let torrentHandle = (viewModel.sections[indexPath.section].items[indexPath.item] as? TorrentListItemViewModel)?.torrentHandle
                else { return nil }

                return UIContextMenuConfiguration {
                    TorrentDetailsViewModel.resolveVC(with: torrentHandle)
                } actionProvider: { _ in
                    let start = UIAction(title: %"details.start", image: .init(systemName: "play.fill"), attributes: torrentHandle.snapshot.canResume ? [] : .hidden, handler: { _ in
                        torrentHandle.resume()
                    })
                    let pause = UIAction(title: %"details.pause", image: .init(systemName: "pause.fill"), attributes: torrentHandle.snapshot.canPause ? [] : .hidden, handler: { _ in
                        torrentHandle.pause()
                    })
                    let delete = UIAction(title: %"common.delete", image: UIImage(systemName: "trash.fill"), attributes: .destructive) { [unowned self] _ in
                        viewModel.removeTorrent(torrentHandle)
                    }

                    return UIMenu(title: torrentHandle.snapshot.name, children: [
                        start,
                        pause,
                        UIMenu(options: .displayInline,
                               children: [delete])
                    ])
                }
            } else {
                let handles = indexPaths.compactMap { indexPath in (viewModel.sections[indexPath.section].items[indexPath.item] as? TorrentListItemViewModel)?.torrentHandle }
                return UIContextMenuConfiguration {
                    nil
                } actionProvider: { _ in
                    let start = UIAction(title: %"details.start", image: .init(systemName: "play.fill"), handler: { _ in
                        handles.forEach { $0.resume() }
                    })
                    let pause = UIAction(title: %"details.pause", image: .init(systemName: "pause.fill"), handler: { _ in
                        handles.forEach { $0.pause() }
                    })
//                    let delete = UIAction(title: %"common.delete", image: UIImage(systemName: "trash.fill"), attributes: .destructive) { [unowned self] _ in
//                        viewModel.removeTorrent(torrentHandle)
//                    }

                    return UIMenu(children: [
                        start,
                        pause
//                        UIMenu(options: .displayInline,
//                               children: [delete])
                    ])
                }
            }
        }

        collectionView.willPerformPreviewActionForMenuWith = { [unowned self] _, animator in
            animator.addCompletion { [self] in
                if let preview = animator.previewViewController {
                    viewModel.navigationService?()?.navigate(to: preview, by: .detail(asRoot: true))
                    if let nav = preview.navigationController as? SANavigationController,
                       nav.viewControllers.last == preview
                    {
                        nav.locker = false
                    }
                }
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        smoothlyDeselectRows(in: collectionView)
    }

    override func viewLayoutMarginsDidChange() {
        super.viewLayoutMarginsDidChange()

        tagsView.contentInset.left = view.layoutMargins.left - tagsView.safeAreaInsets.left
        tagsView.contentInset.right = view.layoutMargins.right - tagsView.safeAreaInsets.right
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        collectionView.isEditing = editing
        toolbarItems = getToolBarItems
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        additionalSafeAreaInsets.bottom = adView.frame.height
        tagsView.scrollToSelectedItem()

        if #available(iOS 26, *),
           let splitViewController
        {
            if !splitViewController.isCollapsed {
                view.backgroundColor = .clear
            } else {
                view.backgroundColor = .systemBackground
            }
        }
    }
}

private extension TorrentListViewController {
    func setup() {
        title = viewModel.title
        navigationItem.largeTitleDisplayMode = .always
        setupCollectionView()
        setupSearch()
    }

    func setupCollectionView() {
        collectionView.allowsMultipleSelectionDuringEditing = true
    }

    func setupSearch() {
        searchVC.showsSearchResultsController = false
        searchVC.searchBar.placeholder = %"common.search"

        searchVC.searchBar.scopeButtonTitles = ["Torrents", "RSS"]
        searchVC.scopeBarActivation = .onSearchActivation

        navigationItem.searchController = searchVC
    }

    func updateSortingMenu(with selected: ViewModel.Sort, reverced: Bool, isGrouped: Bool) {
        sortButton.menu = .init(title: %"list.sort.title", children:
            [
                UIMenu(options: .displayInline, children: ViewModel.Sort.allCases.map { type in UIAction(title: type.name, image: selected == type ? (reverced ? .init(systemName: "chevron.up") : .init(systemName: "chevron.down")) : nil) { [unowned self] _ in
                    if viewModel.sortingType.value == type {
                        viewModel.sortingReverced.value.toggle()
                    } else {
                        viewModel.sortingType.value = type
                        viewModel.sortingReverced.value = false
                    }
                }}),
                UIMenu(options: .displayInline, children:
                    [
                        UIAction(title: %"list.sort.grouped", image: isGrouped ? .init(systemName: "checkmark") : nil) { [unowned self] _ in
                            viewModel.isGroupedByState.value.toggle()
                        }
                    ])
            ])
    }
}

// MARK: - Binding
private extension TorrentListViewController {
    func binding() {
        disposeBag.bind {
            searchVC.isActivePublisher.sink { [unowned self] isActive in
                viewModel.searchPresented = isActive
            }

            viewModel.$filterButtons.removeDuplicates().sink { [unowned self] buttons in
                tagsView.titles = buttons
                guard let filter = viewModel.filter else {
                    tagsView.selectedTagIndex = 0
                    return
                }
                tagsView.selectedTagIndex = (TorrentHandle.State.filterArray.firstIndex(where: { $0 == filter }) ?? 0) + 1
            }

            tagsView.$selectedTagIndex.sink { [unowned self] index in
                viewModel.filter = index <= 0 ? nil : TorrentHandle.State.filterArray[index - 1]
            }

            viewModel.isGroupedByState.removeDuplicates().uiSink { [unowned self] value in
                navigationItem.setBottomPalette(value ? nil : tagsView)
            }

            viewModel.$hasRssNews.uiSink { [unowned self] rssHasNews in
                let rssHasNewsImage: UIImage?
                if #available(iOS 26, *) {
                    rssHasNewsImage = .icRssNew.applyingSymbolConfiguration(.init(paletteColors: [.label, .systemRed]))
                } else {
                    rssHasNewsImage = .icRssNew.withRenderingMode(.alwaysOriginal)
                }
                rssButton.primaryAction = .init(title: %"rssfeed", image: rssHasNews ? rssHasNewsImage : .icRss, handler: { [unowned self] _ in
                    viewModel.showRss()
                })
            }

            collectionView.$selectedIndexPaths.uiSink { [unowned self] indexPaths in
                let torrentHandles = indexPaths.compactMap { (viewModel.sections[$0.section].items[$0.item] as? TorrentListItemViewModel)?.torrentHandle }

                playButton.isEnabled = torrentHandles.contains(where: { $0.snapshot.isPaused })
                pauseButton.isEnabled = torrentHandles.contains(where: { !$0.snapshot.isPaused })
                rehashButton.isEnabled = !torrentHandles.isEmpty
                deleteButton.isEnabled = !torrentHandles.isEmpty
            }

            preferencesButton.tapPublisher.uiSink { [unowned self] _ in
                viewModel.preferencesAction()
            }

            viewModel.sortingType.combineLatest(viewModel.sortingReverced, viewModel.isGroupedByState).uiSink { [unowned self] type, reverced, grouped in
                updateSortingMenu(with: type, reverced: reverced, isGrouped: grouped)
            }

            searchVC.searchBar.selectedScopeButtonIndexDidChangePublisher.uiSink { [unowned self] scopeIndex in
                searchVC.showsSearchResultsController = scopeIndex == 1
            }

            if #available(iOS 17.0, *) {
                viewModel.emptyContentType.uiSink { [unowned self] emptyType in
                    switch emptyType {
                    case .noData:
                        var config = UIContentUnavailableConfiguration.empty()
                        config.image = .init(systemName: "fireworks")
                        config.text = %"list.empty.nodata.title"
                        config.secondaryText = %"list.empty.nodata.subtitle"
                        contentUnavailableConfiguration = config
                    case .badSearch:
                        contentUnavailableConfiguration = UIContentUnavailableConfiguration.search()
                    case .badFilter(let filter):
                        var configuration = UIContentUnavailableConfiguration.empty()
                        configuration.image = .init(systemName: "line.3.horizontal.decrease")
                        configuration.text = %"list.empty.filter.title-\(filter.name)"
                        configuration.secondaryText = %"list.empty.filter.subtitle"
                        contentUnavailableConfiguration = configuration
                    case nil:
                        contentUnavailableConfiguration = nil
                    }
                }
            }
        }
    }
}

private extension TorrentListViewController {
    class Delegates: DelegateObject<TorrentListViewController>, UIDocumentPickerDelegate {
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            parent.viewModel.addTorrent(by: url)
        }
    }

    func makeDocumentPicker() -> UIViewController {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.init(importedAs: "com.bittorrent.torrent")], asCopy: true)
        documentPicker.delegate = delegates
        documentPicker.allowsMultipleSelection = false
        documentPicker.shouldShowFileExtensions = true
        return documentPicker
    }

    func normalizedMagnetString(_ input: String) -> String {
        let cleaned = input
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "&amp;", with: "&")
        guard cleaned.lowercased().hasPrefix("magnet:?") else { return cleaned }
        let parts = cleaned.split(separator: "&", omittingEmptySubsequences: false)
        guard let first = parts.first else { return cleaned }
        let tail = parts.dropFirst().compactMap { part -> String? in
            let item = String(part).trimmingCharacters(in: .whitespacesAndNewlines)
            guard !item.isEmpty else { return nil }
            let lower = item.lowercased()
            if lower == "dn" || lower == "dn=" { return nil }
            return item
        }
        return ([String(first)] + tail).joined(separator: "&")
    }

    func makeMagnetAlert() -> UIAlertController {
        let alert = UIAlertController(title: %"list.add.magnet.title", message: %"list.add.magnet.message", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = %"list.add.magnet.placeholder"
        }

        alert.addAction(.init(title: %"common.cancel", style: .cancel))
        alert.addAction(.init(title: %"common.ok", style: .default) { [unowned self] _ in
            guard let text = alert.textFields?.first?.text,
                  let url = URL(string: normalizedMagnetString(text)),
                  let magnet = MagnetURI(with: url)
            else {
                let alert = UIAlertController(title: %"common.error", message: %"list.add.magnet.error", preferredStyle: .alert)
                alert.addAction(.init(title: %"common.close", style: .cancel), isPrimary: true)
                present(alert, animated: true)
                return
            }

            guard !TorrentService.shared.checkTorrentExists(with: magnet.infoHashes) else {
                let alert = UIAlertController(title: %"addTorrent.exists", message: %"addTorrent.\(magnet.infoHashes.best.hex)_exists", preferredStyle: .alert)
                alert.addAction(.init(title: %"common.close", style: .cancel), isPrimary: true)
                present(alert, animated: true)
                return
            }

            TorrentService.shared.addTorrent(by: magnet)
        }, isPrimary: true)
        return alert
    }

    func makeUrlAlert() -> UIAlertController {
        let alert = UIAlertController(title: %"list.add.url.title", message: %"list.add.url.message", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = %"list.add.url.placeholder"
        }

        alert.addAction(.init(title: %"common.cancel", style: .cancel))
        alert.addAction(.init(title: %"common.ok", style: .default) { [unowned self] _ in
            Task {
                guard let text = alert.textFields?.first?.text,
                      let url = URL(string: text),
                      ["http", "https"].contains(url.scheme?.lowercased())
                else {
                    let alert = UIAlertController(title: %"common.error", message: %"list.add.url.error", preferredStyle: .alert)
                    alert.addAction(.init(title: %"common.close", style: .cancel))
                    present(alert, animated: true)
                    return
                }

                do {
                    let torrentFile = try await TorrentFile.download(from: url)
                    TorrentAddViewModel.present(with: torrentFile, from: self)
                } catch {
                    presentRemoteTorrentDownloadError(error, url: url)
                }
            }
        }, isPrimary: true)
        return alert
    }

    static func makeTagsView() -> TagsView {
        let tagsView = TagsView()
        tagsView.translatesAutoresizingMaskIntoConstraints = false
        return tagsView
    }
}

private extension TorrentListViewController {
    var fixedSpacing: UIBarButtonItem? {
        if #available(iOS 26, *) {
            return nil
        } else {
            return UIBarButtonItem.fixedSpace(44)
        }
    }
}

private extension TorrentListViewModel.Sort {
    var name: String {
        switch self {
        case .alphabetically:
            return %"list.sort.name"
        case .creationDate:
            return %"list.sort.creationDate"
        case .addedDate:
            return %"list.sort.addedDate"
        case .size:
            return %"list.sort.size"
        }
    }
}

extension TorrentHandle.State {
    static var filterArray: [TorrentHandle.State] {
        [
            .finished,
            .downloading,
            .seeding,
            .paused,
            .checkingFiles,
            .downloadingMetadata,
            .checkingResumeData,

            // Custom state for storage error
            .storageError
        ]
    }
}


// MARK: - BT Mobile 0.1.4 File Manager

/// App-sandbox file manager used by BT Mobile 0.1.4. It intentionally does not
/// touch libtorrent discovery, tracker, DHT or peer logic. Download routing is
/// implemented by registering the selected sandbox folder as a normal storage
/// UUID, which the existing Session already understands.
final class BTFileManagerService {
    struct Item {
        let url: URL
        let isDirectory: Bool
        let size: Int64
        let modificationDate: Date?

        var name: String { url.lastPathComponent }
        var pathExtension: String { url.pathExtension.lowercased() }

        var isArchive: Bool {
            ["zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz"].contains(pathExtension)
        }

        var isVideo: Bool {
            ["mp4", "m4v", "mov", "mkv", "avi", "flv", "webm", "ts", "m2ts", "wmv", "mpg", "mpeg"].contains(pathExtension)
        }
    }

    static let shared = BTFileManagerService()
    static let rootURL = TorrentService.downloadPath.appendingPathComponent("BTmobile", isDirectory: true)

    private let fileManager = FileManager.default
    private let preferences = PreferencesStorage.shared

    private init() {
        ensureRootDirectory()
        repairManagedStorages()
    }

    func ensureRootDirectory() {
        try? fileManager.createDirectory(at: Self.rootURL, withIntermediateDirectories: true)
    }

    /// Fresh V0.1.4 installs use Documents/BTmobile as the managed download
    /// root. An existing explicit external default from V0.1.3 is respected.
    func prepareDefaultDownloadDirectoryIfNeeded() {
        ensureRootDirectory()
        guard preferences.btMobileManagedDefaultStorage == nil,
              preferences.defaultStorage == nil
        else { return }
        _ = try? setDownloadDirectory(Self.rootURL)
    }

    func items(in directory: URL) -> [Item] {
        guard isManagedURL(directory) else { return [] }
        ensureRootDirectory()
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey, .isHiddenKey]
        let urls = (try? fileManager.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: Array(keys),
            options: [.skipsHiddenFiles]
        )) ?? []

        return urls.compactMap { url in
            let values = try? url.resourceValues(forKeys: keys)
            if values?.isHidden == true { return nil }
            return Item(
                url: url,
                isDirectory: values?.isDirectory == true,
                size: Int64(values?.fileSize ?? 0),
                modificationDate: values?.contentModificationDate
            )
        }
        .sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory && !$1.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    @discardableResult
    func createFolder(named rawName: String, in directory: URL) throws -> URL {
        let name = try validatedName(rawName)
        let url = directory.appendingPathComponent(name, isDirectory: true)
        guard isManagedURL(url) else { throw ManagerError.invalidPath }
        guard !fileManager.fileExists(atPath: url.path) else { throw ManagerError.alreadyExists }
        try fileManager.createDirectory(at: url, withIntermediateDirectories: false)
        return url
    }

    @discardableResult
    func rename(_ itemURL: URL, to rawName: String) throws -> URL {
        let name = try validatedName(rawName)
        guard isManagedURL(itemURL), itemURL.standardizedFileURL != Self.rootURL.standardizedFileURL else {
            throw ManagerError.invalidPath
        }
        let destination = itemURL.deletingLastPathComponent().appendingPathComponent(name)
        guard isManagedURL(destination) else { throw ManagerError.invalidPath }
        guard !fileManager.fileExists(atPath: destination.path) else { throw ManagerError.alreadyExists }

        try fileManager.moveItem(at: itemURL, to: destination)
        updateManagedStoragesAfterMove(from: itemURL, to: destination)
        return destination
    }

    func delete(_ itemURL: URL) throws {
        guard isManagedURL(itemURL), itemURL.standardizedFileURL != Self.rootURL.standardizedFileURL else {
            throw ManagerError.invalidPath
        }
        try fileManager.removeItem(at: itemURL)
        removeManagedStorages(under: itemURL)
    }

    @discardableResult
    func setDownloadDirectory(_ directory: URL) throws -> UUID {
        guard isManagedURL(directory), directory.hasDirectoryPath || directory.isDirectory else {
            throw ManagerError.invalidPath
        }
        ensureRootDirectory()

        var storages = preferences.btMobileManagedStorageScopes
        if let existing = storages.values.first(where: { $0.url.standardizedFileURL == directory.standardizedFileURL }) {
            existing.allowed = true
            existing.resolved = true
            existing.name = managedDisplayPath(for: directory)
            storages[existing.uuid] = existing
            preferences.btMobileManagedStorageScopes = storages
            preferences.btMobileManagedDefaultStorage = existing.uuid
            return existing.uuid
        }

        let storage = StorageModel()
        storage.uuid = UUID()
        storage.name = managedDisplayPath(for: directory)
        storage.url = directory.standardizedFileURL
        storage.allowed = true
        storage.resolved = true
        // Managed sandbox folders do not require a security-scoped bookmark.
        // Keep a valid Codable payload for the existing StorageModel format.
        storage.pathBookmark = Data()

        storages[storage.uuid] = storage
        preferences.btMobileManagedStorageScopes = storages
        preferences.btMobileManagedDefaultStorage = storage.uuid
        return storage.uuid
    }

    func isCurrentDownloadDirectory(_ directory: URL) -> Bool {
        guard let uuid = preferences.btMobileManagedDefaultStorage,
              let storage = preferences.btMobileManagedStorageScopes[uuid]
        else { return false }
        return storage.url.standardizedFileURL == directory.standardizedFileURL
    }

    var currentDownloadDirectory: URL? {
        guard let uuid = preferences.btMobileManagedDefaultStorage else { return nil }
        return preferences.btMobileManagedStorageScopes[uuid]?.url
    }

    func isManagedURL(_ url: URL) -> Bool {
        let root = Self.rootURL.standardizedFileURL.path
        let candidate = url.standardizedFileURL.path
        return candidate == root || candidate.hasPrefix(root + "/")
    }

    func suggestedExtractionDirectory(for archiveURL: URL) -> URL {
        let stem: String
        if archiveURL.lastPathComponent.lowercased().hasSuffix(".tar.gz") {
            stem = String(archiveURL.lastPathComponent.dropLast(7))
        } else {
            stem = archiveURL.deletingPathExtension().lastPathComponent
        }
        var candidate = archiveURL.deletingLastPathComponent().appendingPathComponent(stem, isDirectory: true)
        var index = 2
        while fileManager.fileExists(atPath: candidate.path) {
            candidate = archiveURL.deletingLastPathComponent().appendingPathComponent("\(stem) \(index)", isDirectory: true)
            index += 1
        }
        return candidate
    }

    private func validatedName(_ rawName: String) throws -> String {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty,
              name != ".",
              name != "..",
              !name.contains("/"),
              !name.contains("\\"),
              !name.contains(":")
        else { throw ManagerError.invalidName }
        return name
    }

    private func managedDisplayPath(for url: URL) -> String {
        let root = Self.rootURL.standardizedFileURL.path
        let path = url.standardizedFileURL.path
        if path == root { return "BTmobile" }
        let suffix = String(path.dropFirst(root.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return suffix.isEmpty ? "BTmobile" : "BTmobile/\(suffix)"
    }

    private func updateManagedStoragesAfterMove(from oldURL: URL, to newURL: URL) {
        let oldPath = oldURL.standardizedFileURL.path
        let oldPrefix = oldPath + "/"
        var storages = preferences.btMobileManagedStorageScopes

        for (uuid, storage) in storages {
            let path = storage.url.standardizedFileURL.path
            guard path == oldPath || path.hasPrefix(oldPrefix) else { continue }
            let suffix = String(path.dropFirst(oldPath.count))
            let newPath = newURL.standardizedFileURL.path + suffix
            let updatedURL = URL(fileURLWithPath: newPath, isDirectory: true)
            storage.url = updatedURL
            storage.name = managedDisplayPath(for: updatedURL)
            storage.allowed = fileManager.fileExists(atPath: updatedURL.path)
            storage.resolved = storage.allowed
            storages[uuid] = storage
        }
        preferences.btMobileManagedStorageScopes = storages
    }

    private func removeManagedStorages(under deletedURL: URL) {
        let deletedPath = deletedURL.standardizedFileURL.path
        let prefix = deletedPath + "/"
        var storages = preferences.btMobileManagedStorageScopes
        let removed = storages.compactMap { uuid, storage -> UUID? in
            let path = storage.url.standardizedFileURL.path
            return path == deletedPath || path.hasPrefix(prefix) ? uuid : nil
        }
        removed.forEach { storages[$0] = nil }
        preferences.btMobileManagedStorageScopes = storages
        if let current = preferences.btMobileManagedDefaultStorage, removed.contains(current) {
            preferences.btMobileManagedDefaultStorage = nil
        }
    }

    private func repairManagedStorages() {
        var storages = preferences.btMobileManagedStorageScopes
        var removed: [UUID] = []
        for (uuid, storage) in storages {
            guard isManagedURL(storage.url), fileManager.fileExists(atPath: storage.url.path) else {
                removed.append(uuid)
                continue
            }
            storage.allowed = true
            storage.resolved = true
            storage.name = managedDisplayPath(for: storage.url)
            storages[uuid] = storage
        }
        removed.forEach { storages[$0] = nil }
        preferences.btMobileManagedStorageScopes = storages
        if let current = preferences.btMobileManagedDefaultStorage, storages[current] == nil {
            preferences.btMobileManagedDefaultStorage = nil
        }
    }

    enum ManagerError: LocalizedError {
        case invalidName
        case invalidPath
        case alreadyExists

        var errorDescription: String? {
            switch self {
            case .invalidName: return "文件名无效，请不要使用 / \\ : 或 . .."
            case .invalidPath: return "只能管理 BTmobile 目录内的文件。"
            case .alreadyExists: return "同名文件或文件夹已经存在。"
            }
        }
    }
}

final class BTFileManagerViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let service = BTFileManagerService.shared
    private var directoryURL: URL
    private var items: [BTFileManagerService.Item] = []
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let statusLabel = UILabel()

    init(directoryURL: URL) {
        self.directoryURL = directoryURL.standardizedFileURL
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = directoryURL == BTFileManagerService.rootURL ? "BTmobile" : directoryURL.lastPathComponent
        navigationItem.largeTitleDisplayMode = .never

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 58
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        statusLabel.font = .preferredFont(forTextStyle: .footnote)
        statusLabel.textColor = .secondaryLabel
        statusLabel.numberOfLines = 2
        statusLabel.textAlignment = .center
        statusLabel.frame = CGRect(x: 0, y: 0, width: 1, height: 54)
        tableView.tableHeaderView = statusLabel

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "操作",
            image: UIImage(systemName: "ellipsis.circle"),
            primaryAction: nil,
            menu: makeDirectoryMenu()
        )
        reload()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    private func reload() {
        items = service.items(in: directoryURL)
        let current = service.isCurrentDownloadDirectory(directoryURL)
        if current {
            statusLabel.text = "✓ 当前 BT 下载目录\n\(relativePath(directoryURL))"
        } else if let selected = service.currentDownloadDirectory {
            statusLabel.text = "当前下载目录：\(relativePath(selected))"
        } else {
            statusLabel.text = "尚未指定 BTmobile 自定义下载目录"
        }
        tableView.reloadData()
        navigationItem.rightBarButtonItem?.menu = makeDirectoryMenu()
    }

    private func makeDirectoryMenu() -> UIMenu {
        let newFolder = UIAction(title: "新建文件夹", image: UIImage(systemName: "folder.badge.plus")) { [weak self] _ in
            self?.promptCreateFolder()
        }
        let setDownload = UIAction(
            title: service.isCurrentDownloadDirectory(directoryURL) ? "当前已是下载目录" : "设为当前下载目录",
            image: UIImage(systemName: service.isCurrentDownloadDirectory(directoryURL) ? "checkmark.circle.fill" : "arrow.down.to.line.compact"),
            attributes: service.isCurrentDownloadDirectory(directoryURL) ? [.disabled] : []
        ) { [weak self] _ in
            self?.setCurrentDownloadDirectory()
        }
        return UIMenu(children: [newFolder, setDownload])
    }

    private func relativePath(_ url: URL) -> String {
        let root = BTFileManagerService.rootURL.standardizedFileURL.path
        let path = url.standardizedFileURL.path
        guard path.hasPrefix(root) else { return url.lastPathComponent }
        let suffix = String(path.dropFirst(root.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return suffix.isEmpty ? "BTmobile" : "BTmobile/\(suffix)"
    }

    // MARK: Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { items.count }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let id = "BTFileManagerCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: id) ?? UITableViewCell(style: .subtitle, reuseIdentifier: id)
        let item = items[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = item.name
        content.image = UIImage(systemName: iconName(for: item))
        content.secondaryText = item.isDirectory ? "文件夹" : ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.accessoryType = item.isDirectory ? .disclosureIndicator : .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = items[indexPath.row]
        if item.isDirectory {
            navigationController?.pushViewController(BTFileManagerViewController(directoryURL: item.url), animated: true)
        } else if item.isArchive {
            presentArchiveMenu(for: item.url, sourceView: tableView.cellForRow(at: indexPath))
        } else if item.isVideo {
            navigateToVideo(item.url)
        } else {
            share(item.url, sourceView: tableView.cellForRow(at: indexPath))
        }
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let item = items[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            guard let self else { return nil }
            var actions: [UIMenuElement] = []
            if item.isDirectory {
                actions.append(UIAction(title: "设为下载目录", image: UIImage(systemName: "arrow.down.to.line.compact")) { [weak self] _ in
                    try? self?.service.setDownloadDirectory(item.url)
                    self?.reload()
                })
            }
            if item.isArchive {
                actions.append(UIAction(title: "解压", image: UIImage(systemName: "archivebox")) { [weak self] _ in
                    self?.extractArchive(item.url, password: nil)
                })
                actions.append(UIAction(title: "密码解压", image: UIImage(systemName: "lock.open")) { [weak self] _ in
                    self?.promptArchivePassword(item.url)
                })
            }
            actions.append(UIAction(title: "重命名", image: UIImage(systemName: "pencil")) { [weak self] _ in
                self?.promptRename(item.url)
            })
            actions.append(UIAction(title: "删除", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.confirmDelete(item.url)
            })
            return UIMenu(children: actions)
        }
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let item = items[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: "删除") { [weak self] _, _, done in
            self?.confirmDelete(item.url)
            done(true)
        }
        let rename = UIContextualAction(style: .normal, title: "重命名") { [weak self] _, _, done in
            self?.promptRename(item.url)
            done(true)
        }
        return UISwipeActionsConfiguration(actions: [delete, rename])
    }

    private func iconName(for item: BTFileManagerService.Item) -> String {
        if item.isDirectory { return "folder.fill" }
        if item.isArchive { return "archivebox.fill" }
        if item.isVideo { return "play.rectangle.fill" }
        switch item.pathExtension {
        case "jpg", "jpeg", "png", "gif", "webp", "heic": return "photo.fill"
        case "mp3", "m4a", "aac", "flac", "wav", "ogg": return "music.note"
        case "pdf": return "doc.richtext.fill"
        default: return "doc.fill"
        }
    }

    // MARK: File operations
    private func promptCreateFolder() {
        let alert = UIAlertController(title: "新建文件夹", message: relativePath(directoryURL), preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "文件夹名称" }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "创建", style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text else { return }
            do {
                try service.createFolder(named: name, in: directoryURL)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func promptRename(_ url: URL) {
        let alert = UIAlertController(title: "重命名", message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = url.lastPathComponent
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "确定", style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text else { return }
            do {
                _ = try service.rename(url, to: name)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func confirmDelete(_ url: URL) {
        let alert = UIAlertController(
            title: "删除“\(url.lastPathComponent)”？",
            message: "删除后无法恢复。若它仍属于正在下载的 BT 任务，任务可能出现文件缺失，请先暂停或删除对应任务。",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "删除", style: .destructive) { [weak self] _ in
            guard let self else { return }
            do {
                try service.delete(url)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func setCurrentDownloadDirectory() {
        do {
            _ = try service.setDownloadDirectory(directoryURL)
            reload()
            let alert = UIAlertController(title: "下载目录已设置", message: "新的 BT 任务将优先保存到 \(relativePath(directoryURL))。已有任务路径保持不变。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default))
            present(alert, animated: true)
        } catch { showError(error) }
    }

    private func share(_ url: URL, sourceView: UIView?) {
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = sourceView ?? view
        vc.popoverPresentationController?.sourceRect = sourceView?.bounds ?? CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(vc, animated: true)
    }

    private func navigateToVideo(_ url: URL) {
        guard VLCPlayerViewModel.canOpenInVLCSync(url) != nil else {
            let alert = UIAlertController(title: "暂时无法播放", message: "文件可能尚未下载完整，或视频格式暂不支持。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default))
            present(alert, animated: true)
            return
        }
        let controller = VLCPlayerViewController(viewModel: .init(with: .init(url: url, torrentPair: nil)))
        present(UINavigationController(rootViewController: controller), animated: true)
    }

    // MARK: Archive
    private func presentArchiveMenu(for url: URL, sourceView: UIView?) {
        let alert = UIAlertController(title: url.lastPathComponent, message: "选择解压方式", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "直接解压", style: .default) { [weak self] _ in self?.extractArchive(url, password: nil) })
        alert.addAction(UIAlertAction(title: "输入密码解压", style: .default) { [weak self] _ in self?.promptArchivePassword(url) })
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.popoverPresentationController?.sourceView = sourceView ?? view
        alert.popoverPresentationController?.sourceRect = sourceView?.bounds ?? CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(alert, animated: true)
    }

    private func promptArchivePassword(_ url: URL) {
        let alert = UIAlertController(title: "压缩包密码", message: url.lastPathComponent, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "输入解压密码"
            field.isSecureTextEntry = true
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "解压", style: .default) { [weak self, weak alert] _ in
            let password = alert?.textFields?.first?.text ?? ""
            self?.extractArchive(url, password: password)
        })
        present(alert, animated: true)
    }

    private func extractArchive(_ url: URL, password: String?) {
        let destination = service.suggestedExtractionDirectory(for: url)
        let progress = UIAlertController(title: "正在解压", message: url.lastPathComponent, preferredStyle: .alert)
        present(progress, animated: true)

        Task.detached(priority: .userInitiated) {
            do {
                try ArchiveExtractor.extract(archiveURL: url, destinationURL: destination, password: password)
                await MainActor.run { [weak self, weak progress] in
                    progress?.dismiss(animated: true) {
                        self?.reload()
                        let done = UIAlertController(title: "解压完成", message: destination.lastPathComponent, preferredStyle: .alert)
                        done.addAction(UIAlertAction(title: "好", style: .default))
                        self?.present(done, animated: true)
                    }
                }
            } catch {
                await MainActor.run { [weak self, weak progress] in
                    progress?.dismiss(animated: true) {
                        if ArchiveExtractor.isPasswordError(error), (password ?? "").isEmpty {
                            self?.promptArchivePassword(url)
                        } else {
                            self?.showError(error)
                        }
                    }
                }
            }
        }
    }

    private func showError(_ error: Error) {
        let alert = UIAlertController(title: "操作失败", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }
}
