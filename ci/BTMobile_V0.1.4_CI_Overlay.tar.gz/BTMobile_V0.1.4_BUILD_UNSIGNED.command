#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"

APP_NAME="BTMobile_V0.1.4"
WORKSPACE="iTorrent.xcworkspace"
SCHEME="iTorrent"
CONFIGURATION="Release"
DERIVED_DATA="$(pwd)/build/DerivedData"
OUT_DIR="$(pwd)/build/output"

command -v xcodebuild >/dev/null 2>&1 || {
  echo "ERROR: xcodebuild not found. Run this script on macOS with Xcode installed."
  exit 1
}

rm -rf "$DERIVED_DATA" "$OUT_DIR"
mkdir -p "$OUT_DIR"

xcodebuild \
  -workspace "$WORKSPACE" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED_DATA" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  DEVELOPMENT_TEAM="" \
  build

APP_PATH=$(find "$DERIVED_DATA/Build/Products" -maxdepth 3 -type d -name 'iTorrent.app' -path '*Release-iphoneos*' | head -n 1)
if [[ -z "${APP_PATH:-}" || ! -d "$APP_PATH" ]]; then
  echo "ERROR: Release iTorrent.app not found after build."
  exit 1
fi

PLIST="$APP_PATH/Info.plist"
if [[ -f "$PLIST" ]]; then
  BUNDLE_ID=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$PLIST" 2>/dev/null || true)
  VERSION=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$PLIST" 2>/dev/null || true)
  BUILD=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$PLIST" 2>/dev/null || true)
  echo "Built Bundle ID: $BUNDLE_ID"
  echo "Built Version: $VERSION ($BUILD)"
  [[ "$BUNDLE_ID" == "com.mxmall123.app" ]] || { echo "ERROR: unexpected bundle id: $BUNDLE_ID"; exit 1; }
  [[ "$VERSION" == "0.1.4" ]] || { echo "ERROR: unexpected version: $VERSION"; exit 1; }
fi

PAYLOAD="$OUT_DIR/Payload"
mkdir -p "$PAYLOAD"
cp -R "$APP_PATH" "$PAYLOAD/"

cd "$OUT_DIR"
/usr/bin/zip -qry "${APP_NAME}_Unsigned.ipa" Payload
rm -rf Payload

/usr/bin/shasum -a 256 "${APP_NAME}_Unsigned.ipa" > "${APP_NAME}_Unsigned_SHA256.txt"
echo ""
echo "DONE: $OUT_DIR/${APP_NAME}_Unsigned.ipa"
echo "This IPA is intentionally unsigned and can be signed with your own signing tool/certificate."
