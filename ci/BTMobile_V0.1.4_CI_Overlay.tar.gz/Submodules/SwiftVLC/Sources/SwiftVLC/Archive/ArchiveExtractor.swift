import CLibVLC
import Foundation

/// Archive extraction backed by the libarchive implementation already bundled
/// with SwiftVLC's pinned libVLC binary.
public enum ArchiveExtractor {
    public struct ExtractionError: LocalizedError, Sendable {
        public let message: String

        public var errorDescription: String? { message }

        public init(message: String) {
            self.message = message
        }
    }

    public static func extract(
        archiveURL: URL,
        destinationURL: URL,
        password: String? = nil
    ) throws {
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true)

        var errorBuffer = [CChar](repeating: 0, count: 2_048)
        let errorBufferSize = errorBuffer.count
        let result: Int32 = archiveURL.path.withCString { archivePath in
            destinationURL.path.withCString { destinationPath in
                guard let password, !password.isEmpty else {
                    return swiftvlc_archive_extract(
                        archivePath,
                        destinationPath,
                        nil,
                        &errorBuffer,
                        errorBufferSize
                    )
                }

                return password.withCString { passwordCString in
                    swiftvlc_archive_extract(
                        archivePath,
                        destinationPath,
                        passwordCString,
                        &errorBuffer,
                        errorBufferSize
                    )
                }
            }
        }

        guard result == 0 else {
            // Never leave a partially extracted folder looking like a success.
            try? fileManager.removeItem(at: destinationURL)
            let message = errorBuffer.withUnsafeBufferPointer { buffer -> String in
                guard let baseAddress = buffer.baseAddress else { return "Archive extraction failed" }
                let text = String(cString: baseAddress)
                return text.isEmpty ? "Archive extraction failed" : text
            }
            throw ExtractionError(message: message)
        }
    }

    public static func isPasswordError(_ error: Error) -> Bool {
        let message = error.localizedDescription.lowercased()
        return [
            "password",
            "passphrase",
            "encrypted",
            "encryption",
            "decrypt",
            "密码",
            "加密"
        ].contains { message.contains($0) }
    }
}
