# BTMobile 0.1.4 Development Build

Base: BTMobile V0.1.3 STABLE (XITRIX/iTorrent v2.2.0-1 + BTMobile CrashFix/DHT/Peer line)
Bundle ID: com.mxmall123.app
Display name: BT Mobile
Version: 0.1.4 (build 14)
Minimum iOS: 16.0

## Frozen V0.1.3 behavior
- DHT discovery/bootstrap logic remains unchanged.
- Magnet normalization remains unchanged.
- Tracker behavior remains unchanged.
- Peer collection and qBittorrent-style peer information display remain unchanged.
- Existing BT download/session logic is reused; V0.1.4 only adds storage routing and file/media/archive features around it.

## V0.1.4 features
1. File manager rooted at `Documents/BTmobile`.
   - Create folders.
   - Delete files/folders.
   - Rename files/folders.
   - Browse nested folders.
   - Share ordinary files.
   - Tap completed video files to open the existing VLC player.
2. Custom BT download directory.
   - The current BTmobile folder can be selected as the download directory.
   - New managed folders are exposed through the existing TorrentAdd storage selector.
   - Fresh installs default to `Documents/BTmobile` unless an explicit V0.1.3 external default already exists.
   - Existing torrents keep their saved storage UUID/path.
3. Progressive video playback (边下边播).
   - Tap a partially downloaded video in Torrent Files.
   - Sets only the target file to top priority.
   - Enables sequential download and first/last piece priority.
   - Resumes the torrent and opens the existing VLC player once the sparse file is readable.
4. Archive extraction.
   - File manager recognizes ZIP/RAR/7z/TAR/GZ/TGZ/BZ2/XZ.
   - Direct extraction and password extraction UI.
   - Uses the libarchive implementation already bundled with the pinned libVLC binary.
   - Rejects unsafe `..`/absolute archive paths and skips symlinks/device entries.
   - Removes partially extracted output on failure.

## Validation completed in this workspace
- Swift parser check: all modified/new Swift files pass.
- C parser check: archive bridge passes clang C11 syntax check.
- Runtime archive bridge tests against system libarchive:
  - plain ZIP: PASS
  - password-protected ZIP with correct password: PASS
  - password-protected ZIP with wrong password: correctly rejected (`Incorrect passphrase`)
  - TAR.GZ: PASS
  - archive path traversal (`../`) rejection: PASS
- V0.1.3 DHT/peer candidate files were byte-compared and are unchanged:
  - `SessionSettings.mm`
  - `TorrentHandle.h`
  - `TorrentHandle.mm`
  - `TorrentDetailsViewModel.swift`
- `Session.mm` differs only in sandbox-managed storage recovery handling.

## Build limitation of this workspace
The current execution environment is Linux and does not provide Xcode/iOS SDK, therefore a final iOS compile/link/sign and IPA generation cannot be performed here. The source is prepared for Xcode verification/signing on macOS.
