# BTMobile 0.1.3 Test

Base: XITRIX/iTorrent v2.2.0-1 + BTMobile CrashFix line
Bundle ID for test signing: com.mxmall123.app
Display name: BT Mobile
Version: 0.1.3 (build 13)

Changes:
- Collapsible qBittorrent-style Peer summary/details section.
- Per-peer IP:port, download/upload rate, TCP/uTP, IN/OUT, HP and client.
- Multi-router DHT bootstrap for trackerless magnet metadata discovery.
- DHT works alongside trackers rather than only as fallback.
- Normalizes empty trailing &dn / &dn= and HTML escaped &amp; magnet links.
- Keeps the valid Firebase startup configuration used by the CrashFix build.
