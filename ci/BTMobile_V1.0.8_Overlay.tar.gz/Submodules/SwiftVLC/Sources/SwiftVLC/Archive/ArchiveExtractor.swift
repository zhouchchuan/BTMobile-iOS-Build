import CLibVLC
import Darwin
import Foundation
import PLzmaSDK

/// Archive extraction. ZIP/RAR/TAR/etc. keep using the libarchive implementation
/// already bundled with SwiftVLC's pinned libVLC binary. 7z archives use the
/// dedicated 7-Zip/LZMA SDK backend because the bundled libarchive lacks LZMA/
/// LZMA2 and cannot extract encrypted 7z payloads.
public enum ArchiveExtractor {
    public struct ExtractionError: LocalizedError, Sendable {
        public let message: String

        public var errorDescription: String? { message }

        public init(message: String) {
            self.message = message
        }
    }

    private struct SevenZipVolumeDescriptor {
        let archivePrefix: String
        let partNumber: Int
        let numberWidth: Int
    }

    private enum ZipVolumeStyle: Equatable {
        case numbered
        case classic
    }

    private struct ZipVolumeDescriptor {
        let archiveName: String
        let style: ZipVolumeStyle
        let partNumber: Int?
        let numberWidth: Int
    }

    private struct PreparedArchive {
        let archiveURL: URL
        let cleanupURL: URL?
        let volumeURLs: [URL]?

        init(archiveURL: URL, cleanupURL: URL?, volumeURLs: [URL]? = nil) {
            self.archiveURL = archiveURL
            self.cleanupURL = cleanupURL
            self.volumeURLs = volumeURLs
        }
    }

    /// Returns true for 7-Zip split volumes such as file.7z.001, .002, ...
    /// V0.1.6 accepts any volume as the selected file and resolves the complete
    /// sibling set automatically before extraction.
    public static func isSevenZipVolume(_ url: URL) -> Bool {
        sevenZipVolumeDescriptor(for: url) != nil
    }

    /// Human-friendly base name used by the file manager for extraction output.
    /// `movie.7z.001` becomes `movie` rather than `movie.7z`.
    public static func sevenZipVolumeBaseName(_ url: URL) -> String? {
        guard let descriptor = sevenZipVolumeDescriptor(for: url) else { return nil }
        let prefix = descriptor.archivePrefix
        if prefix.lowercased().hasSuffix(".7z") {
            return String(prefix.dropLast(3))
        }
        return prefix
    }

    /// Returns true for binary ZIP volumes (`file.zip.001`) and classic
    /// split ZIP sets (`file.z01`, ..., `file.zip`).
    public static func isZipVolume(_ url: URL) -> Bool {
        zipVolumeDescriptor(for: url) != nil
    }

    /// `movie.zip.001`, `movie.z01`, and the final `movie.zip` of a classic
    /// set all extract into a folder named `movie`.
    public static func zipVolumeBaseName(_ url: URL) -> String? {
        guard let descriptor = zipVolumeDescriptor(for: url) else { return nil }
        let name = descriptor.archiveName
        if name.lowercased().hasSuffix(".zip") {
            return String(name.dropLast(4))
        }
        return name
    }

    public static func extract(
        archiveURL: URL,
        destinationURL: URL,
        password: String? = nil
    ) throws {
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: destinationURL, withIntermediateDirectories: true)

        let prepared: PreparedArchive
        do {
            prepared = try prepareArchiveForExtraction(archiveURL)
        } catch {
            try? fileManager.removeItem(at: destinationURL)
            throw error
        }
        defer {
            if let cleanupURL = prepared.cleanupURL {
                try? fileManager.removeItem(at: cleanupURL)
            }
        }

        if isSevenZipArchive(prepared.archiveURL) {
            do {
                try extractSevenZip(
                    archiveURL: prepared.archiveURL,
                    destinationURL: destinationURL,
                    password: password
                )
                return
            } catch {
                try? fileManager.removeItem(at: destinationURL)
                throw error
            }
        }

        // Keep the V0.1.5 libarchive path byte-for-byte in behavior for all
        // non-7z formats (ZIP/RAR/TAR/GZ/etc.).
        var errorBuffer = [CChar](repeating: 0, count: 2_048)
        let errorBufferSize = errorBuffer.count
        let result: Int32
        if let volumeURLs = prepared.volumeURLs, !volumeURLs.isEmpty {
            let volumePaths = volumeURLs.map { strdup($0.path) }
            defer { volumePaths.forEach { free($0) } }
            guard volumePaths.allSatisfy({ $0 != nil }) else {
                try? fileManager.removeItem(at: destinationURL)
                throw ExtractionError(message: "无法准备 ZIP 分卷路径")
            }

            result = volumePaths.withUnsafeBufferPointer { pathsBuffer in
                destinationURL.path.withCString { destinationPath in
                    guard let password, !password.isEmpty else {
                        return swiftvlc_archive_extract_volumes(
                            pathsBuffer.baseAddress,
                            pathsBuffer.count,
                            destinationPath,
                            nil,
                            &errorBuffer,
                            errorBufferSize
                        )
                    }

                    return password.withCString { passwordCString in
                        swiftvlc_archive_extract_volumes(
                            pathsBuffer.baseAddress,
                            pathsBuffer.count,
                            destinationPath,
                            passwordCString,
                            &errorBuffer,
                            errorBufferSize
                        )
                    }
                }
            }
        } else {
            result = prepared.archiveURL.path.withCString { archivePath in
                destinationURL.path.withCString { destinationPath in
                    guard let password, !password.isEmpty else {
                        return swiftvlc_archive_extract(
                            archivePath,
                            destinationPath,
                            nil,
                            &errorBuffer,
                            errorBufferSize
                        )
                    }

                    return password.withCString { passwordCString in
                        swiftvlc_archive_extract(
                            archivePath,
                            destinationPath,
                            passwordCString,
                            &errorBuffer,
                            errorBufferSize
                        )
                    }
                }
            }
        }

        guard result == 0 else {
            // Never leave a partially extracted folder looking like a success.
            try? fileManager.removeItem(at: destinationURL)
            let message = errorBuffer.withUnsafeBufferPointer { buffer -> String in
                guard let baseAddress = buffer.baseAddress else { return "Archive extraction failed" }
                let text = String(cString: baseAddress)
                return text.isEmpty ? "Archive extraction failed" : text
            }
            throw ExtractionError(message: message)
        }
    }

    // MARK: - V0.1.6 Build 19 dedicated 7z backend

    private static func isSevenZipArchive(_ url: URL) -> Bool {
        url.pathExtension.caseInsensitiveCompare("7z") == .orderedSame
    }

    /// Extract 7z using PLzmaSDK (7-Zip/LZMA SDK). The bundled libarchive is
    /// intentionally not used here: its iOS binary lacks LZMA/LZMA2 and even a
    /// full libarchive build does not provide encrypted 7z payload extraction.
    private static func extractSevenZip(
        archiveURL: URL,
        destinationURL: URL,
        password: String?
    ) throws {
        let fileManager = FileManager.default
        let stagingURL = fileManager.temporaryDirectory
            .appendingPathComponent("BTMobile-7z-extract-\(UUID().uuidString)", isDirectory: true)

        do {
            try fileManager.createDirectory(at: stagingURL, withIntermediateDirectories: true)
            defer { try? fileManager.removeItem(at: stagingURL) }

            let sourcePath = try PLzmaSDK.Path(archiveURL.path)
            let sourceStream = try PLzmaSDK.InStream(path: sourcePath)
            let decoder = try PLzmaSDK.Decoder(stream: sourceStream, fileType: .sevenZ)
            if let password, !password.isEmpty {
                try decoder.setPassword(password)
            } else {
                try decoder.setPassword(nil)
            }

            guard try decoder.open() else {
                throw ExtractionError(message: "无法打开 7z 压缩包")
            }

            // Validate archive entry paths before allowing the SDK to write.
            // Extraction happens in a brand-new staging directory and only then
            // moves into the final destination, so the existing file manager is
            // not exposed to archive-controlled paths.
            let items = try decoder.items()
            try validateSevenZipItemPaths(items)

            let stagingPath = try PLzmaSDK.Path(stagingURL.path)
            guard try decoder.extract(to: stagingPath, itemsFullPath: true) else {
                throw ExtractionError(message: "7z 解压失败")
            }

            try validateExtractedSevenZipTree(stagingURL)
            try moveExtractedSevenZipTree(from: stagingURL, to: destinationURL)
        } catch let error as ExtractionError {
            throw error
        } catch let error as PLzmaSDK.Exception {
            let details = [error.what, error.reason]
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
                .joined(separator: ": ")
            let fallback = details.isEmpty ? "7z 解压失败" : details
            throw ExtractionError(message: fallback)
        } catch {
            throw ExtractionError(message: "7z 解压失败：\(error.localizedDescription)")
        }
    }

    private static func validateSevenZipItemPaths(_ items: PLzmaSDK.ItemArray) throws {
        let count = Int(items.count)
        for index in 0..<count {
            let item = try items.item(at: PLzmaSDK.Size(index))
            let rawPath = try item.path().description
            guard isSafeSevenZipItemPath(rawPath) else {
                throw ExtractionError(message: "7z contains an unsafe file path: \(rawPath)")
            }
        }
    }

    private static func isSafeSevenZipItemPath(_ rawPath: String) -> Bool {
        guard !rawPath.isEmpty else { return true }
        let normalized = rawPath.replacingOccurrences(of: "\\", with: "/")
        if normalized.hasPrefix("/") { return false }
        if normalized.count >= 2 {
            let chars = Array(normalized)
            if chars[1] == ":", chars[0].isLetter { return false }
        }
        var depth = 0
        for component in normalized.split(separator: "/", omittingEmptySubsequences: true) {
            if component == "." { continue }
            if component == ".." {
                if depth == 0 { return false }
                depth -= 1
            } else {
                depth += 1
            }
        }
        return true
    }

    private static func validateExtractedSevenZipTree(_ rootURL: URL) throws {
        let fileManager = FileManager.default
        let rootPath = rootURL.standardizedFileURL.path
        guard let enumerator = fileManager.enumerator(
            at: rootURL,
            includingPropertiesForKeys: [.isSymbolicLinkKey],
            options: [],
            errorHandler: { _, _ in false }
        ) else { return }

        for case let url as URL in enumerator {
            let path = url.standardizedFileURL.path
            guard path == rootPath || path.hasPrefix(rootPath + "/") else {
                throw ExtractionError(message: "7z contains an unsafe extracted path")
            }
            let values = try url.resourceValues(forKeys: [.isSymbolicLinkKey])
            if values.isSymbolicLink == true {
                throw ExtractionError(message: "7z contains a symbolic link, which is not extracted for safety")
            }
        }
    }

    private static func moveExtractedSevenZipTree(from stagingURL: URL, to destinationURL: URL) throws {
        let fileManager = FileManager.default
        let children = try fileManager.contentsOfDirectory(
            at: stagingURL,
            includingPropertiesForKeys: nil,
            options: []
        )
        for child in children {
            let target = destinationURL.appendingPathComponent(child.lastPathComponent)
            try fileManager.moveItem(at: child, to: target)
        }
    }

    // MARK: - V0.1.6 7-Zip split-volume support

    private static let sevenZipVolumeRegex = try! NSRegularExpression(
        pattern: #"^(.*\.7z)\.(\d{3,})$"#,
        options: [.caseInsensitive]
    )

    private static let numberedZipVolumeRegex = try! NSRegularExpression(
        pattern: #"^(.*\.zip)\.(\d{3,})$"#,
        options: [.caseInsensitive]
    )

    private static let classicZipVolumeRegex = try! NSRegularExpression(
        pattern: #"^(.*)\.z(\d{2,})$"#,
        options: [.caseInsensitive]
    )

    private static func sevenZipVolumeDescriptor(for url: URL) -> SevenZipVolumeDescriptor? {
        let name = url.lastPathComponent
        let nsName = name as NSString
        let fullRange = NSRange(location: 0, length: nsName.length)
        guard let match = sevenZipVolumeRegex.firstMatch(in: name, range: fullRange),
              match.numberOfRanges == 3,
              match.range(at: 1).location != NSNotFound,
              match.range(at: 2).location != NSNotFound
        else { return nil }

        let prefix = nsName.substring(with: match.range(at: 1))
        let numberText = nsName.substring(with: match.range(at: 2))
        guard let number = Int(numberText), number > 0 else { return nil }
        return SevenZipVolumeDescriptor(
            archivePrefix: prefix,
            partNumber: number,
            numberWidth: numberText.count
        )
    }

    private static func prepareArchiveForExtraction(_ archiveURL: URL) throws -> PreparedArchive {
        if sevenZipVolumeDescriptor(for: archiveURL) != nil {
            return try prepareSevenZipArchiveForExtraction(archiveURL)
        }
        if zipVolumeDescriptor(for: archiveURL) != nil {
            return try prepareZipArchiveForExtraction(archiveURL)
        }
        return PreparedArchive(archiveURL: archiveURL, cleanupURL: nil)
    }

    private static func prepareSevenZipArchiveForExtraction(_ archiveURL: URL) throws -> PreparedArchive {
        guard let selectedDescriptor = sevenZipVolumeDescriptor(for: archiveURL) else {
            return PreparedArchive(archiveURL: archiveURL, cleanupURL: nil)
        }

        let fileManager = FileManager.default
        let directory = archiveURL.deletingLastPathComponent()
        let siblings: [URL]
        do {
            siblings = try fileManager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey],
                options: [.skipsHiddenFiles]
            )
        } catch {
            throw ExtractionError(message: "无法读取 7z 分卷所在目录：\(error.localizedDescription)")
        }

        var numberedParts: [(number: Int, width: Int, url: URL, size: Int64)] = []
        for sibling in siblings {
            guard let descriptor = sevenZipVolumeDescriptor(for: sibling),
                  descriptor.archivePrefix.caseInsensitiveCompare(selectedDescriptor.archivePrefix) == .orderedSame
            else { continue }

            let values = try? sibling.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
            guard values?.isRegularFile != false else { continue }
            numberedParts.append((
                number: descriptor.partNumber,
                width: descriptor.numberWidth,
                url: sibling,
                size: Int64(values?.fileSize ?? 0)
            ))
        }

        numberedParts.sort { lhs, rhs in
            if lhs.number == rhs.number { return lhs.url.lastPathComponent < rhs.url.lastPathComponent }
            return lhs.number < rhs.number
        }

        guard let first = numberedParts.first, first.number == 1 else {
            throw ExtractionError(message: "7z 分卷不完整：缺少第一分卷 \(selectedDescriptor.archivePrefix).001")
        }

        var seen = Set<Int>()
        for part in numberedParts {
            guard seen.insert(part.number).inserted else {
                throw ExtractionError(message: "7z 分卷编号重复：\(part.url.lastPathComponent)")
            }
        }

        for expected in 1...numberedParts.count {
            guard numberedParts[expected - 1].number == expected else {
                let width = max(selectedDescriptor.numberWidth, 3)
                let suffix = String(format: "%0*d", width, expected)
                throw ExtractionError(message: "7z 分卷不完整：缺少 \(selectedDescriptor.archivePrefix).\(suffix)")
            }
        }

        // Ensure the file the user tapped belongs to the resolved set. This also
        // catches case-only/renamed oddities without changing any file in place.
        guard numberedParts.contains(where: {
            $0.url.standardizedFileURL.path == archiveURL.standardizedFileURL.path
        }) else {
            throw ExtractionError(message: "无法识别所选 7z 分卷")
        }

        let tempDirectory = fileManager.temporaryDirectory
            .appendingPathComponent("BTMobile-7z-\(UUID().uuidString)", isDirectory: true)
        do {
            try fileManager.createDirectory(at: tempDirectory, withIntermediateDirectories: true)
        } catch {
            throw ExtractionError(message: "无法创建 7z 分卷临时目录：\(error.localizedDescription)")
        }

        let mergedName = selectedDescriptor.archivePrefix
        let mergedURL = tempDirectory.appendingPathComponent(mergedName, isDirectory: false)

        do {
            guard fileManager.createFile(atPath: mergedURL.path, contents: nil) else {
                throw ExtractionError(message: "无法创建 7z 分卷临时文件")
            }
            let output = try FileHandle(forWritingTo: mergedURL)
            defer { try? output.close() }

            for part in numberedParts {
                let input = try FileHandle(forReadingFrom: part.url)
                do {
                    while true {
                        // Keep each 1 MiB read inside its own autorelease pool.
                        // Large multi-GB split archives otherwise allow Foundation
                        // NSData/FileHandle temporaries to accumulate on iOS and can
                        // be killed by jetsam before libarchive even starts.
                        let data: Data = try autoreleasepool {
                            try input.read(upToCount: 1_048_576) ?? Data()
                        }
                        if data.isEmpty { break }
                        try output.write(contentsOf: data)
                    }
                    try input.close()
                } catch {
                    try? input.close()
                    throw error
                }
            }
            try output.synchronize()
        } catch {
            try? fileManager.removeItem(at: tempDirectory)
            if let extractionError = error as? ExtractionError { throw extractionError }
            throw ExtractionError(message: "合并 7z 分卷失败：\(error.localizedDescription)")
        }

        return PreparedArchive(archiveURL: mergedURL, cleanupURL: tempDirectory)
    }

    // MARK: - BT Mobile 1.0.8 split ZIP support

    private static func zipVolumeDescriptor(for url: URL) -> ZipVolumeDescriptor? {
        if let direct = directZipVolumeDescriptor(for: url) {
            return direct
        }

        // A classic split set ends in `name.zip`, so identify the final part by
        // the presence of a matching `name.z01` sibling.
        guard url.pathExtension.caseInsensitiveCompare("zip") == .orderedSame,
              let siblings = try? FileManager.default.contentsOfDirectory(
                  at: url.deletingLastPathComponent(),
                  includingPropertiesForKeys: [.isRegularFileKey],
                  options: [.skipsHiddenFiles]
              )
        else { return nil }

        let archiveName = url.lastPathComponent
        let hasFirstPart = siblings.contains { sibling in
            guard let descriptor = directZipVolumeDescriptor(for: sibling),
                  descriptor.style == .classic,
                  descriptor.partNumber == 1
            else { return false }
            return descriptor.archiveName.caseInsensitiveCompare(archiveName) == .orderedSame
        }
        guard hasFirstPart else { return nil }
        return ZipVolumeDescriptor(
            archiveName: archiveName,
            style: .classic,
            partNumber: nil,
            numberWidth: 2
        )
    }

    private static func directZipVolumeDescriptor(for url: URL) -> ZipVolumeDescriptor? {
        let name = url.lastPathComponent
        let nsName = name as NSString
        let fullRange = NSRange(location: 0, length: nsName.length)

        if let match = numberedZipVolumeRegex.firstMatch(in: name, range: fullRange),
           match.numberOfRanges == 3,
           match.range(at: 1).location != NSNotFound,
           match.range(at: 2).location != NSNotFound {
            let archiveName = nsName.substring(with: match.range(at: 1))
            let numberText = nsName.substring(with: match.range(at: 2))
            guard let number = Int(numberText), number > 0 else { return nil }
            return ZipVolumeDescriptor(
                archiveName: archiveName,
                style: .numbered,
                partNumber: number,
                numberWidth: numberText.count
            )
        }

        if let match = classicZipVolumeRegex.firstMatch(in: name, range: fullRange),
           match.numberOfRanges == 3,
           match.range(at: 1).location != NSNotFound,
           match.range(at: 2).location != NSNotFound {
            let baseName = nsName.substring(with: match.range(at: 1))
            let numberText = nsName.substring(with: match.range(at: 2))
            guard let number = Int(numberText), number > 0 else { return nil }
            return ZipVolumeDescriptor(
                archiveName: baseName + ".zip",
                style: .classic,
                partNumber: number,
                numberWidth: numberText.count
            )
        }

        return nil
    }

    private static func prepareZipArchiveForExtraction(_ archiveURL: URL) throws -> PreparedArchive {
        guard let selectedDescriptor = zipVolumeDescriptor(for: archiveURL) else {
            return PreparedArchive(archiveURL: archiveURL, cleanupURL: nil)
        }

        let fileManager = FileManager.default
        let directory = archiveURL.deletingLastPathComponent()
        let siblings: [URL]
        do {
            siblings = try fileManager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey],
                options: [.skipsHiddenFiles]
            )
        } catch {
            throw ExtractionError(message: "无法读取 ZIP 分卷所在目录：\(error.localizedDescription)")
        }

        var parts: [(number: Int, width: Int, url: URL)] = []
        for sibling in siblings {
            guard let descriptor = directZipVolumeDescriptor(for: sibling),
                  descriptor.style == selectedDescriptor.style,
                  descriptor.archiveName.caseInsensitiveCompare(selectedDescriptor.archiveName) == .orderedSame,
                  let number = descriptor.partNumber
            else { continue }

            let values = try? sibling.resourceValues(forKeys: [.isRegularFileKey])
            guard values?.isRegularFile != false else { continue }
            parts.append((number: number, width: descriptor.numberWidth, url: sibling))
        }

        parts.sort { lhs, rhs in
            if lhs.number == rhs.number { return lhs.url.lastPathComponent < rhs.url.lastPathComponent }
            return lhs.number < rhs.number
        }

        let firstSuffix = selectedDescriptor.style == .classic ? "z01" : "zip.001"
        guard let first = parts.first, first.number == 1 else {
            throw ExtractionError(message: "ZIP 分卷不完整：缺少第一分卷 .\(firstSuffix)")
        }

        var seen = Set<Int>()
        for part in parts {
            guard seen.insert(part.number).inserted else {
                throw ExtractionError(message: "ZIP 分卷编号重复：\(part.url.lastPathComponent)")
            }
        }

        for expected in 1...parts.count {
            guard parts[expected - 1].number == expected else {
                let width = max(selectedDescriptor.numberWidth, selectedDescriptor.style == .classic ? 2 : 3)
                let suffix = String(format: "%0*d", width, expected)
                let missing = selectedDescriptor.style == .classic
                    ? String(selectedDescriptor.archiveName.dropLast(4)) + ".z" + suffix
                    : selectedDescriptor.archiveName + "." + suffix
                throw ExtractionError(message: "ZIP 分卷不完整：缺少 \(missing)")
            }
        }

        var orderedURLs = parts.map(\.url)
        if selectedDescriptor.style == .classic {
            guard let finalPart = siblings.first(where: {
                $0.lastPathComponent.caseInsensitiveCompare(selectedDescriptor.archiveName) == .orderedSame
            }) else {
                throw ExtractionError(message: "ZIP 分卷不完整：缺少最后的 \(selectedDescriptor.archiveName)")
            }
            orderedURLs.append(finalPart)
        }

        let selectedPath = archiveURL.standardizedFileURL.path
        guard orderedURLs.contains(where: { $0.standardizedFileURL.path == selectedPath }) else {
            throw ExtractionError(message: "无法识别所选 ZIP 分卷")
        }

        // Let libarchive consume the ordered files as a true multi-volume input.
        // This preserves the disk numbers and central-directory offsets used by
        // classic .z01/.zip archives; raw byte concatenation cannot do that.
        return PreparedArchive(
            archiveURL: archiveURL,
            cleanupURL: nil,
            volumeURLs: orderedURLs
        )
    }

    public static func isPasswordError(_ error: Error) -> Bool {
        let message = error.localizedDescription.lowercased()
        return [
            "password",
            "passphrase",
            "encrypted",
            "encryption",
            "decrypt",
            "authentication",
            "crypto",
            "incorrect passphrase",
            "passphrase required",
            "密码",
            "加密"
        ].contains { message.contains($0) }
    }
}
