//
//  AudioBackgroundService.swift
//  iTorrent
//
//  BT Mobile 1.0.8 background continuity fix.
//

import AVFoundation
import UIKit

class AudioBackgroundService: @unchecked Sendable {
    private var player: AVAudioPlayer?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var watchdogTask: Task<Void, Never>?
    private let taskLock = NSLock()
    private var isObserving = false
}

extension AudioBackgroundService: BackgroundServiceProtocol {
    var isRunning: Bool {
        (player?.isPlaying ?? false) || watchdogTask != nil || backgroundTask != .invalid
    }

    func start() -> Bool {
        guard BackgroundService.isBackgroundNeeded else {
            stop()
            return false
        }

        registerNotificationsIfNeeded()
        beginTransitionTask()
        let started = playAudio()
        startWatchdog()
        return started
    }

    func stop() {
        if isObserving {
            NotificationCenter.default.removeObserver(self)
            isObserving = false
        }
        replaceWatchdog(with: nil)
        endTransitionTask()
        stopAudio()
    }

    func prepare() async -> Bool { true }
}

private extension AudioBackgroundService {
    func registerNotificationsIfNeeded() {
        guard !isObserving else { return }
        isObserving = true
        let center = NotificationCenter.default
        center.addObserver(
            self,
            selector: #selector(handleAudioInterruption),
            name: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance()
        )
        center.addObserver(
            self,
            selector: #selector(handleAudioRouteChange),
            name: AVAudioSession.routeChangeNotification,
            object: AVAudioSession.sharedInstance()
        )
        center.addObserver(
            self,
            selector: #selector(handleMediaServicesReset),
            name: AVAudioSession.mediaServicesWereResetNotification,
            object: AVAudioSession.sharedInstance()
        )
    }

    @objc func handleAudioInterruption(_ notification: Notification) {
        guard let typeValue = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue)
        else { return }

        switch type {
        case .began:
            beginTransitionTask()
        case .ended:
            resumeIfNeeded()
        @unknown default:
            break
        }
    }

    @objc func handleAudioRouteChange(_ notification: Notification) {
        guard BackgroundService.isBackgroundNeeded, player?.isPlaying != true else { return }
        resumeIfNeeded()
    }

    @objc func handleMediaServicesReset(_ notification: Notification) {
        player = nil
        resumeIfNeeded()
    }

    func resumeIfNeeded() {
        guard BackgroundService.isBackgroundNeeded else {
            BackgroundService.shared.stop()
            return
        }
        beginTransitionTask()
        _ = playAudio()
        startWatchdog()
    }

    static func createPlayer() throws -> AVAudioPlayer {
        guard let path = Bundle.main.path(forResource: "sound", ofType: "m4a") else {
            throw CocoaError(.fileNoSuchFile)
        }

        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try session.setActive(true)

        let player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
        player.volume = 0.01
        player.numberOfLoops = -1
        player.prepareToPlay()
        return player
    }

    @discardableResult
    func playAudio() -> Bool {
        do {
            let activePlayer: AVAudioPlayer
            if let player {
                let session = AVAudioSession.sharedInstance()
                try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
                try session.setActive(true)
                activePlayer = player
            } else {
                let newPlayer = try Self.createPlayer()
                player = newPlayer
                activePlayer = newPlayer
            }

            if !activePlayer.isPlaying {
                activePlayer.play()
            }
            return activePlayer.isPlaying
        } catch {
            print("\(Date.now.timestamp) [BG] failed to start background audio: \(error)")
            return false
        }
    }

    func stopAudio() {
        player?.stop()
        player = nil
    }

    func startWatchdog() {
        taskLock.lock()
        let alreadyRunning = watchdogTask != nil
        taskLock.unlock()
        guard !alreadyRunning else { return }

        let task = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                guard BackgroundService.isBackgroundNeeded else {
                    BackgroundService.shared.stop()
                    return
                }

                if self.player?.isPlaying != true {
                    _ = self.playAudio()
                }

                do {
                    try await Task.sleep(for: .seconds(8))
                } catch {
                    return
                }
            }
        }
        replaceWatchdog(with: task)
    }

    func replaceWatchdog(with task: Task<Void, Never>?) {
        taskLock.lock()
        let previous = watchdogTask
        watchdogTask = task
        taskLock.unlock()
        previous?.cancel()
    }

    func beginTransitionTask() {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            endTransitionTask()

            let identifier = UIApplication.shared.beginBackgroundTask(withName: "BTMobile.TransferContinuity") { [weak self] in
                self?.endTransitionTask()
            }
            backgroundTask = identifier

            // The looping audio session is the long-running execution mode. The
            // UIKit task only bridges the short activation transition.
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
                guard let self, backgroundTask == identifier else { return }
                endTransitionTask()
            }
        }
    }

    func endTransitionTask() {
        guard backgroundTask != .invalid else { return }
        let identifier = backgroundTask
        backgroundTask = .invalid
        UIApplication.shared.endBackgroundTask(identifier)
    }
}

extension Date {
    var timestamp: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSSZZZZZ"
        return formatter.string(from: self)
    }
}
