"""Run the production extractor on macOS using the SAME pinned PLzmaSDK; no private fixtures."""
from pathlib import Path
import io
import os
import shutil
import subprocess
import tarfile
import tempfile
import zipfile

root = Path.cwd()
def run(*args, **kwargs):
    subprocess.run([str(a) for a in args], check=True, **kwargs)

with tempfile.TemporaryDirectory(prefix="btmobile-v125-tests-") as directory:
    tmp = Path(directory)
    app = tmp / "Sources" / "ArchiveTests"
    native = tmp / "Sources" / "CLibVLC"
    app.mkdir(parents=True)
    (native / "include").mkdir(parents=True)
    archive = root / "Submodules/SwiftVLC/Sources/SwiftVLC/Archive"
    for filename in ("ArchiveExtractor.swift", "ArchiveFailure.swift"):
        shutil.copy2(archive / filename, app / filename)
    shutil.copy2(root / "tests/v125/main.swift", app / "main.swift")
    bridge = root / "Submodules/SwiftVLC/Sources/CLibVLC"
    shutil.copy2(bridge / "archive_bridge.c", native / "archive_bridge.c")
    header = (bridge / "include/CLibVLC.h").read_text()
    # Only the archive declarations are needed, not the unrelated video headers.
    header = "#include <stddef.h>\n#include <stdint.h>\n" + header.split("// MARK: - Archive extraction bridge", 1)[1].split("#endif", 1)[0]
    (native / "include/CLibVLC.h").write_text(header)
    (tmp / "Package.swift").write_text('''// swift-tools-version:5.9
import PackageDescription
let package = Package(name: "ArchiveTests", platforms: [.macOS(.v13)],
  dependencies: [.package(url: "https://github.com/OlehKulykov/PLzmaSDK.git", exact: "1.2.5")],
  targets: [.target(name: "CLibVLC", linkerSettings: [.linkedLibrary("archive")]),
    .executableTarget(name: "ArchiveTests", dependencies: ["CLibVLC", .product(name: "PLzmaSDK", package: "PLzmaSDK")])])
''')
    fixtures = tmp / "fixtures"
    fixtures.mkdir()
    payload = os.urandom(200000)
    (fixtures / "中文.txt").write_bytes(payload)
    for name, options in [("body.7z", ["-pfixture-only", "-mhe=off"]),
                          ("header.7z", ["-pfixture-only", "-mhe=on"]),
                          ("split.7z", ["-pfixture-only", "-mhe=on", "-v64k"]),
                          ("plain.7z", [])]:
        run("7zz", "a", name, "中文.txt", *options, cwd=fixtures, stdout=subprocess.DEVNULL)
    run("/usr/bin/zip", "-q", "-P", "fixture-only", "secret.zip", "中文.txt", cwd=fixtures)
    data = (fixtures / "secret.zip").read_bytes()
    for index, offset in enumerate(range(0, len(data), 65536), 1):
        (fixtures / f"split.zip.{index:03d}").write_bytes(data[offset:offset + 65536])
    with zipfile.ZipFile(fixtures / "plain.zip", "w", compression=zipfile.ZIP_DEFLATED) as f:
        f.writestr("中文.txt", payload)
    for extension, mode in [("tar", "w"), ("tar.gz", "w:gz"), ("tar.bz2", "w:bz2"), ("tar.xz", "w:xz")]:
        with tarfile.open(fixtures / ("plain." + extension), mode) as f:
            info = tarfile.TarInfo("中文.txt")
            info.size = len(payload)
            f.addfile(info, io.BytesIO(payload))
    (fixtures / "broken.zip").write_bytes(b"not an archive")
    shutil.copy2(fixtures / "split.7z.001", fixtures / "missing.7z.001")
    shutil.copy2(fixtures / "split.7z.003", fixtures / "missing.7z.003")
    run("swift", "run", "--package-path", tmp, "ArchiveTests", fixtures)
