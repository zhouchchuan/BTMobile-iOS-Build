import Foundation

func check(_ condition: @autoclosure () -> Bool, _ label: String) {
    precondition(condition(), label)
}
for (raw, hasPassword, encrypted, openFailed, retry, expected) in [
    ("Passphrase required for this entry", false, false, false, true, "请输入密码"),
    ("Incorrect passphrase", true, false, false, true, "密码错误"),
    ("Cannot read encrypted content without a password", false, false, false, true, "请输入密码"),
    ("Item extracted with error.", true, true, false, true, "密码错误"),
    ("Can't open in archive.", false, false, true, true, "可能已加密"),
    ("Can't open in archive.", true, false, true, true, "密码错误或压缩包已损坏"),
    ("RAR encryption support unavailable: not supported", false, false, false, false, "暂不支持"),
    ("CRC error", false, false, false, false, "校验失败"),
    ("Truncated ZIP", true, true, false, false, "不完整"),
    ("No space left on device", true, true, false, false, "空间不足"),
    ("7z contains an unsafe file path", true, true, false, false, "不安全"),
    ("unknown native exception /private/path", false, false, false, false, "解压失败")
] {
    let result = ArchiveFailure.translate(raw, passwordProvided: hasPassword, encrypted: encrypted, sevenZipOpenFailed: openFailed)
    check(result.canRetryPassword == retry, raw)
    check(result.message.contains(expected), "translation: \(raw): \(result.message)")
    check(!result.message.contains("/private/path"), "native path leaked")
}
let root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
let payload = try Data(contentsOf: root.appendingPathComponent("中文.txt"))
var count = 0
func extraction(_ name: String, password: String?, expectPassword: Bool = false, expectFailure: Bool = false) throws {
    count += 1
    let destination = root.appendingPathComponent("output-\(count)", isDirectory: true)
    do {
        try ArchiveExtractor.extract(archiveURL: root.appendingPathComponent(name), destinationURL: destination, password: password)
        check(!expectPassword && !expectFailure, "Unexpected extraction success: \(name)")
        let extracted = try Data(contentsOf: destination.appendingPathComponent("中文.txt"))
        check(extracted == payload, "Payload mismatch: \(name)")
    } catch {
        if !expectPassword && !expectFailure { throw error }
        let failure = (error as? ArchiveFailure) ?? ArchiveFailure.translate(error.localizedDescription, passwordProvided: !(password ?? "").isEmpty)
        check(failure.canRetryPassword == expectPassword, "Prompt mismatch: \(name): \(failure.message)")
        check(!FileManager.default.fileExists(atPath: destination.path), "Partial output survived: \(name)")
        check(failure.message.contains("密码") || !expectPassword, "Not a Chinese password prompt")
    }
    print("PASS extraction \(count): \(name), \(password == nil ? "no password" : "password supplied")")
}
for name in ["secret.zip", "body.7z", "header.7z", "split.7z.001", "split.zip.001"] {
    try extraction(name, password: nil, expectPassword: true)
    try extraction(name, password: "wrong-fixture", expectPassword: true)
    try extraction(name, password: "fixture-only")
}
for name in ["plain.zip", "plain.7z", "plain.tar", "plain.tar.gz", "plain.tar.bz2", "plain.tar.xz"] {
    try extraction(name, password: nil)
}
try extraction("broken.zip", password: nil, expectFailure: true)
try extraction("missing.7z.001", password: nil, expectFailure: true)
print("PASS V1.2.5: 12 message mappings + \(count) actual extraction cases; password retry, cleanup and payload verified")
