//
//  TorrentListViewController.swift
//  iTorrent
//
//  Created by Daniil Vinogradov on 29/10/2023.
//

import Combine
import CombineCocoa
import ImageIO
import LibTorrent
import MvvmFoundation
import SwiftUI
import SwiftVLC
import UIKit

class TLSearchController: UISearchController {
    let isActivePublisher = PassthroughRelay<Bool>()

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isActivePublisher.send(true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isActivePublisher.send(false)
        transitionCoordinator?.animate(alongsideTransition: { _ in }, completion: { [self] ctx in
            if ctx.isCancelled {
                isActivePublisher.send(true)
            }
        })
    }
}

class TorrentListViewController<VM: TorrentListViewModel>: BaseViewController<VM> {
    @IBOutlet private var collectionView: MvvmCollectionView!
    @IBOutlet private var adView: AdView!

    private let addButton = UIBarButtonItem(title: %"common.add", image: .init(systemName: "plus"))
    private let preferencesButton = UIBarButtonItem(title: %"preferences", image: .init(systemName: "gearshape.fill"))
    private let filesButton = UIBarButtonItem(title: "文件", image: .init(systemName: "folder.fill"))
    private let sortButton = UIBarButtonItem(title: %"list.sort", image: .icSort)
    private let rssButton = UIBarButtonItem()

    private let shareButton = UIBarButtonItem(title: %"common.share", image: .init(systemName: "square.and.arrow.up"))
    private let playButton = UIBarButtonItem()
    private let pauseButton = UIBarButtonItem()
    private let rehashButton = UIBarButtonItem()
    private let deleteButton = UIBarButtonItem()

    private lazy var delegates = Delegates(parent: self)
    private lazy var searchVC: TLSearchController = {
        let rssSeacrchViewController = viewModel.rssSearchViewModel.resolveVC()
        let searchController = TLSearchController(searchResultsController: rssSeacrchViewController)
        return searchController
    }()

    private lazy var documentPicker = makeDocumentPicker()
    private let tagsView = makeTagsView()

    private var getToolBarItems: [UIBarButtonItem] {
        collectionView.isEditing ?
            [
                playButton,
                fixedSpacing,
                pauseButton,
                fixedSpacing,
                rehashButton,
                UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
                deleteButton
            ].compactMap { $0 } :
            [
                addButton,
                .init(systemItem: .flexibleSpace),
                filesButton,
                .init(systemItem: .flexibleSpace),
                preferencesButton
            ]
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()

        searchVC.searchBar.textDidChangePublisher.assign(to: &viewModel.$searchQuery)

        searchVC.searchBar.cancelButtonClickedPublisher
            .map { "" }.assign(to: &viewModel.$searchQuery)

        addButton.menu = UIMenu(title: %"list.add.title", children: [
            UIAction(title: %"list.add.files", image: .init(systemName: "doc.fill.badge.plus")) { [unowned self] _ in
                if #available(iOS 26.0, visionOS 26.0, *) {
                    documentPicker.preferredTransition = .zoom(sourceBarButtonItemProvider: { [unowned self] _ in
                        addButton
                    })
                    documentPicker.modalPresentationStyle = .formSheet
                }
                present(documentPicker, animated: true)
            },
            UIAction(title: %"list.add.magnet", image: .init(resource: .icMagnet)) { [unowned self] _ in
                present(makeMagnetAlert(), animated: true)
            },
            UIAction(title: %"list.add.url", image: .init(systemName: "link.badge.plus")) { [unowned self] _ in
                present(makeUrlAlert(), animated: true)
            }
        ])

        filesButton.primaryAction = UIAction(title: "文件管理", image: .init(systemName: "folder.fill")) { [weak self] _ in
            guard let self else { return }
            BTFileManagerService.shared.ensureRootDirectory()
            let controller = BTFileManagerViewController(directoryURL: BTFileManagerService.rootURL)
            navigationController?.pushViewController(controller, animated: true)
        }

        playButton.primaryAction = .init(title: %"details.start", image: .init(systemName: "play.fill"), handler: { [unowned self] _ in
            viewModel.resumeAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        pauseButton.primaryAction = .init(title: %"details.pause", image: .init(systemName: "pause.fill"), handler: { [unowned self] _ in
            viewModel.pauseAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        rehashButton.primaryAction = .init(title: %"details.rehash", image: .init(systemName: "arrow.clockwise"), handler: { [unowned self] _ in
            viewModel.rehashAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        deleteButton.primaryAction = .init(title: %"common.delete", image: .init(systemName: "trash"), handler: { [unowned self] _ in
            viewModel.deleteAllSelected(at: collectionView.indexPathsForSelectedItems ?? [])
        })

        Task {
            // Delay to show SearchBar on screen appear
            disposeBag.bind {
                viewModel.$sections.uiSink { [unowned self] sections in
                    collectionView.sections.send(sections)
                }
            }
        }

        binding()

        navigationItem.leadingItemGroups.append(.fixedGroup(items: [editButtonItem]))
        navigationItem.trailingItemGroups.append(.fixedGroup(items: [rssButton, sortButton]))
        toolbarItems = getToolBarItems

        collectionView.contextMenuConfigurationForItemsAt = { [unowned self] indexPaths, _ in
            guard indexPaths.count > 0 else { return nil }

            if indexPaths.count == 1 {
                guard let indexPath = indexPaths.first,
                      let torrentHandle = (viewModel.sections[indexPath.section].items[indexPath.item] as? TorrentListItemViewModel)?.torrentHandle
                else { return nil }

                return UIContextMenuConfiguration {
                    TorrentDetailsViewModel.resolveVC(with: torrentHandle)
                } actionProvider: { _ in
                    let start = UIAction(title: %"details.start", image: .init(systemName: "play.fill"), attributes: torrentHandle.snapshot.canResume ? [] : .hidden, handler: { _ in
                        torrentHandle.resume()
                    })
                    let pause = UIAction(title: %"details.pause", image: .init(systemName: "pause.fill"), attributes: torrentHandle.snapshot.canPause ? [] : .hidden, handler: { _ in
                        torrentHandle.pause()
                    })
                    let delete = UIAction(title: %"common.delete", image: UIImage(systemName: "trash.fill"), attributes: .destructive) { [unowned self] _ in
                        viewModel.removeTorrent(torrentHandle)
                    }

                    return UIMenu(title: torrentHandle.snapshot.name, children: [
                        start,
                        pause,
                        UIMenu(options: .displayInline,
                               children: [delete])
                    ])
                }
            } else {
                let handles = indexPaths.compactMap { indexPath in (viewModel.sections[indexPath.section].items[indexPath.item] as? TorrentListItemViewModel)?.torrentHandle }
                return UIContextMenuConfiguration {
                    nil
                } actionProvider: { _ in
                    let start = UIAction(title: %"details.start", image: .init(systemName: "play.fill"), handler: { _ in
                        handles.forEach { $0.resume() }
                    })
                    let pause = UIAction(title: %"details.pause", image: .init(systemName: "pause.fill"), handler: { _ in
                        handles.forEach { $0.pause() }
                    })
//                    let delete = UIAction(title: %"common.delete", image: UIImage(systemName: "trash.fill"), attributes: .destructive) { [unowned self] _ in
//                        viewModel.removeTorrent(torrentHandle)
//                    }

                    return UIMenu(children: [
                        start,
                        pause
//                        UIMenu(options: .displayInline,
//                               children: [delete])
                    ])
                }
            }
        }

        collectionView.willPerformPreviewActionForMenuWith = { [unowned self] _, animator in
            animator.addCompletion { [self] in
                if let preview = animator.previewViewController {
                    viewModel.navigationService?()?.navigate(to: preview, by: .detail(asRoot: true))
                    if let nav = preview.navigationController as? SANavigationController,
                       nav.viewControllers.last == preview
                    {
                        nav.locker = false
                    }
                }
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        smoothlyDeselectRows(in: collectionView)
    }

    override func viewLayoutMarginsDidChange() {
        super.viewLayoutMarginsDidChange()

        tagsView.contentInset.left = view.layoutMargins.left - tagsView.safeAreaInsets.left
        tagsView.contentInset.right = view.layoutMargins.right - tagsView.safeAreaInsets.right
    }

    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        collectionView.isEditing = editing
        toolbarItems = getToolBarItems
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        additionalSafeAreaInsets.bottom = adView.frame.height
        tagsView.scrollToSelectedItem()

        if #available(iOS 26, *),
           let splitViewController
        {
            if !splitViewController.isCollapsed {
                view.backgroundColor = .clear
            } else {
                view.backgroundColor = .systemBackground
            }
        }
    }
}

private extension TorrentListViewController {
    func setup() {
        title = viewModel.title
        navigationItem.largeTitleDisplayMode = .always
        setupCollectionView()
        setupSearch()
    }

    func setupCollectionView() {
        collectionView.allowsMultipleSelectionDuringEditing = true
    }

    func setupSearch() {
        searchVC.showsSearchResultsController = false
        searchVC.searchBar.placeholder = %"common.search"

        searchVC.searchBar.scopeButtonTitles = ["Torrents", "RSS"]
        searchVC.scopeBarActivation = .onSearchActivation

        navigationItem.searchController = searchVC
    }

    func updateSortingMenu(with selected: ViewModel.Sort, reverced: Bool, isGrouped: Bool) {
        sortButton.menu = .init(title: %"list.sort.title", children:
            [
                UIMenu(options: .displayInline, children: ViewModel.Sort.allCases.map { type in UIAction(title: type.name, image: selected == type ? (reverced ? .init(systemName: "chevron.up") : .init(systemName: "chevron.down")) : nil) { [unowned self] _ in
                    if viewModel.sortingType.value == type {
                        viewModel.sortingReverced.value.toggle()
                    } else {
                        viewModel.sortingType.value = type
                        viewModel.sortingReverced.value = false
                    }
                }}),
                UIMenu(options: .displayInline, children:
                    [
                        UIAction(title: %"list.sort.grouped", image: isGrouped ? .init(systemName: "checkmark") : nil) { [unowned self] _ in
                            viewModel.isGroupedByState.value.toggle()
                        }
                    ])
            ])
    }
}

// MARK: - Binding
private extension TorrentListViewController {
    func binding() {
        disposeBag.bind {
            searchVC.isActivePublisher.sink { [unowned self] isActive in
                viewModel.searchPresented = isActive
            }

            viewModel.$filterButtons.removeDuplicates().sink { [unowned self] buttons in
                tagsView.titles = buttons
                guard let filter = viewModel.filter else {
                    tagsView.selectedTagIndex = 0
                    return
                }
                tagsView.selectedTagIndex = (TorrentHandle.State.filterArray.firstIndex(where: { $0 == filter }) ?? 0) + 1
            }

            tagsView.$selectedTagIndex.sink { [unowned self] index in
                viewModel.filter = index <= 0 ? nil : TorrentHandle.State.filterArray[index - 1]
            }

            viewModel.isGroupedByState.removeDuplicates().uiSink { [unowned self] value in
                navigationItem.setBottomPalette(value ? nil : tagsView)
            }

            viewModel.$hasRssNews.uiSink { [unowned self] rssHasNews in
                let rssHasNewsImage: UIImage?
                if #available(iOS 26, *) {
                    rssHasNewsImage = .icRssNew.applyingSymbolConfiguration(.init(paletteColors: [.label, .systemRed]))
                } else {
                    rssHasNewsImage = .icRssNew.withRenderingMode(.alwaysOriginal)
                }
                rssButton.primaryAction = .init(title: %"rssfeed", image: rssHasNews ? rssHasNewsImage : .icRss, handler: { [unowned self] _ in
                    viewModel.showRss()
                })
            }

            collectionView.$selectedIndexPaths.uiSink { [unowned self] indexPaths in
                let torrentHandles = indexPaths.compactMap { (viewModel.sections[$0.section].items[$0.item] as? TorrentListItemViewModel)?.torrentHandle }

                playButton.isEnabled = torrentHandles.contains(where: { $0.snapshot.isPaused })
                pauseButton.isEnabled = torrentHandles.contains(where: { !$0.snapshot.isPaused })
                rehashButton.isEnabled = !torrentHandles.isEmpty
                deleteButton.isEnabled = !torrentHandles.isEmpty
            }

            preferencesButton.tapPublisher.uiSink { [unowned self] _ in
                viewModel.preferencesAction()
            }

            viewModel.sortingType.combineLatest(viewModel.sortingReverced, viewModel.isGroupedByState).uiSink { [unowned self] type, reverced, grouped in
                updateSortingMenu(with: type, reverced: reverced, isGrouped: grouped)
            }

            searchVC.searchBar.selectedScopeButtonIndexDidChangePublisher.uiSink { [unowned self] scopeIndex in
                searchVC.showsSearchResultsController = scopeIndex == 1
            }

            if #available(iOS 17.0, *) {
                viewModel.emptyContentType.uiSink { [unowned self] emptyType in
                    switch emptyType {
                    case .noData:
                        var config = UIContentUnavailableConfiguration.empty()
                        config.image = .init(systemName: "fireworks")
                        config.text = %"list.empty.nodata.title"
                        config.secondaryText = %"list.empty.nodata.subtitle"
                        contentUnavailableConfiguration = config
                    case .badSearch:
                        contentUnavailableConfiguration = UIContentUnavailableConfiguration.search()
                    case .badFilter(let filter):
                        var configuration = UIContentUnavailableConfiguration.empty()
                        configuration.image = .init(systemName: "line.3.horizontal.decrease")
                        configuration.text = %"list.empty.filter.title-\(filter.name)"
                        configuration.secondaryText = %"list.empty.filter.subtitle"
                        contentUnavailableConfiguration = configuration
                    case nil:
                        contentUnavailableConfiguration = nil
                    }
                }
            }
        }
    }
}

private extension TorrentListViewController {
    class Delegates: DelegateObject<TorrentListViewController>, UIDocumentPickerDelegate {
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            parent.viewModel.addTorrent(by: url)
        }
    }

    func makeDocumentPicker() -> UIViewController {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.init(importedAs: "com.bittorrent.torrent")], asCopy: true)
        documentPicker.delegate = delegates
        documentPicker.allowsMultipleSelection = false
        documentPicker.shouldShowFileExtensions = true
        return documentPicker
    }

    func normalizedMagnetString(_ input: String) -> String {
        let cleaned = input
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "&amp;", with: "&")
        guard cleaned.lowercased().hasPrefix("magnet:?") else { return cleaned }
        let parts = cleaned.split(separator: "&", omittingEmptySubsequences: false)
        guard let first = parts.first else { return cleaned }
        let tail = parts.dropFirst().compactMap { part -> String? in
            let item = String(part).trimmingCharacters(in: .whitespacesAndNewlines)
            guard !item.isEmpty else { return nil }
            let lower = item.lowercased()
            if lower == "dn" || lower == "dn=" { return nil }
            return item
        }
        return ([String(first)] + tail).joined(separator: "&")
    }

    func makeMagnetAlert() -> UIAlertController {
        let alert = UIAlertController(title: %"list.add.magnet.title", message: %"list.add.magnet.message", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = %"list.add.magnet.placeholder"
        }

        alert.addAction(.init(title: %"common.cancel", style: .cancel))
        alert.addAction(.init(title: %"common.ok", style: .default) { [unowned self] _ in
            guard let text = alert.textFields?.first?.text,
                  let url = URL(string: normalizedMagnetString(text)),
                  let magnet = MagnetURI(with: url)
            else {
                let alert = UIAlertController(title: %"common.error", message: %"list.add.magnet.error", preferredStyle: .alert)
                alert.addAction(.init(title: %"common.close", style: .cancel), isPrimary: true)
                present(alert, animated: true)
                return
            }

            guard !TorrentService.shared.checkTorrentExists(with: magnet.infoHashes) else {
                let alert = UIAlertController(title: %"addTorrent.exists", message: %"addTorrent.\(magnet.infoHashes.best.hex)_exists", preferredStyle: .alert)
                alert.addAction(.init(title: %"common.close", style: .cancel), isPrimary: true)
                present(alert, animated: true)
                return
            }

            TorrentService.shared.addTorrent(by: magnet)
        }, isPrimary: true)
        return alert
    }

    func makeUrlAlert() -> UIAlertController {
        let alert = UIAlertController(title: %"list.add.url.title", message: %"list.add.url.message", preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = %"list.add.url.placeholder"
        }

        alert.addAction(.init(title: %"common.cancel", style: .cancel))
        alert.addAction(.init(title: %"common.ok", style: .default) { [unowned self] _ in
            Task {
                guard let text = alert.textFields?.first?.text,
                      let url = URL(string: text),
                      ["http", "https"].contains(url.scheme?.lowercased())
                else {
                    let alert = UIAlertController(title: %"common.error", message: %"list.add.url.error", preferredStyle: .alert)
                    alert.addAction(.init(title: %"common.close", style: .cancel))
                    present(alert, animated: true)
                    return
                }

                do {
                    let torrentFile = try await TorrentFile.download(from: url)
                    TorrentAddViewModel.present(with: torrentFile, from: self)
                } catch {
                    presentRemoteTorrentDownloadError(error, url: url)
                }
            }
        }, isPrimary: true)
        return alert
    }

    static func makeTagsView() -> TagsView {
        let tagsView = TagsView()
        tagsView.translatesAutoresizingMaskIntoConstraints = false
        return tagsView
    }
}

private extension TorrentListViewController {
    var fixedSpacing: UIBarButtonItem? {
        if #available(iOS 26, *) {
            return nil
        } else {
            return UIBarButtonItem.fixedSpace(44)
        }
    }
}

private extension TorrentListViewModel.Sort {
    var name: String {
        switch self {
        case .alphabetically:
            return %"list.sort.name"
        case .creationDate:
            return %"list.sort.creationDate"
        case .addedDate:
            return %"list.sort.addedDate"
        case .size:
            return %"list.sort.size"
        }
    }
}

extension TorrentHandle.State {
    static var filterArray: [TorrentHandle.State] {
        [
            .finished,
            .downloading,
            .seeding,
            .paused,
            .checkingFiles,
            .downloadingMetadata,
            .checkingResumeData,

            // Custom state for storage error
            .storageError
        ]
    }
}


// MARK: - BT Mobile 0.1.5 File Manager

/// App-sandbox file manager used by BT Mobile 0.1.4. It intentionally does not
/// touch libtorrent discovery, tracker, DHT or peer logic. Download routing is
/// implemented by registering the selected sandbox folder as a normal storage
/// UUID, which the existing Session already understands.
final class BTFileManagerService {
    struct Item {
        let url: URL
        let isDirectory: Bool
        let size: Int64
        let modificationDate: Date?

        var name: String { url.lastPathComponent }
        var pathExtension: String { url.pathExtension.lowercased() }

        var isArchive: Bool {
            ["zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz"].contains(pathExtension)
                || ArchiveExtractor.isSevenZipVolume(url)
                || ArchiveExtractor.isZipVolume(url)
        }

        var isVideo: Bool {
            ["mp4", "m4v", "mov", "mkv", "avi", "flv", "webm", "ts", "m2ts", "wmv", "mpg", "mpeg"].contains(pathExtension)
        }

        /// V0.1.6: common image formats that can be viewed inside BTMobile.
        var isImage: Bool {
            ["jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "tif", "tiff"].contains(pathExtension)
        }

        /// V0.1.6 deliberately scopes editing to plain .txt files so the
        /// established behavior of every other file type remains unchanged.
        var isEditableText: Bool {
            pathExtension == "txt"
        }
    }

    struct TorrentFileMatch {
        let handle: TorrentHandle
        let fileIndex: Int
        let isComplete: Bool
    }

    static let shared = BTFileManagerService()
    static let rootURL = TorrentService.downloadPath.appendingPathComponent("BTmobile", isDirectory: true)

    private let fileManager = FileManager.default
    private let preferences = PreferencesStorage.shared

    private init() {
        ensureRootDirectory()
        repairManagedStorages()
    }

    func ensureRootDirectory() {
        try? fileManager.createDirectory(at: Self.rootURL, withIntermediateDirectories: true)
    }

    /// Fresh V0.1.4 installs use Documents/BTmobile as the managed download
    /// root. An existing explicit external default from V0.1.3 is respected.
    func prepareDefaultDownloadDirectoryIfNeeded() {
        ensureRootDirectory()
        guard preferences.btMobileManagedDefaultStorage == nil,
              preferences.defaultStorage == nil
        else { return }
        _ = try? setDownloadDirectory(Self.rootURL)
    }

    func items(in directory: URL) -> [Item] {
        guard isManagedURL(directory) else { return [] }
        ensureRootDirectory()
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey, .isHiddenKey]
        let urls = (try? fileManager.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: Array(keys),
            options: [.skipsHiddenFiles]
        )) ?? []

        return urls.compactMap { url in
            let values = try? url.resourceValues(forKeys: keys)
            if values?.isHidden == true { return nil }
            let isDirectory = values?.isDirectory == true
            let logicalSize: Int64
            if isDirectory {
                logicalSize = 0
            } else if let fileSize = values?.fileSize {
                logicalSize = Int64(fileSize)
            } else if let attributes = try? fileManager.attributesOfItem(atPath: url.path),
                      let number = attributes[.size] as? NSNumber {
                logicalSize = number.int64Value
            } else {
                logicalSize = 0
            }
            return Item(
                url: url,
                isDirectory: isDirectory,
                size: logicalSize,
                modificationDate: values?.contentModificationDate
            )
        }
        .sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory && !$1.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    /// Resolves a file-manager URL back to the live torrent and file index.
    /// The player needs this pair to enable piece deadlines and segmented
    /// progress when the same unfinished video is opened outside task details.
    func torrentFileMatch(for fileURL: URL) -> TorrentFileMatch? {
        guard isManagedURL(fileURL) else { return nil }

        let targetPath = canonicalPath(fileURL)
        for handle in TorrentService.shared.torrents.values {
            let snapshot = handle.snapshot
            guard let downloadPath = snapshot.downloadPath else { continue }

            for file in snapshot.files {
                let fileIndex = Int(file.index)
                let candidateURL = downloadPath.appending(path: file.path)
                guard canonicalPath(candidateURL) == targetPath else { continue }

                return TorrentFileMatch(
                    handle: handle,
                    fileIndex: fileIndex,
                    isComplete: file.downloaded >= file.size
                )
            }
        }
        return nil
    }

    private func canonicalPath(_ url: URL) -> String {
        url.standardizedFileURL
            .resolvingSymlinksInPath()
            .path
            .precomposedStringWithCanonicalMapping
    }

    @discardableResult
    func createFolder(named rawName: String, in directory: URL) throws -> URL {
        let name = try validatedName(rawName)
        let url = directory.appendingPathComponent(name, isDirectory: true)
        guard isManagedURL(url) else { throw ManagerError.invalidPath }
        guard !fileManager.fileExists(atPath: url.path) else { throw ManagerError.alreadyExists }
        try fileManager.createDirectory(at: url, withIntermediateDirectories: false)
        return url
    }

    @discardableResult
    func rename(_ itemURL: URL, to rawName: String) throws -> URL {
        let name = try validatedName(rawName)
        guard isManagedURL(itemURL), itemURL.standardizedFileURL != Self.rootURL.standardizedFileURL else {
            throw ManagerError.invalidPath
        }
        let destination = itemURL.deletingLastPathComponent().appendingPathComponent(name)
        guard isManagedURL(destination) else { throw ManagerError.invalidPath }
        guard !fileManager.fileExists(atPath: destination.path) else { throw ManagerError.alreadyExists }

        try fileManager.moveItem(at: itemURL, to: destination)
        updateManagedStoragesAfterMove(from: itemURL, to: destination)
        return destination
    }

    func delete(_ itemURL: URL) throws {
        guard isManagedURL(itemURL), itemURL.standardizedFileURL != Self.rootURL.standardizedFileURL else {
            throw ManagerError.invalidPath
        }
        try fileManager.removeItem(at: itemURL)
        removeManagedStorages(under: itemURL)
    }

    @discardableResult
    func setDownloadDirectory(_ directory: URL) throws -> UUID {
        guard isManagedURL(directory), directory.hasDirectoryPath || directory.isDirectory else {
            throw ManagerError.invalidPath
        }
        ensureRootDirectory()

        var storages = preferences.btMobileManagedStorageScopes
        if let existing = storages.values.first(where: { $0.url.standardizedFileURL == directory.standardizedFileURL }) {
            existing.allowed = true
            existing.resolved = true
            existing.name = managedDisplayPath(for: directory)
            storages[existing.uuid] = existing
            preferences.btMobileManagedStorageScopes = storages
            preferences.btMobileManagedDefaultStorage = existing.uuid
            return existing.uuid
        }

        let storage = StorageModel()
        storage.uuid = UUID()
        storage.name = managedDisplayPath(for: directory)
        storage.url = directory.standardizedFileURL
        storage.allowed = true
        storage.resolved = true
        // Managed sandbox folders do not require a security-scoped bookmark.
        // Keep a valid Codable payload for the existing StorageModel format.
        storage.pathBookmark = Data()

        storages[storage.uuid] = storage
        preferences.btMobileManagedStorageScopes = storages
        preferences.btMobileManagedDefaultStorage = storage.uuid
        return storage.uuid
    }

    func isCurrentDownloadDirectory(_ directory: URL) -> Bool {
        guard let uuid = preferences.btMobileManagedDefaultStorage,
              let storage = preferences.btMobileManagedStorageScopes[uuid]
        else { return false }
        return storage.url.standardizedFileURL == directory.standardizedFileURL
    }

    var currentDownloadDirectory: URL? {
        guard let uuid = preferences.btMobileManagedDefaultStorage else { return nil }
        return preferences.btMobileManagedStorageScopes[uuid]?.url
    }

    func isManagedURL(_ url: URL) -> Bool {
        let root = Self.rootURL.standardizedFileURL.path
        let candidate = url.standardizedFileURL.path
        return candidate == root || candidate.hasPrefix(root + "/")
    }

    func suggestedExtractionDirectory(for archiveURL: URL) -> URL {
        let stem: String
        if let volumeBaseName = ArchiveExtractor.sevenZipVolumeBaseName(archiveURL) {
            stem = volumeBaseName
        } else if let volumeBaseName = ArchiveExtractor.zipVolumeBaseName(archiveURL) {
            stem = volumeBaseName
        } else if archiveURL.lastPathComponent.lowercased().hasSuffix(".tar.gz") {
            stem = String(archiveURL.lastPathComponent.dropLast(7))
        } else {
            stem = archiveURL.deletingPathExtension().lastPathComponent
        }
        var candidate = archiveURL.deletingLastPathComponent().appendingPathComponent(stem, isDirectory: true)
        var index = 2
        while fileManager.fileExists(atPath: candidate.path) {
            candidate = archiveURL.deletingLastPathComponent().appendingPathComponent("\(stem) \(index)", isDirectory: true)
            index += 1
        }
        return candidate
    }

    private func validatedName(_ rawName: String) throws -> String {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty,
              name != ".",
              name != "..",
              !name.contains("/"),
              !name.contains("\\"),
              !name.contains(":")
        else { throw ManagerError.invalidName }
        return name
    }

    private func managedDisplayPath(for url: URL) -> String {
        let root = Self.rootURL.standardizedFileURL.path
        let path = url.standardizedFileURL.path
        if path == root { return "BTmobile" }
        let suffix = String(path.dropFirst(root.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return suffix.isEmpty ? "BTmobile" : "BTmobile/\(suffix)"
    }

    private func updateManagedStoragesAfterMove(from oldURL: URL, to newURL: URL) {
        let oldPath = oldURL.standardizedFileURL.path
        let oldPrefix = oldPath + "/"
        var storages = preferences.btMobileManagedStorageScopes

        for (uuid, storage) in storages {
            let path = storage.url.standardizedFileURL.path
            guard path == oldPath || path.hasPrefix(oldPrefix) else { continue }
            let suffix = String(path.dropFirst(oldPath.count))
            let newPath = newURL.standardizedFileURL.path + suffix
            let updatedURL = URL(fileURLWithPath: newPath, isDirectory: true)
            storage.url = updatedURL
            storage.name = managedDisplayPath(for: updatedURL)
            storage.allowed = fileManager.fileExists(atPath: updatedURL.path)
            storage.resolved = storage.allowed
            storages[uuid] = storage
        }
        preferences.btMobileManagedStorageScopes = storages
    }

    private func removeManagedStorages(under deletedURL: URL) {
        let deletedPath = deletedURL.standardizedFileURL.path
        let prefix = deletedPath + "/"
        var storages = preferences.btMobileManagedStorageScopes
        let removed = storages.compactMap { uuid, storage -> UUID? in
            let path = storage.url.standardizedFileURL.path
            return path == deletedPath || path.hasPrefix(prefix) ? uuid : nil
        }
        removed.forEach { storages[$0] = nil }
        preferences.btMobileManagedStorageScopes = storages
        if let current = preferences.btMobileManagedDefaultStorage, removed.contains(current) {
            preferences.btMobileManagedDefaultStorage = nil
        }
    }

    private func repairManagedStorages() {
        var storages = preferences.btMobileManagedStorageScopes
        var removed: [UUID] = []
        for (uuid, storage) in storages {
            guard isManagedURL(storage.url), fileManager.fileExists(atPath: storage.url.path) else {
                removed.append(uuid)
                continue
            }
            storage.allowed = true
            storage.resolved = true
            storage.name = managedDisplayPath(for: storage.url)
            storages[uuid] = storage
        }
        removed.forEach { storages[$0] = nil }
        preferences.btMobileManagedStorageScopes = storages
        if let current = preferences.btMobileManagedDefaultStorage, storages[current] == nil {
            preferences.btMobileManagedDefaultStorage = nil
        }
    }

    enum ManagerError: LocalizedError {
        case invalidName
        case invalidPath
        case alreadyExists

        var errorDescription: String? {
            switch self {
            case .invalidName: return "文件名无效，请不要使用 / \\ : 或 . .."
            case .invalidPath: return "只能管理 BTmobile 目录内的文件。"
            case .alreadyExists: return "同名文件或文件夹已经存在。"
            }
        }
    }
}

final class BTFileManagerCell: UITableViewCell {
    static let reuseIdentifier = "BTFileManagerCellV015"

    private let fileIconView = UIImageView()
    private let nameLabel = UILabel()
    private let detailLabel = UILabel()
    private let sizeLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        fileIconView.translatesAutoresizingMaskIntoConstraints = false
        fileIconView.contentMode = .scaleAspectFit
        fileIconView.tintColor = .secondaryLabel

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 15, weight: .regular)
        nameLabel.textColor = .label
        nameLabel.numberOfLines = 2
        nameLabel.lineBreakMode = .byTruncatingMiddle

        detailLabel.translatesAutoresizingMaskIntoConstraints = false
        detailLabel.font = .systemFont(ofSize: 11, weight: .regular)
        detailLabel.textColor = .tertiaryLabel
        detailLabel.numberOfLines = 1

        sizeLabel.translatesAutoresizingMaskIntoConstraints = false
        sizeLabel.font = .monospacedDigitSystemFont(ofSize: 11.5, weight: .regular)
        sizeLabel.textColor = .secondaryLabel
        sizeLabel.textAlignment = .right
        sizeLabel.setContentCompressionResistancePriority(.required, for: .horizontal)
        sizeLabel.setContentHuggingPriority(.required, for: .horizontal)

        contentView.addSubview(fileIconView)
        contentView.addSubview(nameLabel)
        contentView.addSubview(detailLabel)
        contentView.addSubview(sizeLabel)

        NSLayoutConstraint.activate([
            fileIconView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 14),
            fileIconView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            fileIconView.widthAnchor.constraint(equalToConstant: 25),
            fileIconView.heightAnchor.constraint(equalToConstant: 25),

            sizeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -13),
            sizeLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            sizeLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 58),
            sizeLabel.widthAnchor.constraint(lessThanOrEqualToConstant: 88),

            nameLabel.leadingAnchor.constraint(equalTo: fileIconView.trailingAnchor, constant: 11),
            nameLabel.trailingAnchor.constraint(equalTo: sizeLabel.leadingAnchor, constant: -9),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),

            detailLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            detailLabel.trailingAnchor.constraint(lessThanOrEqualTo: sizeLabel.leadingAnchor, constant: -9),
            detailLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            detailLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -7)
        ])
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func configure(item: BTFileManagerService.Item, iconName: String) {
        fileIconView.image = UIImage(systemName: iconName)
        // Always assign a tint when reusing cells, including unknown types.
        switch iconName {
        case "folder.fill": fileIconView.tintColor = .systemBlue
        case "archivebox.fill": fileIconView.tintColor = .systemOrange
        case "play.rectangle.fill": fileIconView.tintColor = .systemPurple
        case "photo.fill": fileIconView.tintColor = .systemGreen
        case "music.note": fileIconView.tintColor = .systemPink
        case "doc.text.fill": fileIconView.tintColor = .systemTeal
        case "doc.richtext.fill": fileIconView.tintColor = .systemRed
        case "arrow.down.doc.fill": fileIconView.tintColor = .systemIndigo
        default: fileIconView.tintColor = .secondaryLabel
        }
        nameLabel.text = item.name
        if item.isDirectory {
            sizeLabel.text = "文件夹"
            detailLabel.text = "目录"
        } else {
            sizeLabel.text = ByteCountFormatter.string(fromByteCount: max(item.size, 0), countStyle: .file)
            let type = item.pathExtension.isEmpty ? "文件" : item.pathExtension.uppercased()
            if let date = item.modificationDate {
                detailLabel.text = "\(type) · \(Self.dateFormatter.string(from: date))"
            } else {
                detailLabel.text = type
            }
        }
    }

    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "MM-dd HH:mm"
        return formatter
    }()
}

final class BTFileManagerViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let service = BTFileManagerService.shared
    private var directoryURL: URL
    private var items: [BTFileManagerService.Item] = []
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private let statusLabel = UILabel()

    init(directoryURL: URL) {
        self.directoryURL = directoryURL.standardizedFileURL
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = directoryURL == BTFileManagerService.rootURL ? "BTmobile" : directoryURL.lastPathComponent
        navigationItem.largeTitleDisplayMode = .never

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 66
        tableView.register(BTFileManagerCell.self, forCellReuseIdentifier: BTFileManagerCell.reuseIdentifier)
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        statusLabel.font = .preferredFont(forTextStyle: .footnote)
        statusLabel.textColor = .secondaryLabel
        statusLabel.numberOfLines = 2
        statusLabel.textAlignment = .center
        statusLabel.frame = CGRect(x: 0, y: 0, width: 1, height: 54)
        tableView.tableHeaderView = statusLabel

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "操作",
            image: UIImage(systemName: "ellipsis.circle"),
            primaryAction: nil,
            menu: makeDirectoryMenu()
        )
        reload()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    private func reload() {
        items = service.items(in: directoryURL)
        let current = service.isCurrentDownloadDirectory(directoryURL)
        if current {
            statusLabel.text = "✓ 当前 BT 下载目录\n\(relativePath(directoryURL))"
        } else if let selected = service.currentDownloadDirectory {
            statusLabel.text = "当前下载目录：\(relativePath(selected))"
        } else {
            statusLabel.text = "尚未指定 BTmobile 自定义下载目录"
        }
        tableView.reloadData()
        navigationItem.rightBarButtonItem?.menu = makeDirectoryMenu()
    }

    private func makeDirectoryMenu() -> UIMenu {
        let newFolder = UIAction(title: "新建文件夹", image: UIImage(systemName: "folder.badge.plus")) { [weak self] _ in
            self?.promptCreateFolder()
        }
        let setDownload = UIAction(
            title: service.isCurrentDownloadDirectory(directoryURL) ? "当前已是下载目录" : "设为当前下载目录",
            image: UIImage(systemName: service.isCurrentDownloadDirectory(directoryURL) ? "checkmark.circle.fill" : "arrow.down.to.line.compact"),
            attributes: service.isCurrentDownloadDirectory(directoryURL) ? [.disabled] : []
        ) { [weak self] _ in
            self?.setCurrentDownloadDirectory()
        }
        return UIMenu(children: [newFolder, setDownload])
    }

    private func relativePath(_ url: URL) -> String {
        let root = BTFileManagerService.rootURL.standardizedFileURL.path
        let path = url.standardizedFileURL.path
        guard path.hasPrefix(root) else { return url.lastPathComponent }
        let suffix = String(path.dropFirst(root.count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return suffix.isEmpty ? "BTmobile" : "BTmobile/\(suffix)"
    }

    // MARK: Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { items.count }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = items[indexPath.row]
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: BTFileManagerCell.reuseIdentifier,
            for: indexPath
        ) as? BTFileManagerCell else {
            return UITableViewCell()
        }
        cell.configure(item: item, iconName: iconName(for: item))
        cell.accessoryType = item.isDirectory ? .disclosureIndicator : .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = items[indexPath.row]
        if item.isDirectory {
            navigationController?.pushViewController(BTFileManagerViewController(directoryURL: item.url), animated: true)
        } else if item.isArchive {
            presentArchiveMenu(for: item.url, sourceView: tableView.cellForRow(at: indexPath))
        } else if item.isVideo {
            navigateToVideo(item.url)
        } else if item.isImage {
            openImage(item.url)
        } else if item.isEditableText {
            openTextEditor(item.url)
        } else {
            share(item.url, sourceView: tableView.cellForRow(at: indexPath))
        }
    }

    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        let item = items[indexPath.row]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { [weak self] _ in
            guard let self else { return nil }
            var actions: [UIMenuElement] = []

            if item.isDirectory {
                actions.append(UIAction(title: "打开文件夹", image: UIImage(systemName: "folder")) { [weak self] _ in
                    self?.navigationController?.pushViewController(BTFileManagerViewController(directoryURL: item.url), animated: true)
                })
                actions.append(UIAction(title: "设为下载目录", image: UIImage(systemName: "arrow.down.to.line.compact")) { [weak self] _ in
                    try? self?.service.setDownloadDirectory(item.url)
                    self?.reload()
                })
            } else if item.isArchive {
                actions.append(UIAction(title: "解压", image: UIImage(systemName: "archivebox")) { [weak self] _ in
                    self?.extractArchive(item.url, password: nil)
                })
                actions.append(UIAction(title: "密码解压", image: UIImage(systemName: "lock.open")) { [weak self] _ in
                    self?.promptArchivePassword(item.url)
                })
                actions.append(UIAction(title: "用其他 App 打开", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
                    self?.share(item.url, sourceView: tableView.cellForRow(at: indexPath))
                })
            } else if item.isVideo {
                actions.append(UIAction(title: "播放", image: UIImage(systemName: "play.fill")) { [weak self] _ in
                    self?.navigateToVideo(item.url)
                })
                actions.append(UIAction(title: "用其他 App 打开", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
                    self?.share(item.url, sourceView: tableView.cellForRow(at: indexPath))
                })
            } else if item.isImage {
                actions.append(UIAction(title: "查看图片", image: UIImage(systemName: "photo")) { [weak self] _ in
                    self?.openImage(item.url)
                })
                actions.append(UIAction(title: "用其他 App 打开", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
                    self?.share(item.url, sourceView: tableView.cellForRow(at: indexPath))
                })
            } else if item.isEditableText {
                actions.append(UIAction(title: "查看 / 编辑文本", image: UIImage(systemName: "doc.text")) { [weak self] _ in
                    self?.openTextEditor(item.url)
                })
                actions.append(UIAction(title: "用其他 App 打开", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
                    self?.share(item.url, sourceView: tableView.cellForRow(at: indexPath))
                })
            } else {
                actions.append(UIAction(title: "打开 / 分享", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
                    self?.share(item.url, sourceView: tableView.cellForRow(at: indexPath))
                })
            }

            actions.append(UIAction(title: "文件信息", image: UIImage(systemName: "info.circle")) { [weak self] _ in
                self?.presentFileInfo(item)
            })
            actions.append(UIAction(title: "重命名", image: UIImage(systemName: "pencil")) { [weak self] _ in
                self?.promptRename(item.url)
            })
            actions.append(UIAction(title: "删除", image: UIImage(systemName: "trash"), attributes: .destructive) { [weak self] _ in
                self?.confirmDelete(item.url)
            })
            return UIMenu(children: actions)
        }
    }

    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let item = items[indexPath.row]
        let info = UIContextualAction(style: .normal, title: "信息") { [weak self] _, _, done in
            self?.presentFileInfo(item)
            done(true)
        }
        info.image = UIImage(systemName: "info.circle")
        return UISwipeActionsConfiguration(actions: [info])
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let item = items[indexPath.row]
        let delete = UIContextualAction(style: .destructive, title: "删除") { [weak self] _, _, done in
            self?.confirmDelete(item.url)
            done(true)
        }
        let rename = UIContextualAction(style: .normal, title: "重命名") { [weak self] _, _, done in
            self?.promptRename(item.url)
            done(true)
        }
        return UISwipeActionsConfiguration(actions: [delete, rename])
    }

    private func presentFileInfo(_ item: BTFileManagerService.Item) {
        let type: String
        if item.isDirectory {
            type = "文件夹"
        } else if item.pathExtension.isEmpty {
            type = "文件"
        } else {
            type = item.pathExtension.uppercased()
        }
        let size = item.isDirectory ? "—" : ByteCountFormatter.string(fromByteCount: max(item.size, 0), countStyle: .file)
        let modified: String
        if let date = item.modificationDate {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "zh_CN")
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            modified = formatter.string(from: date)
        } else {
            modified = "未知"
        }
        let message = "类型：\(type)\n大小：\(size)\n修改时间：\(modified)\n位置：\(relativePath(item.url.deletingLastPathComponent()))"
        let alert = UIAlertController(title: item.name, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }

    private func iconName(for item: BTFileManagerService.Item) -> String {
        if item.isDirectory { return "folder.fill" }
        if item.isArchive { return "archivebox.fill" }
        if item.isVideo { return "play.rectangle.fill" }
        switch item.pathExtension.lowercased() {
        case "jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "tif", "tiff", "avif", "svg", "ico": return "photo.fill"
        case "txt", "md", "log", "csv", "json", "xml": return "doc.text.fill"
        case "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "aiff", "aif", "wma", "amr": return "music.note"
        case "pdf": return "doc.richtext.fill"
        case "torrent": return "arrow.down.doc.fill"
        default: return "doc.fill"
        }
    }

    // MARK: V0.1.6 built-in viewers
    private func openImage(_ url: URL) {
        let controller = BTImageViewerViewController(fileURL: url)
        navigationController?.pushViewController(controller, animated: true)
    }

    private func openTextEditor(_ url: URL) {
        let controller = BTTextEditorViewController(fileURL: url)
        navigationController?.pushViewController(controller, animated: true)
    }

    // MARK: File operations
    private func promptCreateFolder() {
        let alert = UIAlertController(title: "新建文件夹", message: relativePath(directoryURL), preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "文件夹名称" }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "创建", style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text else { return }
            do {
                try service.createFolder(named: name, in: directoryURL)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func promptRename(_ url: URL) {
        let alert = UIAlertController(title: "重命名", message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = url.lastPathComponent
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "确定", style: .default) { [weak self, weak alert] _ in
            guard let self, let name = alert?.textFields?.first?.text else { return }
            do {
                _ = try service.rename(url, to: name)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func confirmDelete(_ url: URL) {
        let alert = UIAlertController(
            title: "删除“\(url.lastPathComponent)”？",
            message: "删除后无法恢复。若它仍属于正在下载的 BT 任务，任务可能出现文件缺失，请先暂停或删除对应任务。",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "删除", style: .destructive) { [weak self] _ in
            guard let self else { return }
            do {
                try service.delete(url)
                reload()
            } catch { showError(error) }
        })
        present(alert, animated: true)
    }

    private func setCurrentDownloadDirectory() {
        do {
            _ = try service.setDownloadDirectory(directoryURL)
            reload()
            let alert = UIAlertController(title: "下载目录已设置", message: "新的 BT 任务将优先保存到 \(relativePath(directoryURL))。已有任务路径保持不变。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default))
            present(alert, animated: true)
        } catch { showError(error) }
    }

    private func share(_ url: URL, sourceView: UIView?) {
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = sourceView ?? view
        vc.popoverPresentationController?.sourceRect = sourceView?.bounds ?? CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(vc, animated: true)
    }

    private func navigateToVideo(_ url: URL) {
        guard VLCPlayerViewModel.canOpenInVLCSync(url) != nil else {
            let alert = UIAlertController(title: "暂时无法播放", message: "文件可能尚未下载完整，或视频格式暂不支持。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default))
            present(alert, animated: true)
            return
        }

        let torrentPair: (handle: TorrentHandle, fileIndex: Int)?
        if let match = service.torrentFileMatch(for: url), !match.isComplete {
            // Opening an unfinished file is an explicit request to stream it.
            // Resume the task and make this file selectable even if it had a
            // lower priority before the user entered the file manager.
            match.handle.setFilesPriority(.topPriority, at: [NSNumber(value: match.fileIndex)])
            match.handle.resume()
            torrentPair = (match.handle, match.fileIndex)
        } else {
            // Completed and unmanaged videos stay on the ordinary local path.
            torrentPair = nil
        }

        let controller = VLCPlayerViewController(viewModel: .init(with: .init(url: url, torrentPair: torrentPair)))
        present(UINavigationController(rootViewController: controller), animated: true)
    }

    // MARK: Archive
    private func presentArchiveMenu(for url: URL, sourceView: UIView?) {
        let message: String
        if ArchiveExtractor.isSevenZipVolume(url) {
            message = "检测到 7z 分卷包，将自动组合同目录的 .001/.002/... 后解压"
        } else if ArchiveExtractor.isZipVolume(url) {
            message = "检测到 ZIP 分卷包，将自动组合 .zip.001/.002 或 .z01/.z02/.../.zip 后解压"
        } else {
            message = "选择解压方式"
        }
        let alert = UIAlertController(title: url.lastPathComponent, message: message, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "直接解压", style: .default) { [weak self] _ in self?.extractArchive(url, password: nil) })
        alert.addAction(UIAlertAction(title: "输入密码解压", style: .default) { [weak self] _ in self?.promptArchivePassword(url) })
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.popoverPresentationController?.sourceView = sourceView ?? view
        alert.popoverPresentationController?.sourceRect = sourceView?.bounds ?? CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(alert, animated: true)
    }

    private func promptSevenZipVolumePassword(_ url: URL) {
        let alert = UIAlertController(
            title: "7z 分卷解压",
            message: "如果这是加密分卷，请输入密码；无密码分卷可直接选择“无密码解压”。",
            preferredStyle: .alert
        )
        alert.addTextField { field in
            field.placeholder = "输入解压密码"
            field.isSecureTextEntry = true
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "无密码解压", style: .default) { [weak self] _ in
            self?.extractArchive(url, password: "")
        })
        alert.addAction(UIAlertAction(title: "密码解压", style: .default) { [weak self, weak alert] _ in
            guard let password = alert?.textFields?.first?.text, !password.isEmpty else {
                let error = ArchiveExtractor.ExtractionError(message: "请输入 7z 分卷密码，或选择“无密码解压”")
                self?.showError(error)
                return
            }
            self?.extractArchive(url, password: password)
        })
        present(alert, animated: true)
    }

    private func promptArchivePassword(_ url: URL, message: String = "请输入解压密码。") {
        let alert = UIAlertController(title: "请输入密码", message: message + "\n" + url.lastPathComponent, preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "输入解压密码"
            field.isSecureTextEntry = true
            field.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "解压", style: .default) { [weak self, weak alert] _ in
            let password = alert?.textFields?.first?.text ?? ""
            guard !password.isEmpty else {
                self?.promptArchivePassword(url, message: "密码不能为空，请输入解压密码。")
                return
            }
            self?.extractArchive(url, password: password)
        })
        present(alert, animated: true)
    }

    private func extractArchive(_ url: URL, password: String?) {
        // V0.1.6 Build 18 crash guard: a split 7z selected through the context
        // menu used to immediately probe libarchive with no passphrase. Some
        // encrypted 7z headers can fail below Swift before an Error is returned.
        // For split volumes, nil means the user has not chosen a password mode
        // yet, so route through the password dialog first. An explicitly empty
        // string still means “this split archive has no password”.
        if ArchiveExtractor.isSevenZipVolume(url), password == nil {
            promptSevenZipVolumePassword(url)
            return
        }

        let destination = service.suggestedExtractionDirectory(for: url)
        let progress = UIAlertController(title: "正在解压 · 0%", message: url.lastPathComponent + "\n准备压缩包 / 分卷", preferredStyle: .alert)
        present(progress, animated: true)

        Task.detached(priority: .userInitiated) {
            do {
                try ArchiveExtractor.extract(archiveURL: url, destinationURL: destination, password: password) { [weak progress] update in
                    Task { @MainActor in
                        guard let progress, progress.presentingViewController != nil else { return }
                        progress.title = "正在解压 · \(update.percent)%"
                        progress.message = url.lastPathComponent + "\n" + update.phase
                    }
                }
                await MainActor.run { [weak self, weak progress] in
                    progress?.dismiss(animated: true) {
                        self?.reload()
                        let done = UIAlertController(title: "解压完成 · 100%", message: destination.lastPathComponent, preferredStyle: .alert)
                        done.addAction(UIAlertAction(title: "好", style: .default))
                        self?.present(done, animated: true)
                    }
                }
            } catch {
                await MainActor.run { [weak self, weak progress] in
                    progress?.dismiss(animated: true) {
                        let failure = (error as? ArchiveFailure) ?? ArchiveFailure.translate(
                            error.localizedDescription, passwordProvided: !(password ?? "").isEmpty)
                        if failure.canRetryPassword {
                            self?.promptArchivePassword(url, message: failure.message)
                        } else {
                            self?.showError(failure)
                        }
                    }
                }
            }
        }
    }

    private func showError(_ error: Error) {
        let alert = UIAlertController(title: "操作失败", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }
}


// MARK: - BTMobile V0.1.6 Image Viewer

/// In-app image viewer for common downloaded image files.  It uses ImageIO
/// thumbnail decoding to avoid expanding very large source images at full
/// resolution just to fit an iPhone screen.  The source file itself is never
/// modified.
final class BTImageViewerViewController: UIViewController, UIScrollViewDelegate {
    private let fileURL: URL
    private let scrollView = UIScrollView()
    private let imageView = UIImageView()
    private var loadedImage: UIImage?
    private var didApplyInitialZoom = false

    init(fileURL: URL) {
        self.fileURL = fileURL
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = fileURL.lastPathComponent
        view.backgroundColor = .black
        navigationItem.largeTitleDisplayMode = .never

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .action,
            target: self,
            action: #selector(shareImage)
        )

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.delegate = self
        scrollView.backgroundColor = .black
        scrollView.bouncesZoom = true
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        view.addSubview(scrollView)

        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        let maximumDimension = max(UIScreen.main.bounds.width, UIScreen.main.bounds.height)
            * UIScreen.main.scale * 4
        guard let image = Self.downsampleImage(at: fileURL, maximumPixelDimension: maximumDimension) else {
            showLoadFailure()
            return
        }
        loadedImage = image
        imageView.image = image
        imageView.contentMode = .scaleAspectFit
        imageView.frame = CGRect(origin: .zero, size: image.size)
        scrollView.addSubview(imageView)
        scrollView.contentSize = image.size

        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        scrollView.addGestureRecognizer(doubleTap)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        guard let image = loadedImage, image.size.width > 0, image.size.height > 0 else { return }
        let available = scrollView.bounds.size
        guard available.width > 0, available.height > 0 else { return }

        let fitScale = min(available.width / image.size.width, available.height / image.size.height)
        let minimum = max(min(fitScale, 1), 0.01)
        scrollView.minimumZoomScale = minimum
        scrollView.maximumZoomScale = max(minimum * 6, 4)
        if !didApplyInitialZoom {
            didApplyInitialZoom = true
            scrollView.zoomScale = fitScale
        }
        centerImage()
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? { imageView }

    func scrollViewDidZoom(_ scrollView: UIScrollView) { centerImage() }

    private func centerImage() {
        let bounds = scrollView.bounds.size
        let frame = imageView.frame
        let horizontal = max((bounds.width - frame.width) * 0.5, 0)
        let vertical = max((bounds.height - frame.height) * 0.5, 0)
        scrollView.contentInset = UIEdgeInsets(top: vertical, left: horizontal, bottom: vertical, right: horizontal)
    }

    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
        let minimum = scrollView.minimumZoomScale
        if scrollView.zoomScale > minimum * 1.25 {
            scrollView.setZoomScale(minimum, animated: true)
            return
        }
        let target = min(max(minimum * 2.5, 1), scrollView.maximumZoomScale)
        let point = gesture.location(in: imageView)
        let width = scrollView.bounds.width / target
        let height = scrollView.bounds.height / target
        scrollView.zoom(to: CGRect(x: point.x - width / 2, y: point.y - height / 2, width: width, height: height), animated: true)
    }

    @objc private func shareImage() {
        let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        controller.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem
        present(controller, animated: true)
    }

    private func showLoadFailure() {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "无法读取这张图片\n文件可能尚未下载完整或格式不受系统支持"
        label.textColor = .secondaryLabel
        label.textAlignment = .center
        label.numberOfLines = 0
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            label.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])
    }

    private static func downsampleImage(at url: URL, maximumPixelDimension: CGFloat) -> UIImage? {
        let sourceOptions: CFDictionary = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let source = CGImageSourceCreateWithURL(url as CFURL, sourceOptions) else {
            return UIImage(contentsOfFile: url.path)
        }

        let thumbnailOptions: CFDictionary = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: max(Int(maximumPixelDimension.rounded(.up)), 1024),
            kCGImageSourceShouldCacheImmediately: true
        ] as CFDictionary

        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, thumbnailOptions) else {
            return UIImage(contentsOfFile: url.path)
        }
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - BTMobile V0.1.6 TXT Viewer / Editor

/// Plain-text viewer/editor used only for .txt files.  UITextView keeps the
/// native iOS selection handles and Copy menu, while explicit Select All and
/// Copy Selection actions make paragraph copying easy without leaving BTMobile.
final class BTTextEditorViewController: UIViewController, UITextViewDelegate {
    private struct DecodedText {
        let text: String
        let encoding: String.Encoding
        let encodingName: String
        let bom: Data?
    }

    private let fileURL: URL
    private let textView = UITextView()
    private var fileEncoding: String.Encoding = .utf8
    private var encodingName = "UTF-8"
    private var originalBOM: Data?
    private var lastSavedText = ""
    private var saveButton: UIBarButtonItem!
    private var editButton: UIBarButtonItem!
    private var finishEditingButton: UIBarButtonItem!
    private var textActionsButton: UIBarButtonItem!
    private var isEditingDocument = false
    private var detectedLinkCount = 0
    private var previousInteractivePopEnabled: Bool?

    init(fileURL: URL) {
        self.fileURL = fileURL
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = fileURL.lastPathComponent
        navigationItem.largeTitleDisplayMode = .never

        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.delegate = self
        textView.isEditable = false
        textView.isSelectable = true
        textView.dataDetectorTypes = [.link]
        textView.alwaysBounceVertical = true
        textView.font = .systemFont(ofSize: 11.5)
        textView.textContainerInset = UIEdgeInsets(top: 14, left: 12, bottom: 20, right: 12)
        textView.linkTextAttributes = [
            .foregroundColor: UIColor.systemBlue,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        textView.smartQuotesType = .no
        textView.smartDashesType = .no
        textView.smartInsertDeleteType = .no
        view.addSubview(textView)

        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            textView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        saveButton = UIBarButtonItem(title: "保存", style: .done, target: self, action: #selector(saveText))
        saveButton.isEnabled = false
        editButton = UIBarButtonItem(title: "编辑", style: .plain, target: self, action: #selector(beginEditingText))
        finishEditingButton = UIBarButtonItem(title: "完成", style: .plain, target: self, action: #selector(finishEditingText))
        textActionsButton = makeTextActionsButton()
        updateNavigationButtons()
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            title: "返回",
            style: .plain,
            target: self,
            action: #selector(requestClose)
        )

        installKeyboardToolbar()
        loadText()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if previousInteractivePopEnabled == nil {
            previousInteractivePopEnabled = navigationController?.interactivePopGestureRecognizer?.isEnabled
        }
        // A custom back confirmation protects unsaved edits.  Restore the
        // navigation controller's previous gesture state when leaving.
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let previousInteractivePopEnabled {
            navigationController?.interactivePopGestureRecognizer?.isEnabled = previousInteractivePopEnabled
        }
    }

    func textViewDidChange(_ textView: UITextView) {
        guard isEditingDocument else { return }
        updateDirtyState()
    }

    func textView(
        _ textView: UITextView,
        shouldInteractWith url: URL,
        in characterRange: NSRange,
        interaction: UITextItemInteraction
    ) -> Bool {
        openWebLink(url)
    }

    func textView(
        _ textView: UITextView,
        shouldInteractWith url: URL,
        in characterRange: NSRange
    ) -> Bool {
        openWebLink(url)
    }

    @available(iOS 17.0, *)
    func textView(
        _ textView: UITextView,
        primaryActionFor textItem: UITextItem,
        defaultAction: UIAction
    ) -> UIAction? {
        guard case let .link(url) = textItem.content,
              Self.isWebURL(url)
        else { return defaultAction }

        return UIAction { _ in
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }

    private var hasUnsavedChanges: Bool { textView.text != lastSavedText }

    private func updateDirtyState() {
        let dirty = hasUnsavedChanges
        saveButton?.isEnabled = dirty
        title = dirty ? "\(fileURL.lastPathComponent) •" : fileURL.lastPathComponent
    }

    private func updateNavigationButtons() {
        if isEditingDocument {
            navigationItem.rightBarButtonItems = [saveButton, finishEditingButton, textActionsButton]
        } else {
            navigationItem.rightBarButtonItems = [editButton, textActionsButton]
        }
    }

    private func showReadingMode(text source: String? = nil) {
        let plainText = source ?? textView.text ?? ""
        isEditingDocument = false
        textView.resignFirstResponder()
        textView.isEditable = false
        textView.isSelectable = true
        textView.dataDetectorTypes = [.link]

        let rendered = TextDocumentPreviewViewController.linkedText(plainText)
        detectedLinkCount = rendered.linkCount
        textView.attributedText = rendered.text
        title = fileURL.lastPathComponent
        navigationItem.prompt = "文本阅读 · \(encodingName) · \(detectedLinkCount) 个链接"
        saveButton?.isEnabled = false
        updateNavigationButtons()
    }

    @objc private func beginEditingText() {
        let plainText = textView.text ?? ""
        isEditingDocument = true
        textView.dataDetectorTypes = []
        textView.isEditable = true
        textView.isSelectable = true
        textView.attributedText = NSAttributedString(
            string: plainText,
            attributes: [
                .font: UIFont.monospacedSystemFont(ofSize: 15, weight: .regular),
                .foregroundColor: UIColor.label
            ]
        )
        navigationItem.prompt = "文本编辑 · \(encodingName)"
        updateDirtyState()
        updateNavigationButtons()
        textView.becomeFirstResponder()
    }

    @objc private func finishEditingText() {
        guard hasUnsavedChanges else {
            showReadingMode()
            return
        }

        let alert = UIAlertController(title: "保存修改？", message: fileURL.lastPathComponent, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "不保存", style: .destructive) { [weak self] _ in
            guard let self else { return }
            showReadingMode(text: lastSavedText)
        })
        alert.addAction(UIAlertAction(title: "保存", style: .default) { [weak self] _ in
            self?.saveText()
        })
        present(alert, animated: true)
    }

    private func openWebLink(_ url: URL) -> Bool {
        guard !isEditingDocument, Self.isWebURL(url) else { return false }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        return false
    }

    private func loadText() {
        do {
            let data = try Data(contentsOf: fileURL, options: [.mappedIfSafe])
            guard let decoded = Self.decode(data) else {
                throw TextEditorError.unsupportedEncoding
            }
            fileEncoding = decoded.encoding
            encodingName = decoded.encodingName
            originalBOM = decoded.bom
            lastSavedText = decoded.text
            showReadingMode(text: decoded.text)
        } catch {
            textView.isEditable = false
            textView.text = ""
            showError(error)
        }
    }

    private func makeTextActionsButton() -> UIBarButtonItem {
        let selectAll = UIAction(title: "全选", image: UIImage(systemName: "selection.pin.in.out")) { [weak self] _ in
            guard let self else { return }
            textView.becomeFirstResponder()
            textView.selectedRange = NSRange(location: 0, length: (textView.text as NSString).length)
        }
        let copySelection = UIAction(title: "复制选中", image: UIImage(systemName: "doc.on.doc")) { [weak self] _ in
            self?.copySelectedText()
        }
        let share = UIAction(title: "用其他 App 打开", image: UIImage(systemName: "square.and.arrow.up")) { [weak self] _ in
            self?.shareTextFile()
        }
        return UIBarButtonItem(
            title: "更多",
            image: UIImage(systemName: "ellipsis.circle"),
            primaryAction: nil,
            menu: UIMenu(children: [copySelection, selectAll, share])
        )
    }

    private func installKeyboardToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        toolbar.items = [
            UIBarButtonItem(title: "全选", style: .plain, target: self, action: #selector(selectAllText)),
            UIBarButtonItem(title: "复制选中", style: .plain, target: self, action: #selector(copySelectedText)),
            UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil),
            UIBarButtonItem(title: "完成", style: .done, target: self, action: #selector(dismissKeyboard))
        ]
        textView.inputAccessoryView = toolbar
    }

    @objc private func selectAllText() {
        textView.selectedRange = NSRange(location: 0, length: (textView.text as NSString).length)
    }

    @objc private func copySelectedText() {
        let selected = textView.selectedRange
        guard selected.length > 0,
              selected.location != NSNotFound,
              NSMaxRange(selected) <= (textView.text as NSString).length else {
            showMessage(title: "没有选中文本", message: "请先长按并拖动选择需要复制的段落。")
            return
        }
        UIPasteboard.general.string = (textView.text as NSString).substring(with: selected)
        showMessage(title: "已复制", message: "选中的文字已经复制到剪贴板。")
    }

    @objc private func dismissKeyboard() { textView.resignFirstResponder() }

    @objc private func saveText() {
        do {
            try writeCurrentText()
            lastSavedText = textView.text
            showReadingMode(text: lastSavedText)
        } catch {
            showError(error)
        }
    }

    private func writeCurrentText() throws {
        guard var data = textView.text.data(using: fileEncoding, allowLossyConversion: false) else {
            throw TextEditorError.cannotEncode(encodingName)
        }
        if let bom = originalBOM, !data.starts(with: bom) {
            data = bom + data
        }
        try data.write(to: fileURL, options: .atomic)
    }

    @objc private func requestClose() {
        guard hasUnsavedChanges else {
            navigationController?.popViewController(animated: true)
            return
        }
        let alert = UIAlertController(title: "保存修改？", message: fileURL.lastPathComponent, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "不保存", style: .destructive) { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        })
        alert.addAction(UIAlertAction(title: "保存并返回", style: .default) { [weak self] _ in
            guard let self else { return }
            do {
                try writeCurrentText()
                lastSavedText = textView.text
                navigationController?.popViewController(animated: true)
            } catch {
                showError(error)
            }
        })
        present(alert, animated: true)
    }

    private func shareTextFile() {
        let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        controller.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItems?.last
        present(controller, animated: true)
    }

    private func showMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }

    private func showError(_ error: Error) {
        let alert = UIAlertController(title: "文本文件打开失败", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }

    private static func decode(_ data: Data) -> DecodedText? {
        let utf8BOM = Data([0xEF, 0xBB, 0xBF])
        let utf16LEBOM = Data([0xFF, 0xFE])
        let utf16BEBOM = Data([0xFE, 0xFF])

        let bomCandidates: [(Data, String.Encoding, String)] = [
            (utf8BOM, .utf8, "UTF-8"),
            (utf16LEBOM, .utf16LittleEndian, "UTF-16 LE"),
            (utf16BEBOM, .utf16BigEndian, "UTF-16 BE")
        ]
        for (bom, encoding, name) in bomCandidates where data.starts(with: bom) {
            let payload = data.dropFirst(bom.count)
            if let text = String(data: Data(payload), encoding: encoding) {
                return DecodedText(text: text, encoding: encoding, encodingName: name, bom: bom)
            }
        }

        // 0x80000632 / 0x80000631 are Foundation NSStringEncoding values
        // corresponding to GB18030 and GBK, useful for Chinese TXT files.
        let gb18030 = String.Encoding(rawValue: 0x80000632)
        let gbk = String.Encoding(rawValue: 0x80000631)
        let candidates: [(String.Encoding, String)] = [
            (.utf8, "UTF-8"),
            (gb18030, "GB18030"),
            (gbk, "GBK"),
            (.utf16LittleEndian, "UTF-16 LE"),
            (.utf16BigEndian, "UTF-16 BE")
        ]
        for (encoding, name) in candidates {
            if let text = String(data: data, encoding: encoding) {
                return DecodedText(text: text, encoding: encoding, encodingName: name, bom: nil)
            }
        }
        return nil
    }

    private static func isWebURL(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        return ["http", "https"].contains(scheme)
    }

    private enum TextEditorError: LocalizedError {
        case unsupportedEncoding
        case cannotEncode(String)

        var errorDescription: String? {
            switch self {
            case .unsupportedEncoding:
                return "无法识别文本编码。当前支持 UTF-8、UTF-16、GB18030/GBK 等常见 TXT 编码。"
            case let .cannotEncode(name):
                return "修改后的内容无法使用原文件编码 \(name) 保存。请删除该编码无法表示的字符后重试。"
            }
        }
    }
}
