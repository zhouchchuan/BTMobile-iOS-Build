import Foundation

/// Presentation-only translation. Never expose native errors, paths or passwords in alerts.
public struct ArchiveFailure: LocalizedError, Sendable {
    public let message: String
    public let canRetryPassword: Bool
    public var errorDescription: String? { message }

    public static func translate(_ raw: String, passwordProvided: Bool,
                                 encrypted: Bool = false, sevenZipOpenFailed: Bool = false) -> ArchiveFailure {
        let text = raw.lowercased()
        func has(_ values: [String]) -> Bool { values.contains { text.contains($0) } }
        func result(_ message: String, retry: Bool = false) -> ArchiveFailure {
            ArchiveFailure(message: message, canRetryPassword: retry)
        }
        // Unsupported encryption and I/O failures cannot be fixed by repeatedly entering passwords.
        if has(["unsupported", "not supported", "not implemented", "no crypto", "不支持"]) {
            return result("暂不支持此压缩包的压缩或加密方式，请更换兼容格式后重试。")
        }
        if has(["no space", "disk full", "空间不足"]) { return result("存储空间不足，请清理空间后重新解压。") }
        if has(["permission denied", "access denied", "read-only", "unable to create", "unable to write", "can't create output"]) {
            return result("无法写入解压文件，请检查目录权限和可用存储空间。")
        }
        if has(["unsafe", "symbolic link", "symlink", "path traversal", "too long"]) {
            return result("压缩包包含不安全或过长的文件路径，已停止解压。")
        }
        if has(["truncated", "unexpected end", "premature end", "missing volume", "缺少", "不完整"]) {
            return result("压缩包或分卷不完整，请确认文件已下载完成，并将全部分卷放在同一目录。")
        }
        let passwordError = has(["password", "passphrase", "encrypted", "encryption", "decrypt", "密码"])
        let dataError = has(["crc", "checksum", "data error", "corrupt", "error extracting", "extract error", "extracted with error"])
        if passwordError || (encrypted && dataError) {
            if !passwordProvided { return result("此压缩包已加密，请输入密码。", retry: true) }
            if has(["wrong password", "incorrect password", "incorrect passphrase", "密码错误"]) {
                return result("密码错误，请重新输入密码。", retry: true)
            }
            return result("密码错误或加密数据已损坏，请核对密码后重试。", retry: true)
        }
        // PLzmaSDK 1.2.5 uses the same open error for encrypted headers and damaged archives.
        // Offer a password without incorrectly claiming that every damaged 7z is encrypted.
        if sevenZipOpenFailed {
            return result(passwordProvided
                ? "密码错误或压缩包已损坏，请核对密码及文件完整性。"
                : "此压缩包可能已加密，请输入密码；若没有密码，请检查文件是否完整。", retry: true)
        }
        if dataError { return result("压缩包数据校验失败，文件可能已损坏，请重新下载后再试。") }
        if has(["no such file", "not found"]) { return result("找不到压缩包或所需分卷，请检查文件是否存在。") }
        if has(["unrecognized archive", "can't open", "cannot open", "invalid header", "bad header"]) {
            return result("无法打开压缩包，请检查格式是否受支持、文件是否完整。")
        }
        // Keep existing Chinese safety/volume messages; unknown native messages get a safe fallback.
        if raw.unicodeScalars.contains(where: { (0x4E00...0x9FFF).contains($0.value) }) { return result(raw) }
        return result("解压失败，请检查压缩包格式、文件完整性及可用存储空间。")
    }
}
