// BTmobile V1.1.8: local trial quota and server-signed paid entitlement.
// No merchant credentials, payment signing keys, or locally editable paid flag.
import Foundation
import CryptoKit
import Security

struct BTMagnetLedger: Codable {
    var deviceID: UUID
    var day: String
    var used: Int
    var lastSeen: Date

    static func dayKey(_ date: Date) -> String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 8 * 3600)!
        let c = calendar.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year!, c.month!, c.day!)
    }

    mutating func advance(to now: Date) {
        // A backwards clock change must not grant a fresh allowance.
        let effective = max(now, lastSeen)
        let newDay = Self.dayKey(effective)
        if newDay != day { day = newDay; used = 0 }
        lastSeen = effective
    }

    mutating func reserve(at now: Date) -> Bool {
        advance(to: now)
        guard used < 3 else { return false }
        used += 1
        return true
    }
}

enum BTSubscriptionError: LocalizedError {
    case storage(OSStatus)
    case damagedIdentity
    var errorDescription: String? {
        switch self {
        case .storage: return "暂时无法读取设备身份或保存免费额度，请解锁设备后重试。"
        case .damagedIdentity: return "设备身份数据无法校验，请联系支持人员。为保护已有身份，本次未重置数据。"
        }
    }
}

enum BTSubscriptionKeychain {
    static let service = "com.mxmall123.app.subscription.v1"
    static func query(_ account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service, kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }
    static func read(_ account: String) throws -> Data? {
        var q = query(account)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw BTSubscriptionError.storage(status)
        }
        return data
    }
    static func write(_ data: Data, account: String) throws {
        let q = query(account)
        let values: [String: Any] = [kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        var status = SecItemUpdate(q as CFDictionary, values as CFDictionary)
        if status == errSecItemNotFound {
            status = SecItemAdd(q.merging(values) { _, new in new } as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw BTSubscriptionError.storage(status) }
    }
}

final class BTSubscription: @unchecked Sendable {
    static let shared = BTSubscription()
    static let changed = Notification.Name("BTmobile.subscription.changed")
    private let lock = NSRecursiveLock()
    private init() {}

    struct Snapshot {
        let deviceID: String
        let remaining: Int
        let error: String?
        var expiresAt: Date? = nil
        var paid = false
        var paymentsEnabled = false
        var subscriptionEnabled = true
        var policyFresh = false
        var startsAt: Date? = nil
        var paymentChannels: [String] = []
        var unlimited: Bool { paid || !subscriptionEnabled }
        var statusText: String { paid ? "已订阅" : "未订阅" }
        var allowanceText: String {
            if paid { return "无限添加磁力任务" }
            if !subscriptionEnabled { return "免费无限添加磁力任务" }
            return "每天免费添加3次 · 今日剩余\(remaining)次"
        }
    }
    enum AdditionResult { case added, rejected, quotaExceeded, unavailable(String) }

    private func load(now: Date) throws -> (BTMagnetLedger, SymmetricKey) {
        let storedKey = try BTSubscriptionKeychain.read("encryption-key")
        let encrypted = try BTSubscriptionKeychain.read("identity-ledger")
        if encrypted != nil && storedKey == nil { throw BTSubscriptionError.damagedIdentity }
        let key: SymmetricKey
        if let storedKey {
            guard storedKey.count == 32 else { throw BTSubscriptionError.damagedIdentity }
            key = SymmetricKey(data: storedKey)
        } else {
            key = SymmetricKey(size: .bits256)
            try BTSubscriptionKeychain.write(key.withUnsafeBytes { Data($0) }, account: "encryption-key")
        }
        var ledger: BTMagnetLedger
        if let encrypted {
            do {
                let box = try AES.GCM.SealedBox(combined: encrypted)
                let data = try AES.GCM.open(box, using: key,
                    authenticating: Data(BTSubscriptionKeychain.service.utf8))
                ledger = try JSONDecoder().decode(BTMagnetLedger.self, from: data)
                guard (0...3).contains(ledger.used), ledger.day == BTMagnetLedger.dayKey(ledger.lastSeen) else {
                    throw BTSubscriptionError.damagedIdentity
                }
            } catch { throw BTSubscriptionError.damagedIdentity }
        } else {
            ledger = BTMagnetLedger(deviceID: UUID(), day: BTMagnetLedger.dayKey(now), used: 0, lastSeen: now)
        }
        ledger.advance(to: now)
        try save(ledger, key: key)
        return (ledger, key)
    }
    private func save(_ ledger: BTMagnetLedger, key: SymmetricKey) throws {
        let sealed = try AES.GCM.seal(JSONEncoder().encode(ledger), using: key,
            authenticating: Data(BTSubscriptionKeychain.service.utf8))
        guard let data = sealed.combined else { throw BTSubscriptionError.damagedIdentity }
        try BTSubscriptionKeychain.write(data, account: "identity-ledger")
    }
    var snapshot: Snapshot {
        lock.lock(); defer { lock.unlock() }
        do {
            let (ledger, _) = try load(now: Date())
            let claim = try? cachedClaim(deviceID: ledger.deviceID.uuidString)
            let now = max(Date(), ledger.lastSeen).timeIntervalSince1970
            let fresh = claim.map { $0.issuedAt <= now + 300 && $0.validUntil > now } ?? false
            return Snapshot(deviceID: ledger.deviceID.uuidString, remaining: max(0, 3 - ledger.used), error: nil,
                expiresAt: claim.flatMap { $0.expiresAt > 0 ? Date(timeIntervalSince1970: $0.expiresAt) : nil },
                paid: fresh && (claim?.expiresAt ?? 0) > now,
                paymentsEnabled: fresh && (claim?.paymentsEnabled ?? false),
                subscriptionEnabled: !fresh || (claim?.subscriptionEnabled ?? true), policyFresh: fresh,
                startsAt: claim.flatMap { ($0.startsAt ?? 0) > 0 ? Date(timeIntervalSince1970: $0.startsAt!) : nil },
                paymentChannels: fresh ? (claim?.paymentChannels ?? ["alipay", "wxpay"]) : [])
        } catch {
            return Snapshot(deviceID: "暂不可用", remaining: 0, error: error.localizedDescription)
        }
    }

    // Call only for a new magnet, after duplicate detection. Existing torrents,
    // .torrent imports, restores, resume, seeding, and streaming are unaffected.
    func addMagnet(_ operation: () -> Bool) -> AdditionResult {
        lock.lock(); defer { lock.unlock() }
        do {
            var (ledger, key) = try load(now: Date())
            let claim = try? cachedClaim(deviceID: ledger.deviceID.uuidString)
            let now = max(Date(), ledger.lastSeen).timeIntervalSince1970
            if let claim, claim.allowsUnlimited(at: now) {
                return operation() ? .added : .rejected
            }
            let before = ledger
            guard ledger.reserve(at: Date()) else { return .quotaExceeded }
            // Persist before starting the core operation; never start an unaccounted task.
            try save(ledger, key: key)
            let added = operation()
            if !added { try save(before, key: key) }
            DispatchQueue.main.async { NotificationCenter.default.post(name: Self.changed, object: nil) }
            return added ? .added : .rejected
        } catch { return .unavailable(error.localizedDescription) }
    }

    private func cachedClaim(deviceID: String) throws -> BTSubscriptionClaim? {
        guard let data = try BTSubscriptionKeychain.read("entitlement") else { return nil }
        let claim: BTSubscriptionClaim = try BTSubscriptionVerifier.decode(data)
        guard claim.deviceID == deviceID, claim.validUntil > claim.issuedAt,
              claim.validUntil - claim.issuedAt <= 86400, claim.priceCents == 800, claim.days == 30 else {
            throw BTSubscriptionError.damagedIdentity
        }
        return claim
    }

    func storeEntitlement(_ data: Data) throws {
        lock.lock(); defer { lock.unlock() }
        let (ledger, _) = try load(now: Date())
        let claim: BTSubscriptionClaim = try BTSubscriptionVerifier.decode(data)
        let now = max(Date(), ledger.lastSeen).timeIntervalSince1970
        guard claim.deviceID == ledger.deviceID.uuidString, abs(claim.issuedAt - now) < 300,
              claim.validUntil > now, claim.validUntil - claim.issuedAt <= 86400,
              claim.priceCents == 800, claim.days == 30 else { throw BTSubscriptionError.damagedIdentity }
        if let old = try cachedClaim(deviceID: ledger.deviceID.uuidString), old.issuedAt > claim.issuedAt {
            throw BTSubscriptionError.damagedIdentity
        }
        try BTSubscriptionKeychain.write(data, account: "entitlement")
        DispatchQueue.main.async { NotificationCenter.default.post(name: Self.changed, object: nil) }
    }

    func deviceKey() throws -> P256.Signing.PrivateKey {
        lock.lock(); defer { lock.unlock() }
        if let data = try BTSubscriptionKeychain.read("device-signing-key") {
            return try P256.Signing.PrivateKey(rawRepresentation: data)
        }
        let key = P256.Signing.PrivateKey()
        try BTSubscriptionKeychain.write(key.rawRepresentation, account: "device-signing-key")
        return key
    }
}

struct BTSubscriptionClaim: Decodable {
    let aud: String
    let deviceID: String
    let issuedAt: Double
    let expiresAt: Double
    let validUntil: Double
    let priceCents: Int
    let days: Int
    let paymentsEnabled: Bool
    // Missing policy in older signed responses must retain the existing daily limit.
    let subscriptionEnabled: Bool?
    let startsAt: Double?
    let paymentChannels: [String]?
    func allowsUnlimited(at now: Double) -> Bool {
        issuedAt <= now + 300 && validUntil > now && (expiresAt > now || subscriptionEnabled == false)
    }
}

enum BTSubscriptionVerifier {
    // Public verification key only. Matching private key is distributed separately to the operator.
    static let publicKey = "BFuxu2aaqgEyrjxGOADET1X69miait64KLxm4JYS2oTrRL/MH4iad2NTleo01HrMJCPt1sQHzVSGoaEnG8G+T2E="
    private struct Envelope: Decodable { let payload: String; let signature: String }
    static func decode<T: Decodable>(_ data: Data) throws -> T {
        let envelope = try JSONDecoder().decode(Envelope.self, from: data)
        guard let payload = Data(base64Encoded: envelope.payload), let signature = Data(base64Encoded: envelope.signature),
              let publicData = Data(base64Encoded: publicKey) else { throw BTSubscriptionError.damagedIdentity }
        let key = try P256.Signing.PublicKey(x963Representation: publicData)
        guard key.isValidSignature(try P256.Signing.ECDSASignature(derRepresentation: signature), for: payload),
              let object = try JSONSerialization.jsonObject(with: payload) as? [String: Any],
              object["aud"] as? String == "com.mxmall123.app" else { throw BTSubscriptionError.damagedIdentity }
        return try JSONDecoder().decode(T.self, from: payload)
    }
}
