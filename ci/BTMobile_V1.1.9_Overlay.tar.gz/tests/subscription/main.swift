import Foundation
import CryptoKit

func date(_ value: String) -> Date { ISO8601DateFormatter().date(from: value)! }
let now = date("2026-09-17T10:00:00Z")
var ledger = BTMagnetLedger(deviceID: UUID(), day: BTMagnetLedger.dayKey(now), used: 0, lastSeen: now)
for _ in 0..<3 { assert(ledger.reserve(at: now)) }
assert(!ledger.reserve(at: now))
assert(!ledger.reserve(at: date("2026-09-16T10:00:00Z")))
assert(!ledger.reserve(at: date("2026-09-17T15:59:59Z")))
assert(ledger.reserve(at: date("2026-09-17T16:00:00Z")))
assert(ledger.used == 1)
assert(ledger.day == "2026-09-18")
let restored = try JSONDecoder().decode(BTMagnetLedger.self, from: JSONEncoder().encode(ledger))
assert(restored.used == 1 && restored.deviceID == ledger.deviceID)
let fake = Data("{\"payload\":\"e30=\",\"signature\":\"AA==\"}".utf8)
do { let _: BTSubscriptionClaim = try BTSubscriptionVerifier.decode(fake); fatalError("accepted forged entitlement") }
catch { }
// P256 DER signatures are the wire format shared by CryptoKit and the server.
let key = P256.Signing.PrivateKey()
let bytes = Data("wire-test".utf8)
let signature = try key.signature(for: bytes)
let decodedSignature = try P256.Signing.ECDSASignature(derRepresentation: signature.derRepresentation)
assert(key.publicKey.isValidSignature(decodedSignature, for: bytes))
print("PASS: daily quota, fourth rejection, backwards clock, Beijing rollover, persistence, forged entitlement, DER signature")

func policy(enabled: Bool?, expires: Double, valid: Double = 1100) throws -> BTSubscriptionClaim {
    var object: [String: Any] = ["aud":"com.mxmall123.app", "deviceID":UUID().uuidString,
        "issuedAt":900, "expiresAt":expires, "validUntil":valid, "priceCents":800, "days":30, "paymentsEnabled":false]
    if let enabled { object["subscriptionEnabled"] = enabled }
    return try JSONDecoder().decode(BTSubscriptionClaim.self, from: JSONSerialization.data(withJSONObject: object))
}
let policyChecks = [
    try !policy(enabled: true, expires: 0).allowsUnlimited(at: 1000),
    try policy(enabled: false, expires: 0).allowsUnlimited(at: 1000),
    try policy(enabled: true, expires: 2000).allowsUnlimited(at: 1000),
    try policy(enabled: false, expires: 2000).allowsUnlimited(at: 1000),
    try !policy(enabled: nil, expires: 0).allowsUnlimited(at: 1000),
    try !policy(enabled: false, expires: 0, valid: 999).allowsUnlimited(at: 1000),
    try !policy(enabled: true, expires: 1000).allowsUnlimited(at: 1000),
    try !policy(enabled: false, expires: 0).allowsUnlimited(at: 599)
]
assert(policyChecks.allSatisfy { $0 })
let restricted = BTSubscription.Snapshot(deviceID: "test", remaining: 1, error: nil)
assert(restricted.statusText == "未订阅" && restricted.allowanceText.contains("剩余1次"))
var free = restricted; free.subscriptionEnabled = false
assert(free.statusText == "未订阅" && free.allowanceText == "免费无限添加磁力任务")
free.paid = true
assert(free.statusText == "已订阅" && free.allowanceText == "无限添加磁力任务")
print("PASS: subscription switch matrix, legacy claim, expired cache, expiry boundary, future claim, status labels")
