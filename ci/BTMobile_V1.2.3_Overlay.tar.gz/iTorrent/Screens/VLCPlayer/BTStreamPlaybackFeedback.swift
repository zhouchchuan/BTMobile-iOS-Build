import Foundation

/// A stalled HTTP read can be *ahead* of the decoder. Only show buffering when
/// the playback clock has also stopped, using uptime rather than wall-clock time.
struct BTStreamPlaybackFeedback {
    enum ReadState { case ready, waiting, paused, failed(String) }
    var readState: ReadState = .waiting
    private var previousTime: TimeInterval?
    private var lastAdvance: TimeInterval?
    private var startedAt: TimeInterval = 0

    mutating func reset(now: TimeInterval) {
        previousTime = nil
        lastAdvance = nil
        startedAt = now
        readState = .waiting
    }

    /// Two increasing samples confirm playback; a seek's first clock jump does
    /// not. Do not require landing within two seconds of the requested timestamp:
    /// MKV keyframes and delayed event delivery can legitimately overshoot it.
    mutating func sample(time: TimeInterval, now: TimeInterval) -> Bool {
        guard time.isFinite, time >= 0 else { return false }
        defer { previousTime = time }
        guard let previousTime, time > previousTime + 0.05 else { return false }
        lastAdvance = now
        return true
    }

    func message(now: TimeInterval, wantsPlayback: Bool, seeking: Bool) -> (text: String, failed: Bool)? {
        guard wantsPlayback || seeking else { return nil }
        guard now - (lastAdvance ?? startedAt) >= 2 else { return nil }
        switch readState {
        case .ready: return nil
        case .waiting: return ("正在缓冲目标位置，等待下载分片…", false)
        case .paused: return ("BT任务已暂停，请恢复任务以继续缓冲", false)
        case .failed(let message): return (message, true)
        }
    }
}
