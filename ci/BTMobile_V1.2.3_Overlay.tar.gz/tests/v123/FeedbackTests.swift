import Foundation

@main struct FeedbackTests {
    static func main() {
        var state = BTStreamPlaybackFeedback()
        state.reset(now: 10)
        precondition(state.message(now: 11.9, wantsPlayback: true, seeking: false) == nil)
        precondition(state.message(now: 12, wantsPlayback: true, seeking: true) != nil)
        precondition(!state.sample(time: 514, now: 13))
        precondition(state.sample(time: 518.5, now: 13.5)) // missed the old +/-2s seek tolerance
        precondition(state.message(now: 13.5, wantsPlayback: true, seeking: false) == nil)
        // HTTP read-ahead waits throughout, but actual frames continue.
        for i in 1...100 {
            precondition(state.sample(time: 518.5 + Double(i), now: 13.5 + Double(i)))
            precondition(state.message(now: 13.5 + Double(i), wantsPlayback: true, seeking: false) == nil)
        }
        precondition(!state.sample(time: 618.5, now: 114))
        precondition(state.message(now: 116, wantsPlayback: true, seeking: false) != nil)
        state.readState = .paused
        precondition(state.message(now: 116, wantsPlayback: true, seeking: false)?.text.contains("暂停") == true)
        precondition(state.message(now: 116, wantsPlayback: false, seeking: false) == nil)
        precondition(state.sample(time: 619, now: 117))
        precondition(state.message(now: 117, wantsPlayback: true, seeking: false) == nil)
        state.readState = .failed("test timeout")
        precondition(state.message(now: 117.5, wantsPlayback: true, seeking: false) == nil)
        precondition(state.message(now: 120, wantsPlayback: true, seeking: false)?.failed == true)
        state.reset(now: 200)
        precondition(!state.sample(time: 2000, now: 200.1)) // a new seek's initial jump isn't playback
        precondition(!state.sample(time: 2000, now: 203))
        precondition(state.message(now: 203, wantsPlayback: true, seeking: true) != nil)
        precondition(!state.sample(time: .nan, now: 204))
        precondition(!state.sample(time: -1, now: 204))
        precondition(state.sample(time: 2004, now: 204))
        precondition(state.message(now: 204, wantsPlayback: true, seeking: false) == nil)
        print("PASS: startup debounce, read-ahead while playing, overshot seek clock, real stalls, pause, timeout, retry, invalid clocks")
    }
}
