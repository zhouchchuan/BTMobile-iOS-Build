from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
tests = Path(__file__).parent
with tempfile.TemporaryDirectory(prefix='bt-feedback-tests-') as folder:
    binary = Path(folder) / 'feedback-tests'
    subprocess.run(['swiftc', str(root / 'iTorrent/Screens/VLCPlayer/BTStreamPlaybackFeedback.swift'),
                    str(tests / 'FeedbackTests.swift'), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)

native = (root / 'Submodules/LibTorrent-Swift/LibTorrent/Core/TorrentHandle/TorrentHandle.mm').read_text()
body = native.split('- (NSInteger)prepareStreamingReadAtIndex:', 1)[1].split('- (void)addTracker:', 1)[0]
assert '32 * 1024 * 1024' in body
assert '[self resetStreamingReadWindow]' not in body
assert 'self.btReadPriorities[@(p)] != nil' in body
assert 'handle.have_piece' in body and 'handle.resume()' not in body
vc = (root / 'iTorrent/Screens/VLCPlayer/VLCPlayerViewController.swift').read_text()
seek = vc.split('func seekStreaming(to target:', 1)[1].split('// MARK: - Foreground Restore', 1)[0]
assert 'player.seek' not in seek
assert 'network-caching=6000' in vc
assert 'abs(newPlaybackTime - target) < 2' not in vc
assert 'player.currentTime.timeInterval' in vc and 'monitorStreamingPlayback()' in vc
assert 'configureChineseSubtitleFonts(for: media)' in seek
assert 'streamingWantsPlayback' in vc and 'isManualFullscreen' in vc
print('PASS: streaming buffer/seek integration guards; subtitle/fullscreen paths retained')
