//
//  UserDefaults+AppGroup.swift
//  iTorrent
//
//  Created by Даниил Виноградов on 30.06.2024.
//

import Foundation

extension UserDefaults {
    static var itorrentGroup: UserDefaults {
        .standard
    }
}
